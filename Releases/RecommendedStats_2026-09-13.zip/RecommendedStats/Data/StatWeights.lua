-- GENERATED 2026-09-13 - do not hand-edit
RecommendedStatsData_StatWeights = {}
