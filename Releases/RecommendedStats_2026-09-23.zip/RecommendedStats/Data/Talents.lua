-- GENERATED 2026-09-23 - do not hand-edit
RecommendedStatsData_Talents = {
    ["SHAMAN_ENHANCEMENT_MYTHICPLUS"] = {
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZZGbMzglZmZmxYhZAAmhxMjZEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAzyMmxYZZGYmxYZmZmZMWYGAgZYMzwMBmZwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjlFjNmZ2GLzMzMMjxMAAzwYmxMiZmZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYbxYDzsNzyMzMDjlxMAAzwYmhZCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYmlZmZGmZhZAAmhxMDjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYzMzYsMjZGYZMDAwMMmZMzEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGLMzsNWmZmZYGMDAwMMmZMjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYsMzMzwMLjZAAmhxMDjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMbzYGzssMjFzMzGLz8AzMPAzCzAAMDjZGGxMzMDGMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZZGbMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzsNWmZmZYYMDAwMMmZYmAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmZGLLGbMzsYWmZmZeAYMDAwMMmZYmAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjlFjFmZ2GLzMzMDzCzAAMDjZGGxMzMDGMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjxstILGmhZ0gFAmlZMjxyyM2YmZjlZmZGGGzAAMDjZGzMBmZwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjZmNaW2GmhZ0gFAmlZMjxyyMwMzyYZmZmhxyYGAgZYMzwMxMzMDGMGA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_ENHANCEMENT_RAID"] = {
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjxstILGmhZ0gFAmlZMjxyyM2YmZjlZmZGGGzAAMDjZGzMBmZwgxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjxstILGmhZ0gFAmlZMjxyyM2YmZjlZmZGGLMDAwMMmZMzEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjllZsxMzGLzMzMMMmBAYGGzMmZiZmZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZxYjZmNWmZmZGYMDAwMMmZMzEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZZGbMzglZmZmxYhZAAmhxMjZEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAzyMmxYZZGYmxYZmZmZMWYGAgZYMzwMBmZwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjlFjNmZ2GLzMzMMjxMAAzwYmxMiZmZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYbxYDzsNzyMzMDjlxMAAzwYmhZCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZxYjZmtxyMzMzwswMAAzwYmhRgZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGLMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYmlZmZGmZhZAAmhxMDjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxMLLzYzMzYsMjZGYZMDAwMMmZMzEYmBDGDA",
            ["n"] = 1,
        },
    },
    ["MONK_MISTWEAVER_MYTHICPLUS"] = {
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAgAsYbmtZbmBEAAjBYGwAsIjZA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswYaGzAGMYYZmZmhZbwwsYCAAAAgWGwilZWmtZGQAwAmZgZAjhxiMmBA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAMbTbz2MLzitZ2mtZGQAAMmZGMDYAWkxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghhZWGzysNjZmtNDMDzGz2yyMjFGTzYGwgBMmZmZY2GMMLzEAAAAABYx2MLz2MDIAAGDwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAYmZmhZDzwsMTAAAAAEgFbzsMbzMgAgBjBYGwAsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZ22MwMMbmZzyMjFGTzYGwgBwMzMDzGmhZZmAAAAAIAL2mZb2mZABADGDwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgxwyMLjZZ2mxMjFDLLzwsNmtllZGLM0MmBMYYwyMzMDzGmhZZmAAAAAzy0ywsML2mZZ2mZABADwMwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZ22MwMMbmZzyMjFGTzYGwYMbAzMzMMbYGmlZCAAAAgAsYbmtZbmBEAAjBYGwAsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgB2mZZMLz2MmZ22MwMMbMbLLzMWYMNjZADGwYmZmhZDzwsMTAAAAgZbab2mZZWsNz2sNzACAGMmZGMDYAWkxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswYaGzAGjhBLzDMzMMLDeAmlHYCAAAAgAsYZmlZbmBEAMgBYGwYYsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2YZYzixMzyyM2wYGmZZZbmxCzoZMDYwAGzMzMMbDGsMTAAAAAEgFLzsMbzMgAgBMAzAGDjFZMDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAgAsYbmlZbmBEAAjBYGwAsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZADGwYmZmhZDzwsMTAAAAAEgFbzsNbzMgAAYMAzAGDsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYGNjZADGAzMzMMbYGsMTAAAAAEgFbzsNbzMgAgBjBYGwYwsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZWW2mZswMaGzAGMYMLzMzMMbDGsYCAAAAgAsYZmlZbmBEAMgBYGwYYsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZ2WMwMMbmZzyMjFGTzYGwgBMmZmZY2wMMLzEAAAAABYx2Mbz2MDIAAGDwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYmpZMDYwgxYmZmhZDzglZCAAAAgAsYbmtZbmBEAAjBYGwYgFhZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYoZMDYMGAzMzMMbwwsMTAAAAAEgFbzsNbzMgAgBjBYGwYwsIjZA",
            ["n"] = 1,
        },
    },
    ["MONK_MISTWEAVER_RAID"] = {
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswYaGzAGMALzMzMMbwws8ATAAAAAEgFLzsMbzMgAgBjBYGwYYsIjZA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYMmZmZY2GjBLmAAAAAIALWmZZ2mZABADYAmBMGGLyYGA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswYaGzAGMYYZmZmhZbwwsYCAAAAgWGwilZWmtZGQAwAmZgZAjhxiMmBA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZsYmNMMbmZbZZmxCjpZMDYMGAzMzMMbwwsMTAAAAAEgFbzsMbzMgAgBjPAYGwYgFZMDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswQzYGbYwghlZmZGmtBDziJAAAAAaZALWmZZ2mZABADYmBmBMGGLyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW22mZswYaGzAGMALzMzMMbwws8ATAAAAAEgFLzsMbzMgAgBjBYGwYYsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAMbTbz2MLzitZ2mtZGQAAMmZGMDYAWkxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghhZWGzysNjZmtNDMDzGz2yyMjFGTzYGwgBMmZmZY2GMMLzEAAAAABYx2MLz2MDIAAGDwMgxALyYGA",
            ["n"] = 1,
        },
    },
    ["PALADIN_PROTECTION_MYTHICPLUS"] = {
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzy8AzMzMzM2WGDLDLDDAwAAAAAAgmmZ2mZMzwY2aDADMgZwGAAABYmZZbplZGL22wAAmZxYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGz8AzMzMzyyYMLjZZGDAwAAAAAAgmmZWmZMzwY2aDADMgB2AAAzMtNzsMzMzyySLzM2sswMAGMDjBAzMLzAMDwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZegZmZGLbjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02Mz2MzMLbLtMzYxyCzAYwMbYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02MzyMzMLbLtMzYxyCzAYwMbYAwMz2MAzMgxC",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMzYMbtBgBGgBbAAAEgZmltlWmZsYZBDAYGGDAmZAwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyMzYmZG2WGjZZWsNjBAAAAAAAASzMMjZmxY2aDADYgZw2AAAIAzMLbLtMzYx2CGAMmhxAgZGAmZGwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjHYrNAMwAGYDAAgAMzsst0yMjFLLMDgBzshBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamZZmxMzYYrNAMwAMYDAAgAMzsst0yMjFLLMDgBzwYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamxMjZGGzWbAYgBMwGAAYmptZmlZmZW2WaZmxilFmBwgZYMAYmZZGgZGwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlhBAYAAAAAAQTzMLzMmZYYrNAMwAmBbAAgZm2mZ2mZmZZbplZGb2WYGGYwMbYAwMzyMAzMgxC",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWmHYmHYmZmZ2WGjZZYbGDAwAAAAAAgmmZMzYmZMmt2AwAADsBAAmZabmZbmZmlllWmZsYZDDgxYGGDAmZ2mBYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLbjxYWmlZMAADAAAAAAaamZZmxMYMbtBgBGwMYDAAMz02Mz2MzMLbLtMzYz2CGAwMbGDAmZ2mBYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLMDAYmNjBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLbjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02Mz2MzMLbLtMzYxyCzAYwMMGAMzsMDwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLYAMYmNjBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamxMjZGGzWbAYgBMwGAAYmplZmlZmZW2WaZmxilFmBwgZYMAYmZZGgZGwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjHYrNAMwAmBbAAgZm2mZWmZmZZbplZGbWWwAYwMMGAMzsNDwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamxMjZGGzWbAYgBMwGAAABYmZZbplZGLWWYGADmhxAgZGAMzAGb",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLzilZMAAAAAAAAQTzMLzMmZYMbtBgBGwMYDAAMz02MzyMzMbbLtMzYxyGzAYMGmxAgZmlZAMAjF",
            ["n"] = 1,
        },
    },
    ["PALADIN_PROTECTION_RAID"] = {
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamZZmxMzYYrNAMwAmBbAAgZm2mZ2mZmZZbplZGLWWwAgxMMGAMzsMDwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLzilZMAAAAAAAAQTzMLzMmZYMbtBgBGwMYDAAMz02MzyMzMbbLtMzYxyGzAYMGmxAgZmlZAMAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLzysNMAADAAAAAAaamxMjZwY2aDADMDMD2AAAzMtNzsMzMzy2SLzMWYjZAMzYYGDAmZWmBwAMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLMDgBzshBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAm+0bA85vR0Yy+QcPHjtRvuZMMzyYZmZmZmx2MzMmZZMMAAADAAAAAAAJzMLGmBjhZLAwYAAmBbDAAwMTbzysNDQgNDMAMzYGGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjZrNAMwAGYDAAMz0mBzMzy2SLzMWsswMAYMDjBAzMAYGgxC",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLjZbYAAGAAAAAA00MziZMzMGPwWbAYgBMD2GAAYmptZmtZmZW2WaZmxilNmBwMjhhBAzMLzAYAGL",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLjZbYAAGAAAAAA00MjZGzgxs1GAGYGYGsBAAmZabmZZmZmltlWmZsYZjZAMzYYGDAmZWmBwAMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlhBAYAAAAAAQTzMmZMzwY2aDADYgZw2AAAzMtNzsMzMzy2SLzMWsswMAmZMMMAYmZbGADwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjZrNAMwAGYDAAgAMzsst0yMjFLLMDAGzwYAwMDAmBYsB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLzilhBAYAAAAAAQTzMLzMmZYMbtBgBGgBbDAAMz02MzyMzMLbLtMzYzyGGAzMGmxAgZmlZAMAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzy8AzMzMzM2WGDLDLDDAwAAAAAAgmmZ2mZMzwY2aDADMgZwGAAABYmZZbplZGL22wAAmZxYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGz8AzMzMzyyYMLjZZGDAwAAAAAAgmmZWmZMzwY2aDADMgB2AAAzMtNzsMzMzyySLzM2sswMAGMDjBAzMLzAMDwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZegZmZGLbjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02Mz2MzMLbLtMzYxyCzAYwMbYAwMDAmZAjF",
            ["n"] = 1,
        },
    },
    ["HUNTER_SURVIVAL_MYTHICPLUS"] = {
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2mxYGzwyYaGAAAgBAGLLzMWwMz4BGjBgZsBGjZmNDA",
            ["n"] = 2,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZMzsNDAAAAAgZMzMjNjxMmhlx0MAAAADAwy2MjlZMzwMGDYmtZsBGDzsYAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMgxMG2ILwMM0gFzMzMzMWGAAAAAAmxMzM2mxwYG2GTzAAAAMAYYZZm5BWYmZYGjBMzGAGjZmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYzYmZMsMAAAAAAMjZmZwYMjZwQzAAAAAAzYZZmZWYmZmZmZAMz2MWYWmxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgNjZmxwyAAAAAAwMmxMYMmxMYMNDAAAwAgZssMzMLMzMzMzMAwMWYWMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZZ0ssMMDzMNYbmZmZMmtZAAAAAAMjZmBGPgZMDLjpZAAAAGAgllZGLGzMzMjZGwMLzYDmxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYzYmZMsMAAAAAAMjZmZwYMjZwYaGAAAgBAzYZZmZWYmZmZGDgZ2mxCzixYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2MGzYGMmmBAAAYAgxyyMjFMzMmxYAYGbwMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqM2wMzYmZb0ssMMDzMNYbGzMMmtZAAAAAAMDjZsYMmhxsMjmBAAAYAAW2mxsYmZmZmxMDYmtZstgZMmZWMAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZMzsNDAAAAAgZMzMDGjZMDbjpZAAAAGAgltZGLzYmhZMGwMbzYDmxwMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgNjZmxwyAAAAAAwMzMzMMjxMmBjpZAAAAGAMjllZmZhZmZGzMGAmxCYMmZ2MAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjxMmhlx0MAAAADAMW2mZsMMzYMzYAYGbgxwMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz28AAAAAAAmxMzMMjxMmBjpZAAAAGAYmltZGLDzMMjxAwM2gZMMzmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgNjZmxwyAAAAAAwMGzM2mxYGzgx0MAAAADAmZWWmZmFjZmZegZGDAzYDMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYzYmZMsMAAAAAAMjZmZsNjxMmhtx0MAAAADAmxyyMzswMzMegxYAzsNjFwYMzsZAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZmxsMPAAAAAAgZMzMjtZMmxMYMNDAAAwAAjllZGLYmZMjxAmZbGbgxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzM2MGzYGWGTzAAAAMAALbzMWmxMDzYMAMjNwYYmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2mxYGzgx0MAAAADAMWWmZsgZmxMGDAzYDMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjxMmBjpZAAAAGAgltZGLzYmxYMzAwM2wixwMLGAA",
            ["n"] = 1,
        },
    },
    ["HUNTER_SURVIVAL_RAID"] = {
        {
            ["code"] = "C8PApei1JmYNvFfEFaN5bWuGKMgxMGWILwMM0gFzMzMzwyAAAAAAgZMzMDz4BMjZwYaGAAAAAAjllZmZxMzMGzMGwMbAmlZMmZ2MA",
            ["n"] = 2,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZmxsMPAAAAAAgZMzMjtZMmxMYMNDAAAwAAjllZGLYmZMjxAmZbGbgxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMgxMG2ILwMM0gFzMzMzMWGAAAAAAmxMzM2MGzYGWGTzAAAAMAYYZZm5BWYmZYGjBMzGAGjZmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZMzsNDAAAAAgZMzMjNjxMmhlx0MAAAADAwy2MjlZMzwMGDYmtZsBGDzsYAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMgxMG2ILwMM0gFzMzMzMWGAAAAAAmxMzM2mxwYG2GTzAAAAMAYYZZm5BWYmZYGjBMzGAGjZmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYzYmZMsMAAAAAAMjZmZwYMjZwQzAAAAAAzYZZmZWYmZmZmZAMz2MWYWmxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgNjZmxwyAAAAAAwMmxMYMmxMYMNDAAAwAgZssMzMLMzMzMzMAwMWYWMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZZ0ssMMDzMNYbmZmZMmtZAAAAAAMjZmBGPgZMDLjpZAAAAGAgllZGLGzMzMjZGwMLzYDmxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYzYmZMsMAAAAAAMjZmZwYMjZwYaGAAAgBAzYZZmZWYmZmZGDgZ2mxCzixYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2MGzYGMmmBAAAYAgxyyMjFMzMmxYAYGbwMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2mxYGzwyYaGAAAgBAGLLzMWwMz4BGjBgZsBGjZmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqM2wMzYmZb0ssMMDzMNYbGzMMmtZAAAAAAMDjZsYMmhxsMjmBAAAYAAW2mxsYmZmZmxMDYmtZstgZMmZWMAA",
            ["n"] = 1,
        },
    },
    ["PRIEST_DISCIPLINE_MYTHICPLUS"] = {
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYMmZGMbzYmZmZmZAAAAAAAAAAYYWmBzMzYbGzMgpZiBzMAIAmtZbBM2MAAMmZmxgZwMDGBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMDGzMGbmmJGMzAgAY2mtFwYzAAwYmZGDmBzMYEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYMmZGMbzYmZmZmZAAAAAAAAAAYMWmBzMzYzYmBMNTMYmBABwsNbLgxmBAgxMzMGMDmZwMBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGBzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAghZZGMzMjNjZGW2MNTMAzshhwYWGgxgFAAYMzMjBzAMzQwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMzwYmBbmmJGMzAgAY2mtFwYzAAwYmZGDmBzMYEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgxYZGmZmZYGzMYz0MxgZmZ2wQYMLzsNbbGjxiBAgxMPwMGMwMzMzMBzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsYwyMzMPwMwMbzYmZmZMzAAAAAAAAAAYGzyMYmZGmhZATzEDmZmZBDhxsMzystYMGLGAAGzMGDzMYmZmZmgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDzyMjxYmhZbGzMjZ8AzAAAAAAAAAAYYWmBzMzwMmZATzEDwMLYIMmlBYMYBAAGzMzYwMAzMzEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMGWmZmxMwMbzsMzMjxMDAAAAAAAAAgZMLzgZmZYGzMANTMYmZmFMEGzyMbz2mxYsYAAYMzYMMzgZmZmZCG",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzwyMjZGgZbGzMzYMzAAAAAAAAAAYYWmBzMzwMmZgZamYGmZmZDDhxsMz2stZMGLGAAGzMzYwMYmZmxEMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyMzMYmHwgZbmZmZmZAAAAAAAAAAYGWmBzMzwMMDMTzEDmZAQAMbz2CYsZAAYMzMjBzgZGMTwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMzMzgZbGzMzY8AzAAAAAAAAAAYMzyMYmZGmxMDYamYwMzMLYIMmlZ2mtNjxYxAAwYmxYwMYmZmZmgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMGWmZMzMwMbzYmZMjZGAAAAAAAAAAjxyMYmZGbGzMYz0MxAMzGGCjZZAGDWAAgxMzMGMDwMzIYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWGjxYGMbzYmZmZmZAAAAAAAAAAYMWmBzMzwMmZATzEDmZmZBDhxsMz2stYMGbGAAGzMzYwMYmZmZmgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsYmxyYMmZmhZDmZmZmZAAAAAAAAAAYYWmBzMzwMMjBTzEDmZAQAMbz2CYsZAAYMzMjBzgZGMTwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzwMgpZamBzMAIAmtZbBM2MAAMGzMGMDmZwMBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMjNjZGsZamYwMDACgZb2WAjNDAAjZmZMYGMzgRwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgxYZGMzMjNjZGsZamYAmZBDhxsMAjBLAAwYmZGDmBYmZEMD",
            ["n"] = 1,
        },
    },
    ["PRIEST_DISCIPLINE_RAID"] = {
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMjNjZGsZamYwMDACgZb2WAjNDAAjZmZMYGMzgRwM",
            ["n"] = 3,
        },
        {
            ["code"] = "CAQAJVmtV83otBfEj5bt80waBAgtZegZMmZMmBmtZ2mZmxYmBAAAAAAAAAAzysMbMmZGMLMmxYMMLsNTjJWMAzsgFKGzyAM2wCAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzwMgpZamBzMAIAmtZbBM2MAAMGzMGMDmZwMBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMjNjZGsZamYwMjBQAMbz2CYsZAAYMzMjBzgZGjRwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAJVmtV83otBfEj5bt80waBAgtxMDGzDMmZGzsZ2mZGzMmBAAAAAAAAAAWmlZbwMzgZhhBjhZxsNTjJWmBzMAoAMbz2GYsZDAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYMmZGMbzYmZmZmZAAAAAAAAAAYYWmBzMzYbGzMgpZiBzMAIAmtZbBM2MAAMmZmxgZwMDGBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMDGzMGbmmJGMzAgAY2mtFwYzAAwYmZGDmBzMYEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYMmZGMbzYmZmZmZAAAAAAAAAAYMWmBzMzYzYmBMNTMYmBABwsNbLgxmBAgxMzMGMDmZwMBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGBzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAghZZGMzMjNjZGW2MNTMAzshhwYWGgxgFAAYMzMjBzAMzQwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgZYZGMzMzwYmBbmmJGMzAgAY2mtFwYzAAwYmZGDmBzMYEMD",
            ["n"] = 1,
        },
    },
    ["MONK_BREWMASTER_MYTHICPLUS"] = {
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMmZZYZ7B22mNMLAAwysMtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBmwMYmB2MMmZmZMzmtxYmlhltHYbb2wsAAALzy0ysNzyAAMbzSzMzsxwGYmZmhpxAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBmYmBmhxGDmZmZY2GzMmZZYZ7B22mNMLAAwysMtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEmBmhxmhxMzMDz2YmxYZYZ7B22mNMLAAwysNtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGPwYWm5B2YmZMAAAAAAALLYmYmBzMM2AmZmZY2GzMGLDLbPw22shZBAAWmlplZbmlBAACghNwMDYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMz2wMjBAAAAAAYZBmYmBmhBzgZmZGmtxMjZWGW2egttZDzCAAsMLTLz2MLDAAEADbgZGw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEmBmhxmBmZmZMzGzMmZZYZ7B22mNMLAAwysNtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMMzGwMzMDzGzMGLDLbPw22shZBAAWmlplZbmlBAY2mlmZmZjhNwMzMDTjBMAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMMzGDmZmZY2GmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2MwMzMjZ2YmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBjwMYmhxmZwMzMDz2YmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMPwGzMjBAAAAAAYZBzEzMwMMzGDmZmBzGzMmZZYZb22mNMLAAwysNtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMz2YmZMAAAAAAALLYmYmBmhxGMmZmZMzGzMGLDLbPw22shBAAsMLTLz2MLDAAEADbgZGw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMM2YwMzMDz2YmxYZYZz22sNMLAAwysMtMbzsMAAz2s0MzMLmhNwMzMDTjBMAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGjZmtxMzYAAAAAAAWWwMxMDMDzsZgZmZGmNmZMWGW2egttZDzCAAsMLTLz2MLDAwsNLNzMzGDbgZmZGmGDAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGzYGWmxGmZMAAAAAAALLYEzMwMMzGDmZmZY2GmxMLPALb22GzYWAAgNEAAgZbWamZmFzwCAzMMNGwAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMMzGwMzMDzGzMmZZYZ7BW2mNMLAAwysMtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGDPwY2mxGmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2mltZbYWAAgNEAAgZbWamZmNG2AYmhpxAGAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBjYmBzMM2MwMzMjZ2YmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
    },
    ["MONK_BREWMASTER_RAID"] = {
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMLbGzYGWmxGmZMAAAAAAALLYEzMwMM2MjxMzMjZ2YmxMLYZz22YGzCAAshAAAMbzSzMzsZG2AYmhpxAAAG",
            ["n"] = 2,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAwMbbGDGzyM2YmZMAAAAAAALLYEzMwMM2gxMzMDzmtZGzsMssNbbz2wsAAAbIAAAz2s0MzMbMsBwMDTjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyM2YmZMAAAAAAALLYEzMwMMDzgZmZGmthZMzywy2ssNGzsAAAbz20ysNzyAAMbzSzMzswwGYmZmhpxAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMMzmZwMzMDzGzMGLDLbz22YYWAAglZbaZ2mZZAAmtZpZmZWYYDMzMzw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMM2MDmZmZMz2wMGLDLb22mtxMLAAwysMtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAgZbzYGzYWmxGmZMAAAAAAALLYmYmBmB2MwMzMDz2YmxMLDLb22GzYWAAgtZZaZ2mZZAAmtZpZmZ2MDbgZmZGmGDAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGzwYWmxGmZMAAAAAAALLYEzMwMM2MjxMzMDz2wMGLDLbz22YMzCAAsNbTLz2MLDAwsNLNzMzCDbgZmZGmGDAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAwMbbGDGz2MPwGzMjBAAAAAAYZBjYmBmhZ2MwMzMDzGzMmZZYZbW2mNMLAAwGCAAwsNLNzMzGDbAMzw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAgZbzYGPwYWmZ2YmZMAAAAAAALLYmYmBmhZ2MwMzMDzGzMGLDLbPwy2shBAAsMLTLz2MLDAAEADbgZGw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMmZZYZ7B22mNMLAAwysMtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBmwMYmB2MMmZmZMzmtxYmlhltHYbb2wsAAALzy0ysNzyAAMbzSzMzsxwGYmZmhpxAAAG",
            ["n"] = 1,
        },
    },
    ["WARRIOR_FURY_MYTHICPLUS"] = {
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 3,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmBAAYmhxsMwgxA",
            ["n"] = 3,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMjZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMzMjZmZmZGzsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDMYM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMzy2YjFLLmpxMzwkZhZYDYmhBAYmBzMMmlhxgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjZmZ2WmxMjxMmZmZmZmZWmZGzMmFzMzAAAhB2glFjGzAysgZsAMzwAAMzAwwixAGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMDjFAAYmhxsMwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZ2MAAAzMMmlBGMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMz2yMzMzMzMmZmZmZMzyMGzMmNzMzAAAxYZbgFwEMDTgZYDYmhBAAYmhxsMwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMjZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmBAAYmhxsMwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsYmZGAAIMwGssY0YGQmFMjFAzgBAMzAwwiZAGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMz2yMzMzMzMmZmZmZm5BWmxYmxsZmZGAAIGLbDsAmgZYCMDbAzMMAAAzMMmlBGMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMziZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 1,
        },
    },
    ["WARRIOR_FURY_RAID"] = {
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 3,
        },
        {
            ["code"] = "CgEArbixk/ZKwTdpZGVHeylmLAAAAAAAAAQDMzwMwYAgHYYGMY22mZMzMLYGzMDzw2sNPAzMGAAAEDbDsAmADTgBbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEArbixk/ZKwTdpZGVHeylmLAAAAAAAAAQjhhNzMWmxgZWYmZGzwMMz22MjZmZBGzMzYmxywwDMzMAAAIGbbDsAmgZYCMDbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxM2WmZMzYmhZMjZmZWmxMzMmtxMzAAAxMbLDsYZhpxMzwkBzwGAAAwMDmZmhxADGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmxGAAMzwYWGGDGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEArbixk/ZKwTdpZGVHeylmLAAAAAAAAAQjhZmtZmhZMYmFmZmhhZYstNzYmZWYmxMzMmhNbzwMmBAAAxYbZgFwEMDTgBbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEAO9DBjZzKcjSu6RJDto0RCCAAAAAAAAAEgBDMGAwAAmNzMmZsMMjZMmZYZYmZGzAAAABAAEACAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEAjLzRlq54bI5v+r8Sr9Xw4DAAAAAAgGDzMmhlZmZmZYMzMzYGzsMzMGzMbjZmBAAixyyALgJYGmAzwGwMDmtBAAzMGGzMDDG",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_UNHOLY_MYTHICPLUS"] = {
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxMDz2MzMTzmZGjZMAAAAAAAAMzwYAwyMmZ2MzYmZMYZmFzMzimZZhZjZZasgBMDAjZmxMAzMDjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTz2MzYmZMAAAAAAAAMzYMDAWGmZ2mZGzMjBGYGbassBYbiNMgZAYMzMMYmBDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMzMDz2MzMTzmZGzMDAAAAAAAAMzYMDAWGmZ2mZGzMjBGYGLassAYbiNMgZAYMzMMYmBGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxYGAsMMzsNzMmZGD2GYGbassAYbiNMgZAYMzMMYmBjZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyYmZa2mZGzMjBAAAAAAAgZGjZAwywMz2MzYmZMwAzYTjlNAbTshBMDAjZmhBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMMjZYY2mZmZa2mZGDjZAAAAAAAAMzwYAwyMmZ2mZGzMjBLzsYmZW0MLLMbMbTjNAMDAjZmxMYmZmZmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxYGAsMMzsNzMmZGDMwM20YZDw2EbYAzAwYmZYwMDGzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxYY2mZmZa2MzYmZMAAAAAAAAMzYYAwywMz2MzYmZMwAzYTjlFAbTshBMDAjZmxMYmBDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTz2MzYmZMAAAAAAAAMzYMDAWGmZ2mZGzMjBbzsZmZ20MLbMbMbTjNMgZAYMzMMYmZmZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjZMY2mZmZaMzMmZGDAAAAAAAAzMGzAglhZmtZmxMzYw2MbmZmNNzyCzGz20YDDYGAGzMDDmZmZYGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxYY2mZmZa2MzYmZMAAAAAAAAMzYYAwyMmZ2MzYmZMwAzYTjlNAbTshBMDAjZmxMYmBDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMDY2MzMTz2MzMzMjBAAAAAAAg5BGDDAWmBzmZGzMjBGYGbassBYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMzYY2mZmZa2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZMYbmFzMzimZZhZjZbasAgZAYMzMmBzMzMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxYY2mZmZa2MzYMjBAAAAAAAgZGmZAwyMmZ2mZGjZALmFDDZgZjhGLAYGAGzMjZAmZmxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMDDzyYmZa2mZmZmZMAAAAAAAAMzYYAwyMmZ2MzYmZMwAzYTjlFALTshBMDAjZmxMYmBMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGGDAWmxMz2MzYmZMwAzYRjlFAbTsBgZAYMzMmBzMYGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxYGAsMMzsNzMmZGDMwM20YZBw2EbYAzAwYmZYwMDGzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZGmZAwyMmZ2mZGzMDYzsYYIDMbM0YBAzAAzMjZAmZmxYA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_UNHOLY_RAID"] = {
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZmxYY2mZmZa2MzYMjBAAAAAAAgZeAmZAwyMmZ2mZGzMjBLzsYmZW0MLLMbMLTjFAMDAMzMGAzMzYMA",
            ["n"] = 4,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZeAmZAwyMmZ2mZGzMDYzsYYIDMbM0YBAzAAzMjBwMzMGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMzYY2mZmZa2MzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBLzsYmZW0MLLMbMLTjFMgZAYMzMmBYmZGjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzA2MbGGyAzGDNWwAmBgxMzYGgZmxMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMDY2MzMTz2MzMzMjBAAAAAAAg5BGDDAWmBzmZGzMjBGYGbassBYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMGDz2MzMTjZmxYGDAAAAAAAAzMMzAglZMzsZmxMzAWMLGGyAzGDNWAwMAMmZGzAMzMzMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMGDz2MzMTjZmxYGDAAAAAAAAzMMGAsMjZmNzMmZGwiZxwQGY2YoxCGwMAMmZGzAMzMzMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPASnrjTdwaLTX9NnLQoJJXfAwMjZMGDz2MzMTzmZGjZMDAAAAAAAgZGmZAwyMmZ2mZGzYA2MLGGyAzGDNWAwMAwMzYGgZmZMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTz2MzYmZMAAAAAAAAMzYMDAWGmZ2mZGzMjBGYGbassBYbiNMgZAYMzMMYmBDjB",
            ["n"] = 1,
        },
    },
    ["ROGUE_ASSASSINATION_MYTHICPLUS"] = {
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALzsMWYMjZpxstMMZbYYxgZGMzMGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsNDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYmxYMmZYMAGYBmxoxsByyA2MAYmZMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AzDMmZMGmZMGADsAzY0Y2AZbAbAgZmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMzYegxMjxwMjxMgtZWGLMmxs0Y2WGmsNMsgFzMYmZMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsNzyYhxMmlGz2ywkthhNDmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsNDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMzYGzYMmZMMAbzsMWYMjZpxstMMZbYYzgZGMzMGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGLzMzsNzyMz8AegxMjZGmZMGglZWGLMmxs0YWWGmsNMsZwMDmZmhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxMADsAzY0Y2AZbAbGAMzMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZGGMAAAAAwsMYbGAAAAAQWmZmZmZGjtZmZ2mZZmZGPwYmxMDzMGDw2MLjFGzYWaMLLDT2GGWMYmBzMjxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsNzyYhxMmlGzyywkthhNDmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMz8AjZGjhZGzMAGYBmxoxsBy2A2MAYmZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxAsZWGYALBLDTghFDmZAGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxAsNzyYhxMmlGz2ywkthhFDmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlZmZmZmxYZmZmtZWmZmHwDMmZMzwMjxAsNzyYhxMmlGz2ywkthhFDmZwMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlZmZmZmxYZmZmtZWmZmHwDMmZMzwMjxAsNzyYhxMmlGzyywkthhNDmZwMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMz8AmxMjxwMjxMgtZWGLMmxs0Y2WGmsNMsBmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlZmZmZmxYZmZmtZWmZmHwDMmZMzwMjxAYgFYGjGzGIbDYDAMzMGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZmHYMzYMMzYMAGYBmxoxsAy2A2MAYmZMGA",
            ["n"] = 1,
        },
    },
    ["ROGUE_ASSASSINATION_RAID"] = {
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZmHYMzYMMzYMAGYBmxoxsAy2A2MAYmZMGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWCWGmADLGMzAMGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAbmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxMmZMGADsAzY0Y2AZbAbGAMzMDfA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALzsMWYMjZpxstMMZbYYxgZGMzMGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsNDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMzYmxYMmZYMAGYBmxoxsByyA2MAYmZMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AzDMmZMGmZMGADsAzY0Y2AZbAbAgZmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMzYegxMjxwMjxMgtZWGLMmxs0Y2WGmsNMsgFzMYmZMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AmxMjxwMjxAsNzyYhxMmlGz2ywkthhNDmZwMzYMA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_RESTORATION_MYTHICPLUS"] = {
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstNmZmZMzMjhxyyML2YMjlpx2MLMZGGbYmBzyMjRzyyMzmZMbsYMzYYZWmBAgBwMDmZwMDjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMYWWmZxGjZsMN2mZhJzwYzMMDWmZmZa2WmZ2MjBLz8AzMGMLDAAAMzMYmBzMwgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZmZGjZMsAbwMW0YbAZGYDzMY2mZmRzyyMzmZMYZGzMGWmFAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssMjZGjZGzMYsAbwMW0YbAZGYzMMDWmZmZa2WmZ2MjZhlZMzYwsMAAAwMzgZGAYwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZmZGjhxyyMb2YMjlpx2MbMZGGbYmBz2MjRzyyMzmZMbsYMzYMmlZAAYAMzgZGMzwYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzYMjhFYDmxiGbDIzAbMzMYWmZMa2WmZ2MjZjFjZGDmlZAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzYMjxyyML2YMjlpx2MLMZGGbMzMY2mZmRz2yMzmZMYZGzMGjZBAAGAzMYmBzMMGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMDjxYmZYsAbwM20YbAZGYzMDD2GjZa2WmZ2MjZhFzYGzwsMAAAwMzgZGAYwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMDjxYmBjFYDmxiGbDIzAbmZYYWGzMTz2yMziZMbsMjZGDmlBAAAmZGMzAADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzMjZMsAbwMW0YbAZGYDzMYWmZmRzyyMzmZMYZGzMGMLDAAGAzMYmBgxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMDjxYmBjFYDmxiGbDIzAbmZYY2mZMTz2yMziZMbsYMzYwsMDAAAmZGMzAADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMzMzMjZGjZMsAbwMW0YbAZGYDzMY2mZmRzyyMzmZMYZGzMGWmFAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsttMzMzMjZGjhhFYDmxiGbDIzAbYmBzyMzMa2WmZ2MjBLzYmxwysMAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzYMjhFYDmxiGbDIzAbMzMY2mZmRz2yMDzYwyMmZMsMLDAAGAzMYmBgxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAAAAAAYmZmtltZmZmZMzYMjxyyMLWYYsMNWmZhJzwYhZmBz2MjRz2yMzmZMYxYmxYWmFDAADAzYwgZGGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAAAAAAYmZmltlZmZGjZmZMjhFYDmxiGbDIzAbYmZYWmZMTz2yMDzY2YxYmxwysMAAYAmZGMzAwYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzMjZMsAbwMW0YbAZGYDzMY2mZMaWWmZ2MjZjFjZGDmlZAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzMjhxyyML2YMjlpx2MLMZGGbYmBzyMjRzyyMzmZMbsYMzYYZWmBAgBwMDmZwMDjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZYMGzMYWWmZzCjZsMN2mZjJzwYzMDDWGzMTz2yMzmZMLsMzYGDmlBAADwMzgZGMzADmB",
            ["n"] = 1,
        },
    },
    ["SHAMAN_RESTORATION_RAID"] = {
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDIzAbmhZw2YMTz2yMzmZMLsYegZGzwsMAAAwMzgZGAYwM",
            ["n"] = 3,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMjxyyMb2YMjlpx2MbMZGGLmhZw2YMTz2yMzmZMLsYegZGzwsMAAAwMzgZGMzADmB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMjxiZ2gBMBzGTgxiZYGsNGz0stMzsZGzCLmHYmxMMLDAAAMzMAYmBGMD",
            ["n"] = 2,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZYMzYmZMWMzGMgJY2YCMWMGzgtxYmmtlZmNzYWYx8AzMmhZZAAAgZmBAzMwgZA",
            ["n"] = 2,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMzMzMjZGjZgFYDmxiGbDIzAbMzMY2mZMa2WmZ2MjZjFjZGDLzyMAAAYmZwMDAAzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDIzAbmhZw2MjZa2WmZ2MjZhFzDMzYGGDAAAMzMYmBAGMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMjxyyMbWYMjlpx2MbMZGGLmhZw2YMTz2yMzmZMLsYegZGzwsMAAAwMzgZGMzADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQAL+iDLHPJSLC+6fqMJ8tubCAAAAAAAAAAYMzMLzwMYW2sMAYBWgZspxyAyMwGeADYZmZmJzyCzMNmhZ2wyMmBjhZZMAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZYMGzMYWWmZzCjZsMN2mZjJzwYzMDDWGzMTz2yMzmZMLsMzYGDmlBAADwMzgZGMzADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstNmZmZMzMjhxyyML2YMjlpx2MLMZGGbYmBzyMjRzyyMzmZMbsYMzYYZWmBAgBwMDmZwMDjBD",
            ["n"] = 1,
        },
    },
    ["MAGE_FROST_MYTHICPLUS"] = {
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmZGzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAWAYbbMzMDmthxMsAAAwMbAzwYAzgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmxYmZmZWMzMzMzMzsMTzMbzCAAAaBAA2AAAAAYzYmZmhZbGzMjtNAAAwMDmBGwAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmZGzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAWAYbbMzMDmthxMsAAAwMbAzADYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzMzMziZmZMjZgAAAzMzssMz0GAAAAAAsBw2yYmZGMbDjZYBAAgZ2AmBGwMYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmxswMzEzMGzMzMziZmZmZmZmlZamZbWAAAQLAAwGAAAAAbLjZmZGmtZMzM2WAAAAzMYGYADgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMzMzMzMziZmZMjZgAAAzMzssMz0GAAsBAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzMzMziZmhZMDEAAYmZmllZm2AAAAAAgFA2WGzMzgZbYMzYBAAgZ2AmhxAmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzALzMzsMmZmYmZGzMzMziZmhZMDEAAYmZmllZm2AAAAAAgFA2WGzMz8AMbDjZGLAAAMzGwMwAmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAQLAAAAAAwCAbbjZmZwsNjZmx2CAAAYmBzADYGgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZEzMmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAgNA2WGzMzMMbDjZYBAAgZ2AmBGwMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNmtlZWmZmZDzMxMMzMzYmFzMjZGzMLz0Mz2sAAmZmZZZmpNAAYBAAAsBw2yYmZALzYMzYBAAgZ2AmhxMgBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlxMzEzMGzMzMziZmhZMDEAAYmZmllZm2AAgNAAAwCAbbjZmZwsNMmZsBAAwMbAzADYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMmZmZmZWMzMzMzMzsMTzMbzCAAAaBAAWAAAAAYbZMzMDmtZMzM2WAAAAzMYGGDYAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFmZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwGAbLjZmZwsNMmZsAAAwMbAzADYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMegZmYmxYmZmZ2MzMjZGzsMTzMbzCAYmZmtlZmWAAgNAAAAA22GzMzgZbmZmZmtFAAAmZbmBzwYADgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzYmZWMzMzMMzsMTzMLzCAAAaBAAWAAAAAYbZMzMDmtZMzM2WAAAAzMYGYAD8BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmxsMbzMTMDzMzMzMLmZmxMmBCAAMzMzyyMTbAAwGAAAYBgttxMzMY2GGzwGAAAzsBMDjBMDGA",
            ["n"] = 1,
        },
    },
    ["MAGE_FROST_RAID"] = {
        {
            ["code"] = "CAEAMhlVtghLZL4RZzExaQoBYZGGLzMzsMmZmYmZmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAAbAstMmZmBz2wYGWAAAYmNgZgBMDGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CAEAMhlVtghLZL4RZzExaQoBYZGGLzMzsMmZmYmxMzMzMziZmZMjZgAAAzMzssMz0GAAAAAAYDgtlxMzMY2GGzwCAAAzsBMDjBMDGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFmZmYmZmZmZmZWMzMMjZmtZamZZWAAzMzssMz0GAAAAAAsBw22YmZGMbDjZGLAAAMz2MDmBGwMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMzMzMzMziZmZMjZgAAAzMzssMz0GAAsBAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGmZZm5BmlxMzEzMzYmZmZWMzMjZMzsMTzMLzCAYmZmllZm2AAAAAAgNA2WGzMzgZbYMDLAAAMz2MDmBGwMYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGmZZmZmlxMzEzYmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAgNA2WGzYGMbDjZYBAAgZ2AmBGwMYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGLjlZmHYWGzMTMzMjZmZmZxMzMmxMQAAgZmZWWmZaDAAAAAA2AYbZMjZwsNMmhFAAAmZDYGGDYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAgNA2WGzMzgZbYMDLAAAMzGwMwAmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAMhlVtghLZL4RZzExaQoBYNzwYZGmlxMzEzMzMzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAsBw2yYmZGMbDjZYBAAgZ2AmhxAmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmZGzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAWAYbbMzMDmthxMsAAAwMbAzwYAzgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmxYmZmZWMzMzMzMzsMTzMbzCAAAaBAA2AAAAAYzYmZmhZbGzMjtNAAAwMDmBGwAYA",
            ["n"] = 1,
        },
    },
    ["MAGE_ARCANE_MYTHICPLUS"] = {
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzQzMGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMmFMzQzMzAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
            ["n"] = 2,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFmZQzMGAAAGAwMz0sssNDAEbAAAmZG2sMjZWmxYmZmZYhZmZmZAAGAAgBYmBYAwwMzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZm5BmFMzQzMzAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGLjlZmZWwMoZmZAAAYAAzMTzyy2MzMzssMzEbAAsAzMDbWmxMLzYMzMzMswMmZmBAYAAAmZWwMDYGAMMzM",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLmZmFMzQzMzAAAwAAmZmmlllZAgYDAgNGzMDbWmxMLzYMjZmhFmZm5BmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMPwsgZGamZGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZmZmZZZmJ2AAAMzMsZZGzsMjxMzMzwCzMzMzAAMAAAzMLYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZxMzsgZQzMzAAAwAAmZmmlltZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAjBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMmFmZQzMzAAAwAAmZmmlllZAgYDAgFYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFMDamZGAAAGAwMz0sssMzMzMLLzMxGAAbMmZG2sMjZWmxYGzMDLMzMzMDAwAAAMzsgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGLjlZmHYW4BmZoZGDAAADAYmZaWWWmBAiNAA2YMzMsZZGzsMjxMmZGWYmZmZGAgBAAYAmZAGAMMzM",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzsgZGamZGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMmFegZQzMzMAAAGAwMz0sssMzMzMLLzMxGAAbwMzwmlZmZWmxYGzMDLMzMzMDAwAAAMzsgZGwMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzsgZGamxAAAwAAmZmmlllZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAjBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZAgYDAAYmZmxmlZmZWmxYMzMYhZmZmZAAGAAgBYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwYZmxswDMDamZGAAAGAwMz0sssMDAEbAAsxYmZYzyMmZZGjZMzMswMzMzMAADAAwAMzAmBADzMD",
            ["n"] = 1,
        },
    },
    ["MAGE_ARCANE_RAID"] = {
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzQzMGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZAgYDAAwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMAzMgZAwwMzA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZAgYDAAwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMAzMgZAwwMzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmxMzMAADAAwAMzAmBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAkrVdV3pA5GLQDtVHHbnyGZGMbzgZMjZzDwYmhx08AjZAAAAAAYgAmZmWmtlZAgYDAAAAAgNAMGMzysMzMzYMDzMzMjZYZM",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMzQzMzAAAwAAmZmmlltZAgYDAAwMzwmlZMzyMGzMzMDLMzMjZAAGAAgBYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMzQzMzAAAwAAmZmmlllZAgYDAAwMzwmlZMzyMGzMzMDLMzMjZAAGAAgBYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamZGAAAGAwMz0sssMDAEbAAAmZG2sMjZWmxYmZmZYhZMzMDAwAAAMAzMgZAwwMzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFmZQzMGAAAGAwMz0sssNDAEbAAAmZG2sMjZWmxYmZmZYhZmZmZAAGAAgBYmBYAwwMzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZm5BmFMzQzMzAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGLjlZmZWwMoZmZAAAYAAzMTzyy2MzMzssMzEbAAsAzMDbWmxMLzYMzMzMswMmZmBAYAAAmZWwMDYGAMMzM",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLmZmFMzQzMzAAAwAAmZmmlllZAgYDAgNGzMDbWmxMLzYMjZmhFmZm5BmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMPwsgZGamZGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZmZmZZZmJ2AAAMzMsZZGzsMjxMzMzwCzMzMzAAMAAAzMLYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZxMzsgZQzMzAAAwAAmZmmlltZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAjBADzMD",
            ["n"] = 1,
        },
    },
    ["PALADIN_HOLY_MYTHICPLUS"] = {
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzDYGzYGmBAwMDzYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAAbAgBAAWGwMzyMzsMjZMsY2MziZaiZZGzMzYMbZAYAYDsxiZGAEAwMzy2ilZG2YbMD2AmhBAMzAwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZ2mZmlZMjhFzmZWMTTMLGzMDjZLDADAbgNWMzYZ2GGBAMzsssYZmhN2GzgNgZ2GAgZGMwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwAAA2mZmZMjZGLmxMDLjtZmFjmYMjZmhxslBgBMsB2YZGzsMbzMzWDAAAwCAsZYMjZwAAYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZ2mZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsZmBABAMzsssYZmhN2GzgNgZMAAzMAMjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAAWGwMzyMzsMjZMsY2MziZaiZxYmZGjZLDADAbgN2MzMLz2Mzs1AAmZWWWsMzwGbDD28AwMbDAwMDmZwYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAYwyAmZWmZmlZMjhFzmZWMTTMMmZmxY2yAwAwGYjFzMAIAgZmllFLzMsx2YGsBMjBAYmBAjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsZmZWmtZmZpBAMzsssYZmhN2GPwgNgZMDAYmBzMMjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2mZGmZWmZsAzMsM2mZWMaihxMzwY2yAwAwGYjtZmZWmtZmZrBAAAYhNMYzMYGDMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMMmZGGzWGAGA2AbsYmBABAMzsssYZmhN2GzgNDMjBAYmBgZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2GGmZWmZsYMzMsM2MziRTMLGzMDjZLDADAbgNWmZmZZ2mZmlGAwMzy2mtZGWYjZwGwMGMDgZGMzwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAAWGwMzyMzsMjZMsY2MziZaixMmZmxY2yAwAwGYjNzMAIAgZmllFLzMsx24BGsBMjBAYmBgZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAAWGwMzyMzsMjZMsY2MziZaihxMzMGzWGAGA2AbsZmBABAMzsssYZmhN2GzgNgZMAAzMAMjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2GzMzMjZmZBmZYZsZmFjmYWMmZGGzWGAGA2AbsNzMzysNzMbNAAAALAD2AmZbGmBAwMDzYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMmxMzMGzWGAGA2AbsYmZWmtZmZrBAMzsssYZmhN2GGsZgZMAAzMYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMLzYmZYMbZAYAYDsxmZGAEAwMzyyilZG2YbMD2AmZbAAmZAwYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAADWGwMzyMzsMjZMsY2MziZaixMmZmxY2yAwAwGYjNzMzysNzMbNAgZmllFLzMsx2YGsBMjBAYmBzMYMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAAbAwMAADWmZmZmZMzMLGzYYBmZxoJGGzMDjZLDADAbgNWmZmZZ2mZmtGAwMzyyilZGWYjZwGDmhhBgZGMzwMGjGA",
            ["n"] = 1,
        },
    },
    ["PALADIN_HOLY_RAID"] = {
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAglxMzYGzMzGjxYWGbzMLmpJGzYmZYY2yAwAG2AbsMjZWmtZmZrBAAAYBA2MMmxMAAgZGmxY0A",
            ["n"] = 2,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAAbAwMAADWmZmZmZMzMLGzYYBmZxoJGGzMDjZLDADAbgNWmZmZZ2mZmtGAwMzyyilZGWYjZwGDmhhBgZGMzwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZMzYxYmZYZwMLzoJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAYwyAmZWmZmlZMjhFzmZWMTTMMmZmxY2yAwAwGYjFzMAIAgZmllFLzMsx2YGsBMjBAYmBAjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMDAAsMmZGzYmZWYMGzyYbmZxMJGGzMDDzWGAGwwGYjlZMzysNzMbNAgZmltFLzMsAAbegxYGzMAwMDmZYGjRD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAwgtFLDsAAbGGzYGmBwMwMDzYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAglxMzYGzMzCjxYWGbzMLmpJGGzMDDzWGAGwwGYjlZMzysNzMbNAAAALAwmhxMmZAAgZGmxY0A",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAglZmZGzYmZ2YwYWGbzMLzoJGGzMDDzWGAGwwGYjlZMzysNzMbNAAAALAwmhxMmZAAgZGmxY0A",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyYmZMjZmZjxYMLjtZmFzkY2mxMzwY2yAwAwGYjtZMzysNzMLNAAAALAwmhxMmBAAMzwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwAAAWGzMjZMzMLMGjZZsNzsYmmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNDjZMzAAAzMMjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZWmZsYMmhlBzsYmmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2GzMzMjZmZBmZYZsZmFjmYYMzMMmtMAMAsB2YbmZmlZbmZ2aAAAAWAGsZgZMDzAAYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAGsMmZmZGzMjZMmhlxixmZaihxMzAegtMAMAsB2YxMzsMbzMzSDAYmZZbxyMDbAAPwAAAAAAIA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZWmZsYMmhlBzsMjmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGNA",
            ["n"] = 1,
        },
    },
    ["PALADIN_RETRIBUTION_MYTHICPLUS"] = {
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGEAAwCgBAjZ2AmxMzGwMzwYGDG",
            ["n"] = 2,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAMzGwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGmZAAAAAAYUmlZYmx2Y2GmZbGjxYYGLsNAMLzyMzs1gAAAWAMAYMzGDmxMzGwMzwYYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxMjxYmxCbAYWmtZmZrBBAAsAYAwYGmBzYmZDYmZYMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAANbbzMzyYmZAAAAAAYUGzwMjtxsNMz2MmZMGmxCbDAzysNzMbNzMtNzsNDAYBwAgxMMDmxY2wyMzMjZMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAjysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAMjZYGMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAjhBMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtmZm2mZ2mBAsAYAwYGGYGzMbYZmZmhxMGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrZmptZmtZAALAGAMmhZwMmZ2wyMzMDjhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAgZ2AmxMzGwMzwYGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzMzAAAAAAYmysYYmx2Y2GmZbGjxYMzYjNAMbz2Mzs1Mz02Mz2MAgNADAGzwMYGzMbYbmZmhBGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBBAAsAYAwYGGYGzMbAzMDjZMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtmZmWmZ2mBAsAYAMGzsBMjZmNsMzMzwYYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAYMDDMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxMjxYmxCbAYWmtZmZrZmptZmtZAALAGAMmhZwMmZ2wyMzMDjhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAgZ2AmxMzGwMzYGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1Mz02MzyMAgFADAGzwAzYmZDLzMzMMGGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGEAAwCgBAjZ2AmxMzGwMzwYGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAZmptZmtZAAbAGAMmhBmxMzGWmBDjZMYA",
            ["n"] = 1,
        },
    },
    ["PALADIN_RETRIBUTION_RAID"] = {
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrZmptZmtZAALAGAMmhBmxMzGWmZmZMjhBD",
            ["n"] = 3,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAZmptZmtZAAbAGAMmhBmxMzGWmBDjZMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAVg1HmQqr1Dwlv86ljju8vCAAAAAQz22MzsMMzAAAAAAwoMmhZGbDz2wMbzYMmZYGbsNAAgMz02Mz2MAgNADAzYGmBzYMbYZGMMmxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAMzGwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGmZAAAAAAYUmlZYmx2Y2GmZbGjxYYGLsNAMLzyMzs1gAAAWAMAYMzGDmxMzGwMzwYYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAjyYGmZsNmthZ2mxMjxYmxCbAYWmtZmZrBBAAsAYAwYGmBzYmZDYmZYMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAANbbzMzyYmZAAAAAAYUGzwMjtxsNMz2MmZMGmxCbDAzysNzMbNzMtNzsNDAYBwAgxMMDmxY2wyMzMjZMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAjysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAMjZYGMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAjhBMjZmNgZmhxwgB",
            ["n"] = 1,
        },
    },
    ["WARRIOR_ARMS_MYTHICPLUS"] = {
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZbZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTIzgNwMDDDmlZ2GgZGAMDDA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAgBNMGzMbLzMzMDzYmBAAAAwYZmBmwYZbgFwAmhJkZwGYmx2wgZZmtBYmBAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZzMzMzwMmZAAAAAMWmZgJMWWGYBMgZYCZGsBmZsNMYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZYmZbZmZmZYGzMAAAAAmZZmBmwYZZgFwAmhJkZwGYmhhBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzYmZGAAAghphZGzMbLzMzMDGzMAAAAAmZZmBmwYZb2MzywihhZmZajmZwGYmhhBWmZbwMzMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMz8AmZGAAAghphxwMbLzMzMjZGzMAAAAAmZZmBmwYZZgFwAmhJkZwGYmhhBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZbZmZmZYGzMAAAAAmZZmBmwYZZgFwAmhJkZwGYmhhBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTIzgNwMDjtBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCZGsBmZYsNwyMLDwMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMDzMLLzMzMDzYmBAAAAwMLzMwEGLLDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMmZGAAAghphxYmZbZmZmZwYmBAAAAwMLzMgwYZZgFwAmhJkZwGYmx2wALzsMAzMAYGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmxyMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCZGsBmZYsNYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYDMgZYCZGsBmZYsNwyMLDwMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxwMbLzMzMjZGzMAAAAAGLzMwEGLbzmZWGWMMMzMTb0MD2AzMMMYWmZbwMzMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGzMbmZmZGmxMDAAAAgxyMDMhxy2AbgBMDTIzgNwMDDDmlZ2GgZGAMDDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTIzgNwMDDDmlZ2GgZGAMDDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZxMzMzYmxMDAAAAgxyMDMhxy2sZmthFDDzMz0GNzgNwMDDDmlZ2GMzMzAgZYA",
            ["n"] = 1,
        },
    },
    ["WARRIOR_ARMS_RAID"] = {
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmxyMzMzgxMDAAAAgZWmZgJMWWmFsAGwMMhMD2AzMM2GMLzsNAzMAYGGA",
            ["n"] = 5,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmZbZmZmZwYmBAAAAwMLzMwEGLLDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 4,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFz8AmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyysgFwAmhJkZwGYmhx2ALzsNAzMAYGGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2AbgBMDTIzgNwMDDDmlZ2GgZGAMDDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZYmxyMmZGzMmZAAAAAMWmZgJMW2GYBMgZYCZGsBmZYsNY2mZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMzMDAAAghphZYGLLzMzMDzYmBAAAAwMLzMgsYssMwCYAzwEyMYDMzgxYwMGgZGAmZYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMz8AmZGAAAghphxwMbLzMzMjZGzMAAAAAmZZmBmwYZZ2MzywihhZmZajmZwGYmhhBWmZbwMzMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmxyMzMzgxMDAAAAgZWmZgJMWWGYBMgZYCZGsBmZYsNYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYGWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTIzgNwMDmtBzyMbDwMDAzMMA",
            ["n"] = 1,
        },
    },
    ["WARRIOR_PROTECTION_MYTHICPLUS"] = {
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYGLzMzMDzYmBAAAALDAzYAGstBbLGNmBwsEzsBzMmBzCAMzAAwAGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZYmZmZGzmZmlhxY0wMzstMjZmxMMzAAAAglZGgZMAD22mxsssMamZYGWmlGzsAjZmhBAYmZmBAYgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd32AAAzMzYmZGmZ2mxsMMGjGGzYZmZmZYGzMAAAAYZAYGDAsYGDbkBmhFaMzCjZYGMbAAmZAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzMmZmZmxsZmZZYMmphZmZjZmZGGmZAAAAwyMDwMGgB2gtFjGzAY2iZ2wMYGmZDAmZAAwAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYmllZMzMmhZGAAAAsMGgZMADW2mxsssNamZYGWmlGzsBjZmhBAYmZmBAYgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmFzMLzYMGNmZGWMzMDzwMDAAAAWmZAmxAMYbbGzyyyoZmhZYZWaMzGMmZGGbAwMzMDAYGYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmNzMLzYMGNmxwyMmZGzwMDAAAAWmZAmxAMYbD2WMaMDgZJmZDGzMDmNAYmBAgZgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZYMGNmxYZxMzMjZYmBAAAALzMAzYAGYDWWMaMDgZJmZDGzMDGAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZYMGNmxYbxMzMjZYmBAAAALzMAzYAGYDWWMaMDgZJmZDGzMDDAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmNzMLzYMGNmxYbxMzMjZYmBAAAALzMAzYAGYDWWMaMDgZJmZDGzMDGAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZMLzYMGxMzMbmZmZGzwMDAAAAWGDwMGgBbLzYWW2GNzMMDLzWjZ2gZmZGGbAwMzMDAAYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzgZmZmxsYmZZGPgxoxMGWMzMzYGzMDAAAAWmZAmxAMYbbGzyy2oZmhZYZWaMzGmxMzwYDAmZmZAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYMzMzMmNzMLzYMGNmxwiZmZGzwMDAAAAWmZAmxAMYbbGzyyyoZmhZYZWaMzGMmZGMbAwMzMDAYGYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZGjxoxMGWMzMzYGmZAAAAwyMDwMGgB2glFjGzAYWiZ2AmZGMbAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAzMzYmZGGzmZmlhxYmGGjtlZmZmhZMzAAAAglZAMzyAMwGssY0YGAzWM2gZMzgBAMzAAwMwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZwMzMzY2MzsMjxYEmZYZmZmZYGzMAAAAYZMAzYAGYDWWMaMDgZLmZDmZmZwsBAzMAAMDMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmNzMLzYMGNmxYbZGzMjZGzMAAAAYZmBYGDwAbwyiRjZAMLxMbwYMDGAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZGjxoxMGWMzMzYGmZAAAAwyMDwMGgB2glFjGzAYWiZ2AmZGGLAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZGjxohxMWmZmZGzwMDAAAAWmZAmxAMwGssY0YGAzSMzGwMzwYDAmZAAwAjB",
            ["n"] = 1,
        },
    },
    ["WARRIOR_PROTECTION_RAID"] = {
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAzMDzMzMzY2MzsMMGjGmZssMzMzMMjZGAAAAsMGgZMAD22mxsssNamZYGWmlGzsBzYmBDAYmBAgBMG",
            ["n"] = 2,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYGLzMzMDzYmBAAAALDAzYAGstBbLGNmBwsEzsBzMmBzCAMzAAwAGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLzgxMNMGMzwMYYGAAAAsMGgZ2GgB2glFjGzAY2iZ2gZAYDAmZAAwADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmZmZmxMmNjZZGjxMNMzwyMzMzgxMDAAAAWGDwMGgB2glFjGzAY2iZ2gZMzwYDAmZAAYAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLDjxMNMzwyYmZGmxMDAAAA2GDwMbDwAbw2iRjZAMbxMbYmxMDmNAYmBAgBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLDjxMNMzYbZMzMDGzMAAAAYZMAzsNAD22mxstsNamZYG2mtGzshZGzMM2AgZmZGAwAGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLDjxMNMzwyYmZGmxMDAAAAWGDwMbDwAbw2iRjZAMbxMbYmxMDjNAYmBAgBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYGLzMzMDzYmBAAAALDAzYAGYD2WMaMDgZJmZDmZMDmFAYmBAgBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZYmZmZGzmZmlhxY0wMzstMjZmxMMzAAAAglZGgZMAD22mxsssMamZYGWmlGzsAjZmhBAYmZmBAYgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd32AAAzMzYmZGmZ2mxsMMGjGGzYZmZmZYGzMAAAAYZAYGDAsYGDbkBmhFaMzCjZYGMbAAmZAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzMmZmZmxsZmZZYMmphZmZjZmZGGmZAAAAwyMDwMGgB2gtFjGzAY2iZ2wMYGmZDAmZAAwAjB",
            ["n"] = 1,
        },
    },
    ["HUNTER_BEASTMASTERY_MYTHICPLUS"] = {
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLDNDAAAAAAAAMjxAmZjAmFw2AA",
            ["n"] = 2,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGLzMjZMDGTzAAAAAAAAAzYMgZ2IgZBsNAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAYGjhZmZ2IgZBsNAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAAPwYMgZ2IwMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZYbMNDAAAAAAAA8AjxAmZjAmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAAzYMgZ2IgZBsNAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYxsMjZmhFDLwMLGaGbAAYGzMzsMzwMzMjZGMzYmhZGzMzYzMjZMDGaGAAAAAAAAYGjBMzGhxMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbmZMjZYZMNDAAAAAAAAMjxAmZjAmFw2AA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYzMjZMDGTzAAAAAAAAAzYMgZ2IwMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYzMjZMDGaGAAAAAAAAMzYMgZ2IMMLgtBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzwMzMjZGMzYmhZGzYmltZmxMmBDNDAAAAAAAAmHYMDwMbEGmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZYZMNDAAAAAAAA8AjxAmZjAmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZYMDLjpZAAAAAAAAgHYMGwMbEYmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGPwMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAgxYgZmZ2IYZmFwyAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzYGmZGzYGWGaGAAAAAAAAMzYmBMzGBMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzwMzYGzgx0MAAAAAAAAYegZGDYmNCYWAbDAD",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbEwsA2GAA",
            ["n"] = 1,
        },
    },
    ["HUNTER_BEASTMASTERY_RAID"] = {
        {
            ["code"] = "C0PApei1JmYNvFfEFaN5bWuGKAMmxwCsBzwQDbAAYmx2MzsYGmZmZYGzMGmhZGzMzYbmZYMDLDNDAAAAgZAAAYegxMDYmNEwsA2GA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwGsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwGsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzwMGzYGMmmBAAAAAAAAjxMAzsR2YZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGPwMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAgxYgZmZ2IYZmFwyAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYxsMjZmhFDbwMLGaGbAAYGzMzsYGzMzMjZGjZGmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAYEriH0bRqGs1Qj5St9dJoZxsMjZmhFDbwMLGaGbAAAMgZwAAAwYAAPADDQDAAAAAAAAAAAAEAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PApei1JmYNvFfEFaN5bWuGKALGzYYxwCMDDNsBAgZYbMz2MDzYmhhZGjZGzMjZMDzYMjZwYaGAAAAAzAAAwYmZGwMbIbGmFw2AA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAo4YcvOcqUdzB9zV+NhSAcYzsAGwAGAyYBAAjhZmZxMMzYmhZmZmZMDzMmxMMjxMmZ4BMZAAAAAAzAAAwYmxwMDQwyMLAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PApei1JmYNvFfEFaN5bWuGKYzYgBAYYDyYBAAzw2YmlZGmxMDDzMGzMmZGDDmxYGGgmBAAAAwMAAAMGDMzAEwsAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGmZmlHYGmxMDzYmxYmhZGzMzgZGzYGMmmBAAAAMDAAAmZGDYmNCDzCYbAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGLzMjZMDGTzAAAAAAAAAzYMgZ2IgZBsNAA",
            ["n"] = 1,
        },
    },
    ["HUNTER_MARKSMANSHIP_MYTHICPLUS"] = {
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMjtZMzMmBjpZMYW22mZmZmZmZmFmZZYGAAAzYMAMjNwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGN2GQmBbAAAAAAAAgZMzMDGzMjZwQzYwstZmZmZmZmZgZZYmBAAMzMzYAMjtNMDwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZ2GDjZMTjlZG2yMMbAAAAAAAAgZMjZsNjZmxMYMNjBz222MzMzMzMzgZWGmBAAYegZGGzMYGbMMAbMz2MG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwGMwMGNWGQmBbAAAAAAAAgZMzMjtZMzMmBjpZMYW22mZmZmZmZmFmZZYGAAgxYmBgZsBGgNmZbGD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMjNjZmxMsNmmxgZZbbmZmZmZmZWYmlhZAAAMjxAwM2ADwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMziZMzMmBjpZMYW22mZmZmZmZGYWGmZAAAjZmBAzYbDGgNmZbGD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZWGDjZMTjlZGWyMMbAAAAAAAAgZMjZW2mxMzYG8AmmxgZbbZmZmZmZmZwMLDzAAAMmZGjZGMjNGGgNmZbGD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGTzYwsttMzMzMzMzMYmlhZAAAmHYMjBwM22gBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYG8AmmxgZbzMzMzMzMzswMLDzAAAMmZGDgZsxwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzwMmZGzgx0MGMbbLzMzMzMzMDMLDzAAAMGzYAMjtNWmBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAwYMMAmxGWmBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzwMmZGzgx0MGMbbmZmZmZmZmFMLDzAAAMGzYAMjtNWmBYhZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGTzYwsttNzMzMzMzMwsMMDAAgZmhBwM2YMDwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMziZMzMmBjpZMY22MzMzMzMzMYmlhZGAAwYmhBwM2YYA2YmtZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZYGzMjZwYaGDmtNzMzMzMzMDmZZYmBAAMmZmZAMjNGGgNmZbGD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGTzYwstZmZmZmZmZWwsMMDAAgZmhBwM2YMDwCzsNjB",
            ["n"] = 1,
        },
    },
    ["HUNTER_MARKSMANSHIP_RAID"] = {
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAwYMMAmxGWmBYjZ2mxA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzwMmZGzgx0MGMbbLzMzMzMzMDMLDzAAAMGzYAMjtNWmBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAwYMjBwM2wyMAYmtZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzYGbzYmZMDGTzYwsttMzMzMzMzMYmlhZAAAGjZMAmxGWmBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PApei1JmYNvFfEFaN5bWuGKwCMwMGNWGQmBbAAAAAAAAAzYGzYxYmZMDGTzYwstZmZYmZmZmZhZWGmZAAAzMzAAzM2YYA2YmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAw8AjhBwM2wiBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzwMmZGzgx0MGMbbmZmZmZmZmFMLDzAAAMGzYAMjtNWmBYhZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYG8AmmxgZbzMzMzMzMzswMLDzAAAMmZGDgZsxwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYG8AmmxgZbbZmZmZmZmZwMLDzAAAMmZGDgZsxwAsxMbzYA",
            ["n"] = 1,
        },
    },
    ["PRIEST_SHADOW_MYTHICPLUS"] = {
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIDLmpxAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZgZaMwMAzsZGNbGAyYsAgZGwYmZGzCzstMAzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAMLmxMbzMmZWmxYY2mZGzMzYDZYxMNGYGgZ2MjmNDAZMWAwMjBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZWmZGzM2MzYmZGbIDLbz0AMzMDAEgZb22CmNGAYwYmZGz2YGMzgZwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGDz2MzYmZGbIDLbmGgZmZAgAMbz2WwsxAADmZmZGz2YGMzgZwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGDz2MzYmZmZDZYjpxAzAMzmZ0sZAIjxCAGMYMzMjZjZ2WGgZwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MzYGzmZGzMzwQzAz0MgZAmZzMa2MAkxYBAzAMmZmxsxMbLDwMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDzAAAAAAAAAAAAMMLmxYbmxMz2MYG2mZGzMzATGYmmZGMDwMbmRzmBgMGLAYmxgxMzMmNmZbZAMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGGaGYmmZgZAmZzMa2MAkxYBAzMgxMzMmNmZbZAMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzw2MNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mxYmZGbMZGMTDwMAzsZGNbGAyYsAgZGwYmZGzGzstMAzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mxYmZGbID2mpBYGgZ2MjmNDAZMWAwMDYmZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZAAAAAAAAAAAAgZxMmZbmxMzyMzYmx2MGzMzYDZYxMNGYmZGAIAz2stEMbMAwgxMzMmtxMYmBzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDPAAAAAAAAAAAAgxMLmxMbzMmZWmZGzw2MzYmZGbIDLmpZAzAMzmZ0sZAIjxCAgBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mxYmZGbIDLbz0AMDwMbmRzmBgMGLAYmBMmZmxswMbLDwMYA",
            ["n"] = 1,
        },
    },
    ["PRIEST_SHADOW_RAID"] = {
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGLzMMzyMDzw2MzYmZGbIzYxMNAzAMziZ0sZAIjxCAmZAjZmZMbjZ2WGgZwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CIQA4VPTJ8eQb8/qEm8PyGu4yMMjZGAAAAAAAAAAAgxYxMGLzMMz2MDzw2MzYmZGbIzYxMNAzAMziZ0sZAIjxCAmBYMzMjZbMz2yAMDGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMGAAAAAAAAAAAAjZZmxYZmxMzyMDzwmBzMzMQmhtZaMwMzMYmNzoZzgZb22yYmNGAYwMzMzMz2YGMzgZwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDPAAAAAAAAAAAAgxMLmxMbzMmZWmZGzw2MzYmZGbIDLmpZAzAMzmZ0sZAIjxCAgBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzM2mxYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIDLmpxAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZgZaMwMAzsZGNbGAyYsAgZGwYmZGzCzstMAzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAMLmxMbzMmZWmxYY2mZGzMzYDZYxMNGYGgZ2MjmNDAZMWAwMjBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZWmZGzM2MzYmZGbIDLbz0AMzMDAEgZb22CmNGAYwYmZGz2YGMzgZwA",
            ["n"] = 1,
        },
    },
    ["ROGUE_SUBTLETY_MYTHICPLUS"] = {
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 7,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbLzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbZMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAmhxsYWmxsNDjFGWmZZahWmFYYmZmBzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbLzMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbZmZmZmZMYMz2AAAAwgxsYWmxsNYswwyMLTL0ysADzMmBzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYmZbZmZmZmZMYMz2AAAAwgxsZWGYALglhJkZBGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMLbjxMDjZmZmZGGbzYGbLzMzMzMjBjZWGAAAAGMmFzyMmtZYswwyMLTL0yshZYmZmBzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYG2mZmZmZGDGzsNAAAAmBjZxsMjZbGGLMsMzy0CtMLYGmZmZwMGA",
            ["n"] = 1,
        },
    },
    ["ROGUE_SUBTLETY_RAID"] = {
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMjZYmZmZG8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 3,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 3,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMjZwDMzMzYMbjZmZbbMzMzMjBjZWGAAAAmhxAGzmhBGYW0CtYDGwMDmxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUQAA0tw2gAD7pPTLoW5IGZDeAAMAAAAAAAzyMzsMNmZZmxMGDDzMzMMmtxYGbbzMjZmZMYsMbDAAAAzgBwY2MMwAziWoFbMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQAByFP3pExAEG41/8+e6b8fDgx2MAAAAAwsMGLTMbbjxMjZwDMzMzYMbjZGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAziWoFbYGwMDmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMjZwMzMzYMbDzw2MzMzMzYwYmtBAAAwMYMgxsZYgBmFtQL2wMgZGMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsNGLTMbbjxMjZYmZmZG8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQAphyM11FofNMFa1K3vFEDUCgx2MAAAAAwsMGLTMbbjxMjZwMzMzYMbDzw2MzMzMzYwYmtBAAAwMYMgxsZYgBmFtQL2wMgZGMjB",
            ["n"] = 1,
        },
    },
    ["DRUID_FERAL_MYTHICPLUS"] = {
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 3,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZrZZmtFYmZAWYwAAAYmNMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZMmZmZMmtFWGbzMzYmZAAAAYJY2YMmZUzYWGzMzYMDDAAAAAgBGAAAANzysMzMzsNzSzyMLbwMzAswgBAwMDmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZ2MzMzMGzGWmZZmZm5BmZAAAAYLY2MMmZUzYWGzMzYMjZAAAAAAMwAAAAoZWmlZmZmtZWaWmZZDMzAswgBAwMDmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAmZ2YmZmZG2M2mZZmZm5BmZAAAAYLY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZpZZmtFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzCzMzYMzAAAAAAgBGAAAABAz2MLNLzssBmZAWMzwAAYmBAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCmFDjZG1MmlxMzMGzYAAAAAAYgBAAAQzsMLzMzMbzs0sMz2CYmBYxMYAAMzgZ2wA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZpZZmlFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZ2mZmZ2mZpZZmtFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2MGmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZ2MzMzMzY2MWGbzYm5BmZAAAAYJY2gxMjaGzCzMzYMzMAAAAAAAGAAAABAz2MLNLzssBmZAWMzwAAYmBAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZYmZmZMmNjtZWmxMjZGAAAAWCmNDMzM1MmFzMzMLjZYAAAAAAMwAAAAoZWmlZmZmlZWaWmZZBmZGgFGMAAmZwMbYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAzMzGzMzMGzmx2MLzYm5BmZAAAAYLY2M8AmZUzYWmZmZmlxMAAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZ2YmZmxY2WGLjtZmZMzMAAAAsEMbGGzMqZMLjZmZMmxAAAAAAwADAAAgAgZbmlmlZW2AzMALmBDAgZGAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 1,
        },
    },
    ["DRUID_FERAL_RAID"] = {
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZMGzMjxstMzygZmZmZGAAAA2CmNYMzomxsMzMzMGz8ADAAAAAAgBAAAQzsMLzMzMbzs0sMzyGYmBYxMYAAMzgZWwA",
            ["n"] = 6,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZwMzMzMmtl5BWGbzYm5BmZAAAAYLY2gxMjaGzyYmZGjZmBAAAAAAwAAAAoZWmlZmZmtZWa2mZZDMzAsYGMAAmZwMLYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYLY2MMmZUzYWMzMzYMDAAAAAAMwAAAAIAY2mZpZbmlNYmZAWMDGAAzMAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGAkuH5GdQpDrgY32rlVGnyqBAAAAAAmZb2MzGzMzMbzGjtZmZmHYmBAAAAAYLY2AzMjaGzCbzMjZmZmBAAAAAAAAAABoZWmlZmtBEYBMzAYhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZMmZmZMmtFWGbzMzYmZAAAAYJY2YMmZUzYWGzMzYMDDAAAAAgBGAAAANzysMzMzsNzSzyMLbwMzAswgBAwMDmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZ2MzMzMGzGWmZZmZm5BmZAAAAYLY2MMmZUzYWGzMzYMjZAAAAAAMwAAAAoZWmlZmZmtZWaWmZZDMzAswgBAwMDmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAmZ2YmZmZG2M2mZZmZm5BmZAAAAYLY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZpZZmtFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzCzMzYMzAAAAAAgBGAAAABAz2MLNLzssBmZAWMzwAAYmBAD",
            ["n"] = 1,
        },
    },
    ["DRUID_GUARDIAN_MYTHICPLUS"] = {
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMAAAAAAMjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 3,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMAAAAAAMzsZALbzMYMLDgpAAAAbYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMmBAAAAAMjNDYZbmBjZZAMFAAAYDz8AALGYALWAYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDYjxoJamZWmZmZGjZMDAAAAAYGbzAW2mZwY2GATBAAA2wMPwAWMDGwmltBYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmZmFzMjZWmZxMPwMLLDMbmxoJyMzyYmZmlxMAAAAAAYsZGYZbmBjZZAMFAAAYzYmBYxYYgZxCAzMAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMMAAAAAgZsZALbzMYMLDgpmZbWmZmBAwGmZAWMwAWsAwMzMLwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYqZWmlZmZAAshZMgFzgBsYZbAmZmZDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMGAAAAAgZsZALbzMYMLDgpAAAAbYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMGAAAAAgZsZAbbzMYMLDgpAAAAbYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWMzMzsMmxMAAAAAgZsZAbbzMYMLDgpmZZWmZmBAwGm5BAWMGGwiFAmZmZDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMzyMLmxMLLDMbGGNRzMzyMzMzsMmBAAAAAAjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMAAAAAAMjNDYZbmBjZbAM1MLzyMzMAA2wMDwixwAWsAwMzMLwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWGzMzsMmBAAAAAgZmNDYZbmBjZZAMFAAAYzYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJyMzyYmZmlxMPwAAAAAAMjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZbGGNRzMziZmZmlxMAAAAAwgZsZAbbzMYMLDgpmZZWmZmBAwGmZAWMwAWsAwMzMLwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZbGGNRzMziZmZsMmBAAAAAGMjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsMPwMjZWMLGmZZZgZzwoJTzMzyMzMjlxMGAAAAAgZsNDYZbmBjZZAM1MLzyMzMAA2wMPAwiZwAWsAwMzMbwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWmZxMPgZZZgZjxoJamZWmZmZGjZMDAAAAAYGLzA22mZwYWGATNzysMzMDAgNMjBsYGMAWAYmZmNYA",
            ["n"] = 1,
        },
    },
    ["DRUID_GUARDIAN_RAID"] = {
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMPAAAAAAgZsYAbbzMYMLDgpmZZWmZmBAwGm5BAWMDGwiFAmZmZDG",
            ["n"] = 3,
        },
        {
            ["code"] = "CgGA8cL7tpvige+kkmGM9zUPWDAAAAAAAAAAAgZmZmFzMjZWmZx4BmZZZgZzwoJyMzyYmZmlxMDAAAAAAmNzALbzMYMLDgpAAAAbYmBYxADmZxyGgZGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmZmFzMjZWmZxwMLLDMbGGNRmZWmZmZmlxMGAAAAAgZsZGYZbmBjZZAMFAAAYDzMALGDDMLWMAzMAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGA8cL7tpvige+kkmGM9zUPWDAAAAAAAAAAAgZmxsMmZMz2MLzgx2AYGjmoZmZZmZmZMmxMAAAAAgZsNDYZbmBjZbAM1MLzyMzMAA2wMPwAWMDGwiFDwMzMbwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGA8cL7tpvige+kkmGM9zUPWDAAAAAAAAAAAgZmxsMPwYMzmZZGMWGY2YMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmtBwUAAAgNMzDAsYGMgFLbDwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2mZxgZZbgZzwoJamZWmZmZGjZMDAAAAAYGLzAW2mZwYWGATNzysMzMDAgNMzDAsYGMwsYBgZmZ2gB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsMmZMWMLzMPgZZZgZzMGNRzMziZmZmlxMAAAAAAMsMDYZbmBjZZAMFAAAYDz8ADYxMYwgltBYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWMLm5BmZZZgZDGNRzMzyMzMzYMjZAAAAAAzYZGw22MDGz2AYKAAAwGmZAWMDGALAMzAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2MLmhxyAzmhRT0MzsMzMzMLzMDAAAAAAzYZGwy2MDGzyAYqZWmlZmZAAshZeAgFzgBsZZbAmZmZDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsMPwMjZWMLGmZZZgZzwoJTzMzyMzMjlxMGAAAAAgZsNDYZbmBjZZAM1MLzyMzMAA2wMPAwiZwAWsAwMzMbwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWmZxMPgZZZgZjxoJamZWmZmZGjZMDAAAAAYGLzA22mZwYWGATNzysMzMDAgNMjBsYGMAWAYmZmNYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWMLmhZZZgZjxoJamZWmZmZGjZMDAAAAAYYZGwy2MDGzyAYqZWmlZmZAAshZMgFzgBjFLbAmZmZDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsMmZMziZZGPwMWGY2MMaiMzsMzMzMLjZMAAAAAAzYZGwy2MDGzyAYKAAAwGmZAWMDGwiFAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMAAAAAAMzsZALbzMYMLDgpAAAAbYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
    },
    ["DRUID_RESTORATION_MYTHICPLUS"] = {
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbzQzGjpZGDMLmZmZYYmBAAAAwAAAAABAAMbzs0sNzmNGz8ADmZB0MAAzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGaWGjpZGgZZmZmZYYGAAAAAGAAAAIAAgZbmlmtZ2sxMzMDmBoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMmNjNbzAAAAAAAAAAgFDNbzw0MAmlZmZmZxwAAAAAgBAYGw22YBTzMLDAgZbmtmtZ2sxYmZYmZD0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZzw0MjZwsYmZmZZGegZAAAAAAAwAAQAAAz2MbNbzsYjxMDMzCoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmZmthZwsNsZbGAAAAAAAAAAsANbzw0MgxswMzMLGmBAAAAgBAYAAQAAAz2MbNbzsZjxMDGzGGNDAwMDADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMjxMLzMjZmxsNMmxwYjZAAAAAAAAAAwihmtxYamBYWMzMzwwMDAAAAgBAAw22YBTzMLDAgZbmlmtZ2sxYmZYmZB0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMDmNjNbzAAAAAAAAAAglBNLzw0MjBmFzMzYxwDMAAAAAMAAzAAQAAAz2MbNbzsZjZmZwMzCoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AwsZsZbGAAAAAAAAAAsYoZzMmmZAmFzMzMLGGAAAAAMgBwA22GLYamZZAAMbzs0sNzmFGzMDzMbgmBAzMzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmxYmZmZMbDDjZhZz2MAAAAAAAAAAYxQz2MMNzAPgZxMzMWM8ADAAAAADAYGAAEAAwsNzWz2ML2YmZGMzsBaGAgZGAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAALDa2MjpZGDPgZZmZmZYYmBAAAAAAAAAIAAgZbmlmtZ2sxYmBmBoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsN8AMmFzsZbGAAAAAAAAAAsYoZbGmmZAmFzMzYxwDMAAAAAMgBYGADQAAAz2MbNbzsYjxMzwMzGoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZbMjZmxsNMDmNjNbzAAAAAAAAAAglBNbzw0MjBmFzMzYxwDYAAAAAMAAzAWWGLYamZZAAMbzs1sNzmNmZmBzMLgmBAYmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMDzshNbzAAAAAAAAAAgNDNbmx0MDwsMzMzMM8AzAAAAAYAAMAAEAAwsNzWz2ML2YMzMMzAjmBAYmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZhZMzMmtZGjxsNzsZbGAAAAAAAAAAsYoZbGmmZAmFzMzMLGGAAAAAMgBYGw22YDTzMLDAgZbmlmtZWswYmHYwYD0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMDmNmNbzAAAAAAAAAAgFDNbzw0MDwsYmZmZxwDMDAAAAgBAYGAACAAY2mZrZbmFbMm5BGmZ2ANDAwMDADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2GjpZGgZZMzMDDzAAAAAwAAAAABAAMbzs0sNzmNmZmZwMwoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNzMwshNbzAAAAAAAAAAgNDNbzw0MDwsYmZmZxwDYAAAAAMAAzAAQAAAz2MbNbzsYjxMzwMzGoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2MjpZGDMLzMzMjZYmBAAAAAAAAbbjNMNzsMAAmlZWa2mZzGjZegBzA0MAYmZmBgB",
            ["n"] = 1,
        },
    },
    ["DRUID_RESTORATION_RAID"] = {
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MzMzYWGmZmxixCzAAAAAAAAAAglBNbmx0MDDmlxMzMMMDAAAAADAgBstM2w0MzyAAAEwCzMzgZGY0MAYmBAA",
            ["n"] = 3,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2mZMNzYgZZmZmZYYmBAAAAwAAAYbbshpZmlBAwsMzSz2Mb2YMzDAzA0MAYmZmBgB",
            ["n"] = 2,
        },
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MmZGz2wDYmZYswMAAAAAAAAAAYZQzmZMNzAjZbmZmZYYGAAAAAAAAAABAAMbzs0sNzmNmZmBzMANDAwMDAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AwshNbzAAAAAAAAAAgFDNbzMmmBwsMzMzMLGYAAAAAMAgZGAACAAY2mZrZbmFbMm5BGmZ2MoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MzMzY2GmZmxixCzAAAAAAAAAAglBNbzMmmZAmlxMzMMMDAAAAADAgBstM2w0MzyAAYWmZrZbmNLMzMDmZgRzAgZmZGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MmZGzywMzMzixCzAAAAAAAAAAglBNbmx0MDDmlxMzMMMDAAAAADAgBstM2w0MzyAAAEwCzMzgZGY0MAYmBAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2mZMNzYgZbmZmZYYmBAAAAwAAAYbbshpZmlBAwsMzWz2Mb2YMzDAzA0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2MjpZGDMLzMzMjZYmBAAAAAAAAbbjNMNzsMAAmlZWa2mZzGjZegBzA0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthHgZmNjtxMAAAAAAAAAAYZQzmZMNzYgZZmZmZMDzMAAAAAAAAYbbshpZmlBAwsMzSz2Mb2YMzDMYGgmBAzMzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbzQzGjpZGDMLmZmZYYmBAAAAwAAAAABAAMbzs0sNzmNGz8ADmZB0MAAzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGaWGjpZGgZZmZmZYYGAAAAAGAAAAIAAgZbmlmtZ2sxMzMDmBoZAAmZAYA",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DESTRUCTION_MYTHICPLUS"] = {
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmlZmZmFjZbxDMAAYGjZmZxGMwsY0YGAzWsxAAAjBGbAAzMYMjZsBAAYmZGAAGDD",
            ["n"] = 2,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+ixDMzoZzM2mZmZWmtZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDLzWjFGAAYMDDAwMzMDGzYmZDAAwMzMAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZMzMzsMLzMzMLmZ2WYAAwMGzMziFYgZxoxMAmtYjBAAGDG2AAmZgZGjBAAgZmZAAYMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzMzysYmZmFjxiZAAwMzYmZWsADMLGNmBwsFbMAAwYgxGAwMDMzYMAAAMzMDAAjhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjhZmxsMLzMzMLmZ2W8ADAAmxYmZWsADMLGNmBwsFbMAAwYA2AAmZwMzYMAAAMzMzAAYMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMz2MzYWmtZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDLzWjFGAAYMYYDAzMzMYMjZsBAAYmZGAAYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzDMzoZzM2mZGzmtZmZmFzMLLjBAAzYMzMbgxMGWIDsNsQjFGAAYMDDAwMDw4BGzMbAAAmZmZAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzMzysZmZmFzMLLjBAAzYMzMLgxMGWIDsNsQjFGAAYMYAAmZAGzYGbAAAmZmBAAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmlZmZmFjZbxDMAAYmZMzMbWgBmFjGzAY2iNGAAYMAbAAzMYMjZsBAAYmZGAAGDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2mZGzysZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDbzWjFGAAYMYAAmZmZwYGzYDAAwMzMAAYGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWmNzMzsYmZZZMAAYGjZmZBMmxwCZgthFaswAAAjBDAwMDwYGzMbAAAmZmBAAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2mZGzysZmZmFzMLLzDMAAYGjZmZBMmxwCZgthFaswAAAjBDAwMDwYGjZDAAwMzMAA4BGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMjZmZmlZZmZmZxMzyyYAAwMGzMzmNMzMmZZZ0Mzw2wys1YhBAAGDG2AwMzMDmZGGbAAAmZmBAAGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZxM2MzMzysMzMzsYMLLegBAAzMjZmZxCmZGzssMamZYbYZ2asxAAAjBYDAzMzMYMjxAAAwMzMAAMGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmlZmZmFjZbxMAAYGjZmZxGMwsY0YGAzWsxAAAjBYDAYmBjZMjNAAAzMzAAwYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+iZmZmpZzM2mZGz2sMzMzsYMLLmBAAzYMzML2gBmFjGzAY2iNGAAYMAbAAzMgZMGAAAmZmZAAMGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMMzMmtZZmZmZxMz2CDAAmZGzMziNYgZxoxMAmtYjBAAGDwGAwMDmZGzMbAAAmZmBAgxwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMMzoZxMzyMzYWmtZGzsYGLLjBAAzYMzMLWwMzYmltRzMDbDLzWjFGAAYMDDbAYmZmBjZMzsBAAYmZGAAGDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlZZmZmZxY2WMDAAmxYmZWsADMLGNmBwsFbMAAwYA2AAmZwMzYMAAAMzMDAAjhB",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DESTRUCTION_RAID"] = {
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlZZmZmZxMz2CDAAmxYmZWsADMLGNmBwsFbMAAwYwwGAwMDmZGMAAAMzMzAAYMM",
            ["n"] = 2,
        },
        {
            ["code"] = "CsQAYIOwXTfhprvln24ZeRPDbMbGzYmZmRMbGGzmZmhZb2MGYWMbssMzMAAAAgZmZZZmZZYBGYWMaMDIzWshBAAAAAAwMzMGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbM2mZGzysMzMzsYmZbhBAAzYMzMLWgBmFjGzAY2iNGAAYMYYDAYmBmZMGAAAmZmBAgxwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjhZmZmlZZmZmZxMz2iHYAAwMGzMziFYgZxoxMAmtYjBAAGDwGAwMDMzYMAAAMzMzAAYMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMjZmZmlZZmZmZxMzyyYAAwMGzMzmNMzMmZZZ0Mzw2wys1YhBAAGDG2AwMzMDmZGGbAAAmZmBAAGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAA81jxQD71lYhS/t8p6HgAAmZmZmZEzmBmtZmZY2mNzwMzsY2MWMzAAAAAzMDLzMzMgxMGWIDsNahGLYAAAAAAAMmZmBAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+ixDMzoZzM2mZmZWmtZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDLzWjFGAAYMDDAwMzMDGzYmZDAAwMzMAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZMzMzsMLzMzMLmZ2WYAAwMGzMziFYgZxoxMAmtYjBAAGDG2AAmZgZGjBAAgZmZAAYMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzMzysYmZmFjxiZAAwMzYmZWsADMLGNmBwsFbMAAwYgxGAwMDMzYMAAAMzMDAAjhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjhZmxsMLzMzMLmZ2W8ADAAmxYmZWsADMLGNmBwsFbMAAwYA2AAmZwMzYMAAAMzMzAAYMM",
            ["n"] = 1,
        },
    },
    ["PRIEST_HOLY_MYTHICPLUS"] = {
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzAYmaAgZ2MTmNDAMGsZmZWA0MmZMGmZ2WGgBMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMbYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmx2MmZAMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgxMmlxMjZGjZGYbmZmBAAAwwsMzYmZmx2MmZAMTBwMLYIMmtBYMwixMLAaGz8AGDmBYmZAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZm5BmlxYMzYYGGLzMzMAAAAGmlZGzMzMYMzgNMTBwMLYIMmlBYMwixMLAaGz8AGDmBYmZGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmhZMzgNMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmxmxMD2wMFAzshhwYWGgxALGzsAoZMzYMYGgZmBMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTNAmZBDhxsMAjBWMzMLAaGmxYwMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzAbzMzMAAAAGzsMDmZmx2MmZAMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAghZmlxMjZGjZGYZmZmBAAAwwsMzYmZmh5BMzAYmCgZWwQYMbDwYgFjZWA0MmZMGMDwMzMwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMMzsMmZMzYMzALzMzMAAAAGzsMDmZmhZMzYAzUAMzCGCjZbAGDsY8AzCgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZmxsMmZMzYYGYZmZmBAAAwwsMDmZmx2MmZYBmpAYmlZ2mZysNzsNAzMDWMzMLAaGzMGDmZbZwMzAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZmxsMmZMzYYGYZmZmBAAAwwsMDzMzM2mxMDgZKAmZBDhxsMAjBWMzMLAaGmxYwMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMzYmZmx2MmZAMTBwMLzsMzkZbmZZAmZGsYMzCgmhhxgZAmZmBGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYzwMjhZMzYGzMGLzMzMAAAAGzsMDmZmBjZGshZqBwMLzsMzkZbmZZAmZGsYmZAoZMzDYMYGgZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
    },
    ["PRIEST_HOLY_RAID"] = {
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzAYmaAgZ2MTmNDAMGsZmZWA0MmZMGmZ2WGgBMA",
            ["n"] = 6,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMbYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzYAzUAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwMsMDzMzMYGzAYmaAgZWMTmFDAMGsZmZWA0MMjxwMz2yAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmx2MmZAMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
    },
    ["MAGE_FIRE_MYTHICPLUS"] = {
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsNAMzQYMgZYMA",
            ["n"] = 3,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMjZAAgZMmZmZMzsMAMzQGjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzsgZGZmxAAAwMLzYGLzyMz0sttMDAwmZmx2MzMzYDAAAAALmZmZGAAMjxMzMjZmFgZmZGyYMDMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzgZZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYBAAAAALmZmZAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMmBAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMzMDAAMjxMzMjZmlBgZGaYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwMLzMzsgZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsNAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYBAAAAAbmZmZAAgZMmZmZMzsNAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMzMDAAMjxMzMjZmlBgZGCjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFbmZkZMDAAADAYmZaW2WmBAYzMzYbmZmZsAAAAAgFzMzMAAwMGzMzMmZWGAmZIjxAmhxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzAAAwAAmZmmlllZAA2MzM2mZmZGbAAAAAYxMzMzDAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlllZAA2MzM2GzMzAAAAAA2MzMzMAAYMjZMzMzMbDAzMEGjBGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMGAAAGAwMz0sssMDAwmZmx2YmZGLAAAAAYxMzMDAAMmxMMzMzsNAMzQGjxgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
    },
    ["MAGE_FIRE_RAID"] = {
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFmZGZmxAAAwAAmZmmlllZAA2MzM2GzMzYDAAAAALmZmZAAgxMmxMzMzsAgZGCjxgZYMA",
            ["n"] = 2,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzgZZmZmFmZGZmxAAAwAAmZmmlllZAA2MzM2GzMzYDAAAAALmZmZAAgxMmxMzMzsAgZGyYMGMDDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwYBAzMTzyyyMAAbmZGbzMzMDAAAAAYxMzMDAAMjxMzMjZmtBgZGyYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMzMDAAMjxMzMjZmlBgZGCjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAJHMkDNl9e4q1zfgySSx9jbGGbWwMzMzs4BYMzw0YMmZAAAAAAMzyMNzsMLQAAQWMmhZGzMzMzsYMzYGYmlZwswAAAAAAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMjZAAgZMmZmZMzsMAMzQGjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzsgZGZmxAAAwMLzYGLzyMz0sttMDAwmZmx2MzMzYDAAAAALmZmZGAAMjxMzMjZmFgZmZGyYMDMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzgZZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYBAAAAALmZmZAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMmBAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMzMDAAMjxMzMjZmlBgZGaYMgZYMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_BLOOD_MYTHICPLUS"] = {
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZxMjZmxAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZZmZmmZZmZMzMAAAAAGMzMzMjZmZMAYmZmZGAAgZmtxwYGLLNW2WGmsNMsAYGDAAmZmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMLzMz0MLGjZmxAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzwMmZmhZbmZmmZxMjxMmBAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDktBsBYGzAAAmZwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmxgZbmZmmZZmZMzMGAAAAwMMzMzMjZGDAYmZmZGAAgZmtxwYGLLNW2WGmsNMsBYGDAAmZmZAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMbzMz0MLmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMGMbzMz0MLzMjxMGAAAAwMMzMzMzYmZMAYmZmZGAAgZmtxwYGLLNW2WGmsMMsAYGDAAmZmZwYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMGMbjZmmZZmZMzMGAAAAwMMzMzMjZGDAYmZmZGAAgZmtxwYGLLNWWWGmsNMsBYGDAAmZmZAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmZMbzMz0MLmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZZGjZmxAAAAAmhZmZmZMzYAAzMzMzAAAMzsNGGzYRjltlhJbDDbAmxAAgZmZGAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZZMz0MLzYMzMGAAAAwgZmZmZMzMjBAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZxYmZmxAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMbzMz0MbmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZZmZmmZxMjZmxAAAAAmhZmZmZMzYAAzMzMzAAAMzsNGGzYZpxy22wkthhNAzYAAwMzMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMbzMz0MLmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAMzsNGGzYZpxy2ywkthhNAzYAAwMzMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMjhZbmZmmZxYmxMGAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLbgsNgNAzYGAAwMDmhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZxMjZmBAAAAwMMzMzMjZGDAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyYmxMmZmhZbmZmmZzMjhxMAAAAwYmZmZmZMzYMAwMzMzAAAMzsNGGzYZpxyy2wkthhlBYGGAAmZmZAMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_BLOOD_RAID"] = {
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMLzMz0MLmZMmBAAAAYGzMzMzMjZGjBAmZmZGAAgZmtxwYGbLNW2WGmsMMsAYGGAAmZmZwMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZxMjZmBAAAAwMMzMzMjZGDAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyYmxMmZMMbzMz0MbmZMmxMAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLLgsNgNAzwAAAmZghB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAclESCN5uIs3wGGVadXqL3xwMzMDzYmZGmxMzMNzYYmxMGAAAAYmZmZmZGzmZmxAAAYmZmBAAAYgBmxoxyGILDYDgZwGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyYmxMmZmhZbmZmmZzMjhxMAAAAwYmZmZmZMzYMAwMzMzAAAMzsNGGzYZpxyy2wkthhlBYGGAAmZmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMbzMz0MLmZmxMAAAAAmZmZmZmZYGDAYmZmZmBAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMbzMz0MLmZMMmBAAAAmZmZmZmZYmZAAzMzMzAAAYgBmxiGLbgsNgNAzwAAAmZwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMbzMz0MLmZMmBAAAAwYmZmZmZMzYMAYmZmZGAAgZmtxwYGLLNW22GmsMMsAYGGAAmZmZwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMbzMz0MLmZmxMAAAAAmhZmZmZmHYmZAAjZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzwMmZmhZbmZmmZxMzMmxAAAAAmZmZmZmZ8AzYAAzMzMzAAAMzsNGGzYZpxy22wkthhNAzwAAwMzMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWmZGmxMzMMbjZmmZzMzMzMAAAAAmZmZmZmZYGDAYmZmZmBAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZZmZmmZZmZMzMAAAAAGMzMzMjZmZMAYmZmZGAAgZmtxwYGLLNW2WGmsNMsAYGDAAmZmZAMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_FROST_MYTHICPLUS"] = {
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 2,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMGDz2MzMzMLzY0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZYYWmZmZmZbGjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjZY2mZmZmZzY0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbziZZGGLMsMz20QzYBzMmZGYAYYmBzMGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMzMDY2mZmZmZZmZmmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZzMjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjBz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbWMLzwYhhlZ2mGaGLYmxMzADADzMYmBYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxMDz2MzMzMbzYkZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MbzwYhhlZWmGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMDjxYY2mZmZmZbmZkZMzYYmxgZmZmZmZmZAAAAAAAAAYMbziZbGGLMsMz20QzYBzMmZGYAYYmBzMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZAzyMzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDYWmZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MLzwYhhlZ2mGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZYYWmZmZmZbGjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MLzwYhhlZ2mGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbWMLzwYhhlZ2mGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMzYY2mZmZmZzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAzAD",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_FROST_RAID"] = {
        {
            ["code"] = "CsPAclESCN5uIs3wGGVadXqL3NDwMzYGjxYZYmZmZmxMGZGjxwMDwMzMzMzMzAAAAAAAAAAAgxy2sZWmhxCDLzsNN0MWwMzMzMDMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMGDz2MzMzMLzY0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZYYWmZmZmZbGjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjZY2mZmZmZzY0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbziZZGGLMsMz20QzYBzMmZGYAYYmBzMGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMzMDY2mZmZmZZmZmmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZzMjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjBz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbWMLzwYhhlZ2mGaGLYmxMzADADzMYmBYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxMDz2MzMzMbzYkZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MbzwYhhlZWmGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMDjxYY2mZmZmZbmZkZMzYYmxgZmZmZmZmZAAAAAAAAAYMbziZbGGLMsMz20QzYBzMmZGYAYYmBzMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZAzyMzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDYWmZmZmZbmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MLzwYhhlZ2mGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
    },
    ["ROGUE_OUTLAW_MYTHICPLUS"] = {
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 2,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGmZbaZw2MAAAAAgZbZMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw2yMzMMzMzsYmZ2GAAAAzMDAGzihhMwswCtwGAmZwAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBMY2mFzMzoZmNmFW2mWYjBYmZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBMY2mFzMzoZmNmNW2mWYjBYmZmZgHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAMjBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYZZmZGmZMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGmZbaZw2MAAAAAAbLzMzwMzMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMmZmtZmZmZMmN4BmZZaZw2MAAAAAALbzMzwMzMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAMbLzMzwMjZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZMzsNzMzMzMzsBmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYMgBz2sYmZGNzsxswy20CbMAzMzMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAgZMAYMLGGyAzCL0CbAYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMDzsNzMzMjxss4BYmtplBbzAAAAAAstMzMDzMzMLmZmlBAAAgxAgxsYYIDMLsQLsxAMzgBmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
    },
    ["ROGUE_OUTLAW_RAID"] = {
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZmZmtZmZmZMmNeAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQAA0tw2gAD7pPTLoW5IGZDeAAMwwYmZwMzwMMMzMzMjZmplZMLzAAAAAAgttxM8AzMjFmZZ2GAAAAzMDwAbwwoBA2mwiZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZMzsNzMzMzMzsBmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYMgBz2sYmZGNzsxswy20CbMAzMzMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGmZbaZw2MAAAAAgZbZMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw2yMzMMzMzsYmZ2GAAAAzMDAGzihhMwswCtwGAmZwAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBMY2mFzMzoZmNmFW2mWYjBYmZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAMjBMY2mFzMzoZmNmNW2mWYjBYmZmZgHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_ELEMENTAL_MYTHICPLUS"] = {
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZmtxyMzMjhFLzMLDjZmFAgBAmZMMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYmllZajZGjlZMzYmhlZmlhxMzCAwAAzMGGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZGjlZmZGDLzyMzywYmZBAYAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZmtxyMPwMjxsYZmZZYMzsAAMAwMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZmtxyMzMjhFLzMLDjZmFAgBAmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZGjlZmZGDLWmZWGGzMLAAzAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYssYajZmtxyMmZMmFLzMLDjZmFAgZAwMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsthBMgZzMN0MLAwsMzMjx2ipFmZMWmZmZMjFLzMLDjZmFAgBgZmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzmZCNzCAMbzMzYstYajZmtxyMzMjhFLzMLDjZmFAgBAzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMbzMzYstYajZGjlZmZGjZxyMzywYmZBAYAMzMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMmZmZZbZMMjBAAAAsYmNYADY2YCZWAgZZmZGjtFTLMzYsMzMzYYZWmxiZGmZZAADAMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMbzMzYstZaBzYsMjZmZMLWmZWGGzMLAAzAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGzstMTLmZmNWmxMjBWmxiZGmZZAgZAMzMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMLzMzYmtlZiZmZjlZMzYwsMzsMMmZWAAzAYmZmxwwA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_ELEMENTAL_RAID"] = {
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZZZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZGLzMjZmFAwMAmZmZMMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZmZZGjZmFAwMAmZmZMMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAmZZZAwyCDAAAAAAAAAgQAAAAIAAAAAAAAAAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCZWAgZZmZGjtFTYmZbsMzMzYMLWmxyMzYmZBAYAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMWWMtxMz2YZmHYmxYWsMzsMMmZWAAGAYmxwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGzstMTLmZmNWmxMjBWmxiZGmZZAgZAMzMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMLzMzYmtlZiZmZjlZMzYwsMzsMMmZWAAzAYmZmxwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZGLmZMzsAAmBwMzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZGLmZYmlBAmBwMzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZZZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZmZZGjZmFAwMAmZmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYahZGjlZmZGzYxyMzywYmZBAYAgZGDDD",
            ["n"] = 1,
        },
    },
    ["WARLOCK_AFFLICTION_MYTHICPLUS"] = {
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAYmZZWmZmlxAAzy2yYYMLmpxMzwWmFG2GAAAmBAAmZmZMzwMYGmZmZmxgZmZGAwMwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmNGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzDMzoZjx2MzYWGAAgZmlZZmZWGDAMLLLjhxsYmGzMDbZWYYbAAAYGAAYmZmZMjZGMDzMzMzYwMzMDAYGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNLmx2MzYWGAAwMzsMLzMz2YAgx2yADYCmhtADbDAAAzAAAYmZMzwsxYGjZmZYYmZmBAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmFGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzmZmZWGAAwMzsMLmZ2GDAM2WGYATwMsFYYbAAAYGAAAzMjZMjtxYGjZmZGDzMzAAMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2mZGzyAAAmxsMLmZ2GDAMbbbjhxsYmGzMDbZ2YYbAAAYAAAYmhZYsNGzMjZmZMDzMzMAgBMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGQmFwyAAAwMAAwMDmZGjZzMDzMmZGDmZmBAYGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmx2MzYWGAAgZmlZZmZWGDAM2WGYATwMsFYYbAAAYGAAAzMzMjZGjhxMzMzMGmZmBAYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZmZWGAAwMmlZZmZWGDAYBGYWMaMDIzCYZAAAYAAAzMYMjxsxwMzYmZMDzMzAAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzoZhhZmZmlBAAYmZZ2mZmFzAAjtlBGwEMDbBG2GAAAmBAAwMjZmZMYGmZmZGzgZmZAAGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNLmxyMzYWGAAwMzsMLzMzyYAgx2yADYCmhtADbDAAAzAAAYmZMzwsxwYmZmZYYmZmBAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAysBWGAAAmBAAmZgZmZMMzwMjZmxgZmZAAmBG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMzsYZmZWGDAM22GYATwMsFYYbAAAYGAAAzMjZMzsBmZmZmxMDzMzAAMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzoZhhZmZmlBAAYmZZWmZmlxAAjllBGwEMDbBG2GAAAmBAAwMDzMmBzwMzMzMGMzMzAAmBG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZmZWGAAgZmlZZmZWGDAMLbbjhxsYmGzMDbZWYYZAAAYGAAYmZmZmZMGmZYmxMzYwMzMAAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZGz2AAAmZmlZxMzyYAgx2yADYCmhlADbDAAAzAAAYmZmZMzYMmxYmZmxwMzMAADYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+amZMzoZzM2mZGz2AAAmZmlZZmZ2GDAM22GYATwMsFYYbAAAwAAAYmZMDzsNzYGjZmZYYmZGAgBMA",
            ["n"] = 1,
        },
    },
    ["WARLOCK_AFFLICTION_RAID"] = {
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAYmZZWmZmlxAAzy2yYYMLmpxMzwWmFG2GAAAmBAAmZmZMzwMYGmZmZmxgZmZGAwMwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAysBWGAAAmBAAmZgZmZMMzwMjZmxgZmZAAmBG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAYIOwXTfhprvln24ZeRPDbAmZmZmZEzmhxsZmZY2GAAAwMzMzyMjxyMzMLmxMDAYGLwAziRjZAZWCWmBAAAAAAAAzwCA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAYIOwXTfhprvln24ZeRPDbghZmZmZEzmhxsZmZY2GAAAwMjZWmZegx2MzMLmxMDAYGbwAziRjZAZWCWmBAAAAAAAAzwCA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmNGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzDMzoZjx2MzYWGAAgZmlZZmZWGDAMLLLjhxsYmGzMDbZWYYbAAAYGAAYmZmZMjZGMDzMzMzYwMzMDAYGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNLmx2MzYWGAAwMzsMLzMz2YAgx2yADYCmhtADbDAAAzAAAYmZMzwsxYGjZmZYYmZmBAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmFGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzmZmZWGAAwMzsMLmZ2GDAM2WGYATwMsFYYbAAAYGAAAzMjZMjtxYGjZmZGDzMzAAMgB",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DEMONOLOGY_MYTHICPLUS"] = {
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmx2MzMz2AAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmxMDmZGzYmZDAAMmZMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzYWGAAAAAAgx2yMmZGWMMMz2s1CNjFjZGLzyMzMmBAmZMzMmZwMzYGzYBAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzY2GAAAAAAgx2yMmZGWMMMz2s1CNjFjZGLz2MzMmBAmZMzMmZwMzMzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmxsMAAAAAAAgxMGWgB2GtQDLGzMWmlZmZMDAMzYmZMzAMzMmZAAAGzMzYYYZGDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2MzYWGAAAAAAAwYGDLwAbjWohFjZGLz2MzMmBAmZMzMmZAGzwYDAAMmZmZGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmZ2mZGzyAAAAAAAM22mxMzwihhZ2mtWoZsYMzYZ2mZmxMAwMjZmxMDmZGzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+ixDMzoZzMz2MzMz2AAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmxMDmZGzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzMz2AAAAAAAAGzYYBGYb0CNsYMzYZ2mZmxMAwMjZmxMDwYGGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZ2mZmxMAwMjZmxMDwYGGbAAgxMzMzwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+ixMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDwMzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmx2MzY2GAAAAAAAwYGDLwAbjWohFjZGLzyMzMmBAmZMzMmZAGzwMbAAgxMzMzwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbjZMzMmlBAAAAAAAMmxwCMw2oFaYxYmxysMzMjZAgZGzMjZGgZmxMAAAGzMzYYYZGDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmZ2mZmZ2GAAAAAAAwYGDLwAbjWohFjZGLz2MzMmBAmZMzMmZAGzYGLAAgxMjxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzMzyAAAAAAAAGzYYBGYb0GNsYMzYZ2mZmxMAwMjZmxMDwYGzYDAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMMzoZzM2mZmZ2GAAAAAAAwYGDLwAbjWohFjZGLz2MzMmBAmZMzMmZAGzYmZBAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAAAAAYstMjZmhFDDzsNbtRzYxYmxysMzMjZAgZGzMjZGMzYmhZAAAGzMzMDDLzYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amxMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlBAAAAAAYstMjZmhFDDzsNbtQzYxYmxysMzMjZAgZGzMjZGMzYmhZ2AAAjZmZMMsMjBMA",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DEMONOLOGY_RAID"] = {
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amxMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 3,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amZmZmpZjx2MzMzyAAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmZmZwMzwMMAAAjZmxMglZMgB",
            ["n"] = 3,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAAAAAYstMjZmhFDDzsNbtRzYxYmxysMzMjZAgZGzMjZGMzYmhZAAAGzMzMDDLzYAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMz2MzMzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDAzYmBAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjhZmxsMAAAAAAAgxMGWgB2GtQDLGzMWmlZmZMDAMzYMzMzAMzMmZAAAGzMzYYYZGDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZMzMmlBAAAAAAAMmxwCMw2oFaYxYmxysMzMjZAgZGjZmZGAzMmBAAwYmZmZYYZGDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjxMzMDwMzYmBAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amZmZmpZjx2MzMzyAAAAAAAM2WmxMzwihhZWmtWoZsZMzYZMzMmZAgZmZGzMzgZmhZYAAAGzMjZMYZmBYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlBAAAAAAYstMjZmhFDDzsNbtQzYxYmxysMzMjZAgZGzMjZGMzYmhZ2AAAjZmZMMsMjBMA",
            ["n"] = 1,
        },
    },
    ["MONK_WINDWALKER_MYTHICPLUS"] = {
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAswsNmxYmZgAYxMLzyYaWmlmZmZBYGDMzMDwYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzAGwYGmZmZY2GmhZZmAAWMz2MzYMzMQAsYmlZZMNLzSzMzsAYMwMzMAjlBwMzs5CA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMgZmhZmZGmNMDziJAgFmtxMGzMDEALmZZWGTQAAzMDgZAYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAswsxMmZmZgAYxMLz2YCCAYGDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNmZwyMBAswsxMmZmZgAYxMLz2YCCAYGDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNMDzyMBAswsxMmZmZgAYxMLz2YCCAYmZAMDALDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMMMzMzwshZYWmJAgFmNmxMzMDEALmZZWGTzys0MzMLAzMDMzMDwYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNmZYWmJAgFmNmxMzMDEALmZZ2GTQAAzYAMDALDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAGmxMzMDz2wMMLzEAwiZ2mZGjZmBCgNzsMLjpZZWamZmFAMwMzMAjlZAmZmNfA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mxAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDzyMBAswsNmxMzMDEALmZZWGTQAAGDgZAYZAMzMb+A",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2wMMLPwEAwiZ2GzYmZmBCgFzsMLjpZZWamZmFAjBmZmBYsMAmZmNXA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMGMMMzMzwshZYWmJAgFmNmxMzMDEALmZZ2GTQAAzYAMDwYZMgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmx2MAAAAAAAAAAAALDjwMMMgZMjZmZGmNMDzyMBAsYmtxMmZmZgAYxMLzyYCCAwMDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwwMmZmZY2YmhZxEAwiZ2mZGjZmBCgFzsMbjJIAAjBwMAjlZAmZmNPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mxAAAAAAAAAAAAbDjmxMMMgZMMzMzwsNMDWmJAgFmtxMmZmZgAYxMLzyYCCAwYAMDwYZAMzMb+A",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMGMjhZGzwshZYWmJAgFmNmxMzMDEALmZZ2GTQAAzMDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmx2MAAAAAAAAAAAALDz0MmhhBMMMzMzwsxMDWmJAgFmtxMmZmZgAYxMLz2YaWmlmZmZBYGDMzMDwYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMCzwwAmZGmZmZY2GmhZZmAAWMz2YGzMzMQAsYmlZbMBBAYMAmBYsMAmZmNXA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBWmxwMzMDz2wMMLmAAWMz2YGzMzMQAsYmlZZMNLzSzMzsAYMwMzMAjlBwMzs5DA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2ghZZmAAWMz2MDzMzMQAsBgmlZpZmZWAwAzMAMWGAD4DA",
            ["n"] = 1,
        },
    },
    ["MONK_WINDWALKER_RAID"] = {
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwMGmZmZY2GmhZZmAAWMz2YGzMzMQAsYmlZZMBBAgBwMAsMAmZmFXA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmBMwyMGmZmZY2GmhZZmAAWMz2YGzMzMQAsYmlZZMNbzSzMzsAYMwMzMAsMAmZmNfA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2wMsMzMbzAAAAAAAAAAAAsMMCzwwAbzMDzMzMMbDzwsMTAALmZbmxMmZGIA2MzysMmmlZpZmZ2AwAzMzAwyAYmZW8B",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgZGLzMz2MAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDzyMBAsYmtZmxMzMDEALmZZWGTzys0MzMbAGDMzMDALDgZmZzDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2ghZZmAAWMz2MDzMzMQAsBgmlZpZmZWAwAzMAMWGAD4DA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZYWmJAgFzsNmxMzMDEALmZZWGTzys0MzMbAGDMzMDALDgZmZzHA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGwAGzwMzMDz2wMMLzEAwiZ2GzYmZmBCgFzsMLjpZZWamZmFAjBmZmBglZAmZmFPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwMmxMzMDz2wMYZmAAWMz2YGzMzMQAsYmlZZMNLzSzMzsBYMwMzMAsMAmZmFPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mZAAAAAAAAAAAALDjmxMMMw2YmxMzMDz2wMMLmAAWY2YGzMzMQAsYmlZZMNLzSzMzsAYMwMzMAsMAmZmND",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GmhlZmZbGAAAAAAAAAAAglhRzYGwAmxMmZmZY2GmhZZmAAWMz2MzYmZmBCgFzsMLjpZZWamZmNAMwMzMAsMAmZmNPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2wgtZmZbGAAAAAAAAAAAglhRzYGGGwMGmZmZY2GmhZZmAAWMz2MzYMzMQAsZswYaWmlmZmZDADMzMDALDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAi6cZM+HWADeySjzG9Lwx8PzYMYMYbmZ2mxAAAAAAAAAAAALDzEmhhB2mZGmZmZYWwMMLmAAWMz2YYMzMQAsBgmlZpZmZWAGzAzMAMWGADYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAswsNmxYmZgAYxMLzyYaWmlmZmZBYGDMzMDwYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzAGwYGmZmZY2GmhZZmAAWMz2MzYMzMQAsYmlZZMNLzSzMzsAYMwMzMAjlBwMzs5CA",
            ["n"] = 1,
        },
    },
    ["DRUID_BALANCE_MYTHICPLUS"] = {
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBjZZmlZWYmxGLzsMmZM2wwAM22mZwY2GBmAAAAsYmZmZwmhxYAAYmBLDA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhhZMLzsMzCzM2YZmlxMjxGGGgx22MDGz2IwEAAAgFmZmZwmhxYAAYmBLDA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMjZsZWmxYmZGbYYAGgttxGmmZWGBAAAYzMzMzgNDjxAwMDAMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNMmZgxsYmZmBDGjZWmZxMzYjlZWGzMGLYYAGbbzMYMbjATAAAAWYmZmBbGzYMAAMzglBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYstMzstNz2sNTzMLzEAAAgNzMzMD2MwYGAzMYmBGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgxsYmZmZBMMmZZmFzMjNWmZZMmZsghBYstNzgxsNCMBAAAYhZmZGsZMjxMAAmZgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgxsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZEAAAgNmZmZwmBGzAYmBAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsMzMzMYYY2mZZsMMjNzyMLjZmhNMMADw22YDTzMLjAAAAsZmZmZwmhxYGAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMMYGjZWmZzMzYhlZWGjZGLYYAGbbzMLbzsNLz0MzyMBAAAYhZmZGsZMMmBwMDmZgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBjZZmlZWYmxGLzsMmZM2wwAM22mZwY2GBmAAAAswMzMD2MmxYAAYmBLDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYGz2MLjtZMjNzyMGzMzYDDDwAstN2w0MzyIAAAAbMzMzgNDjxAwMDAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsYmZmZhhZMmZZmFzMjNWmZZMmZsghBYstNzgxsNCMBAAAYhZmZGsZYMmBAwMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBjxMLzswMzswyMLjxMjNMMAjltZGMmtRgJAAAALmZmZGsZYMGAAmZwyA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzwYGLsMzyMjxMbYAwYbZmBjZbEYCAAAwCzMzMYzYGjZAAMzglBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMD8AmFzMzMLgZMmZZmFzMjNWmZZMmZsghBYstNzgxsNCMBAAAYhZmZGsZYMmBAwMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMMjtZWmxYmZGbYYAGbLzMbbzsMbz0MzyMBAAAYzMzMzgNDjxAwMDmZgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZEAAAgNzMzMD2MwYGAzMAwA",
            ["n"] = 1,
        },
    },
    ["DRUID_BALANCE_RAID"] = {
        {
            ["code"] = "CYGAkuH5GdQpDrgY32rlVGnyqBAAAAAAAAAAAAAAAAAAoGCzYGAAAwmZZmlZmlxMzMzsYMGmZshFAMW2mZbbbmlZZmmZWmpAAQAsBAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmZhxDYMLzsN2mxMz2YZGzMGmNMAYAW2GbYamZZEAAAgNzMzMD2MMGDAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLGzYhlZWGjZGbYYAGbLzMYMbjATAAAAWYmZmBbGzYMDAgZGsMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDzyYZmFzMzsxyMLjZmhNMMAjttZGMmlRgJAAAALmZmZGsZMjxAAwMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmZhBjZZmtx2MmZ2GLzYmxwshBADwy2YBTzMLjAAAAsZmZmZwmxMGDAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzsYmZmtxyMLjZGsgBAjltZGbzY2mJzsYCAAAwCzMzMYzYGjBgZGMzADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLGzYhlZWGjZGbYYAGbLzMYMbjATAAAAWMzMzMYzwYMDAgZGsMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWGlZpZMmZAmtZmZmZBYMLjlxywMz2MLzYmZmhNMAYssNzstNz2sMTzMLzEAAAgNzMzMD2MMGDAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMMjtZWmxYmZGbYYAGbLzMbbzsMbz0MzyMBAAAYzMzMzgNDjxAwMDmZgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZEAAAgNzMzMD2MwYGAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNMmZgxsYmZmBDGjZWmZxMzYjlZWGzMGLYYAGbbzMYMbjATAAAAWYmZmBbGzYMAAMzglBA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_HAVOC_MYTHICPLUS"] = {
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyALzmZMMLaaMzMmxGAAAwAAQAwMDGACAAM",
            ["n"] = 2,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmxYmMmZAAAAAAAzmxsNDzMwMWmZmZYmBzyMbzsMLzMzssNbTTzMzMmxGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmZGzkxMDAAAAAAY2MmtBzMwMWmZmZYmBzyALzmZMMLaaMzMmxGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMjZMzMzMmJjZGAAAAAAwsYMbjxMDMjlZmZGmZwsMDzysZGjtZZaaMzMG2AAAAGAACAmZwAQAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMzMzEmZAAAAAAAzyMzYGMDmZsMz8AzwMDmlBWmFzYY200YmZMsBAAAAAgAgZGMAEAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmxYmMmZAAAAAAAzixsNDzMz2MzYZmxMMzwMLzsNDGGbbMJjZGzYBAAAAAABYmBYAIAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzyMmZmZmZmMmZAAAAAAAzmxsNDjBzMWmZMDzMGzyALziZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMzyMmZmxYmMmZAAAAAAAzixsNDzMz2MzYZmxMMzwMLzsNDGGbbMJjZGzYBAAAAAABYmBYAIAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaAzMzmxMzMmZmMmZAAAAAAAzyMGzwMjlZmxyMzDMzsMzsMGDsMLmxwspphZGDbAAAAAAIAYmBDABAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmZGzkxMDAAAAAAY2MmtZYmBmxyMzMDzMYWGYZ2MjhZRTjZmxwGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmZGzkxMDAAAAAAYWMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iagZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxkMmZMjFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmZGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmhZGmZZmtZwwYZjJZMzYYBAAAAAABYmBYAIAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALziZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMDjZmZMmJjZGAAAAAAwsZMbzMmZwDMjlZmHYGmZwsMwysYGDzmmGzMjZsBAAAMAAEAMzgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iagZmZ2MmZmxMzkxMDAAAAAAY2egxsNDzMz2MzYZmxMWmZYmlZ2mBDjlNmkxMjhFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyYbmlZbmxYb200YmZMsBAAAAAgAgZGMAEAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALzmZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_HAVOC_RAID"] = {
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALzmZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 4,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZmZmZ2MmZmxMzkxMDAAAAAAYWegxsNDzMYmxyMjZYmBzyALzmZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 2,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmZmZmwMDAAAAAAY2MmtZYmBzMWmZegZYmBzyALziZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 2,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzixMzMzYmwMDAAAAAAY2MmtZGzMYmxyMjZYmxYWGYZWMjhZRTjZmxwGAAAAAACAmZwAQAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAEDLOxe3SEPP2R8Hw6bhoSYmZmZmZGMzMjxMhZGAAAAAAwsNMmZMzgZmtZbMmBzshlNYbWMjhZRTjxMzYwG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZmZmZ2mxMzMGzkxMDAAAAAAYWMmlZYmBmx2YmZGAWmZbmlZbmZmttZZaamZmxM2AAAAAAQAmZmZwAQAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyYbmlZbmxYb200YmZMsBAAAAAgAgZGMAEAAYA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_VENGEANCE_MYTHICPLUS"] = {
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmhZmMzMYYmZGYGzMmZmZmxgZmZsZmZbMMAAAAAAACYmZsBAAAgBmZmZmt2mZmBAAAAAYA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjhZkZmBWMjZwMjZGz8AzMzYYmZmx2YGjxMAAAAAAACYmZsBAAAgBmZmZml2mZmBAzAAAAYA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMzkZmxwyMzMDMjZmZMzMzYwwM2MzsNGzAAAAwsNDGGLLMhhZM2AAAAwgZmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMjZkZmBziZmZgZMzYGzMzYYmZmxmZmtxwAAAAwsMDGGLLMhhZmZ2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAmtZwwYZhJMMzM2AAAAwgZmZmZ2abmZGzMADAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjxMjZMjMzMGWmZmZgZMzYmZmZGDGmxmZmtxYGAAAAmtZwwYZhJMMzMzCAAAAGYmZmZWabmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMjMzMGWmZmZgZMzMjZmZGDGmxmZmtxYGAAAAmtZwwYZhJMMzM2AAAAwAzMzMzWbzMzYmBYAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmBWMzMDMjZmZMzMzYwMzM2MzsNGzAAAAAAAIgZmxGAAAAGYmZmZ2abmZGAAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjhZkZmZYWMzMjhZMzYGzMzYYGmx2DMzsNGGAAAAAAABMzM2AAAAwgZmZmZ2abmZGAYAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmxwyMzMDMjZGzMzMzYwwM2egZmlxwAAAAwsNDGGLLMhhZmxCAAAAGYmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjxMjZMjMzMGWmZmZgZMzYmZmZGDGmxmZmtxYGAAAAmtZwwYZhJMMzMzCAAAAGYAEgZGAAAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZmMzMwiZMDmZMzYmHYmZGDzMzM2YmtxwAAAAwsNDGGLLMhhZmZ2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMzkZmBziZMDmZMjZMzMzYwMzM2egZmtxwAAAAwsNDGGLLMhhZmxCAAAAGYmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMjMzMwiZMDmZMzYmZmZGDmZmxmZmtxYGAAAAAAABMzM2AAAAwAzMzMzWbzMzAADAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmBDzMzAzYmxMzMzMGMzMDmZWGDDAAAAAAgAmZmZDAAAADMzMzMbtNzMDAMAAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAmtZwwYbjJMMzM2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjxMjhZmMzMGjZmZGYGzMzYmZmxghZsZmZbMmBAAAAAAQAzYsBAAAgBzMzMzs12MzMAwAAAAYA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_VENGEANCE_RAID"] = {
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZmMzMYWMzMDmZMzYGzMzYwMzM2egZGjxMAAAAAAACYmhNAAAAMwMzMzs12MzMAAAAAAD",
            ["n"] = 3,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZmMzMYWMzMDmZMzYGzMzYwMzM2egZGjxMAAAAYbGMgNEwMDbAAAAYgZmZmZrtZmZAAAAAAG",
            ["n"] = 2,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjhZkZmBWMjZwMjZGz8AzMzYYmZmx2YGjxMAAAAAAACYmZsBAAAgBmZmZml2mZmBAzAAAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAEDLOxe3SEPP2R8Hw6bhoSAAGMzMjxMjMzMGDjZbmBjtZYmZGMzMjZGbjZMzgBAAAAYZWMjhZTTDMzMDbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMYWMjZgZMzYmZmZGDmZmx2DMzsMGAAAAwsNDGGbbMhhZmxGAAAAGYmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjZmZkZmZMWMzMDMjZGzMzMzYwwM2mZGjBAAAAAAACYmZsBAAAgBjZmZml2mZmBAGAAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMYWMjZgZMzYmZmZGDmZmx2DMzsNGAAAAwsNDGGbbMhhZmxGAAAAGYmZmZWabmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMYWMzMDMjZGzYmZGDzMzM2egZmtxAAAAAmtZwwYbjJMMzM2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMzkZmxwyMzMDMjZmZMzMzYwwM2MzsNGzAAAAwsNDGGLLMhhZM2AAAAwgZmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMjZkZmBziZmZgZMzYGzMzYYmZmxmZmtxwAAAAwsMDGGLLMhhZmZ2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmBziZmZgZMzYGzMzYYmZmxmZmtxAAAAAmtZwwYZhJMMzM2AAAAwgZmZmZ2abmZGzMADAAAgB",
            ["n"] = 1,
        },
    },
    ["EVOKER_DEVASTATION_MYTHICPLUS"] = {
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMwMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 2,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmBMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 2,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmZwMMjZaMzMNzM2mZmZmZmZmZGwMzAmZZmZgBMzM2glxs0YbmhJzkNw2wAzMGz4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZw4BMzwMwYGjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AyMBYDzgZGM8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGYMTzMzMNzMz2MzMzMzMzMzAmZmxYmZZmZgBGD2glxoxyAyMBYDzgZGM8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGYMTzMzMNzMz2MzMzMzMzMzAmZmZGzMLjZgBGD2glxox2AyMBYDzgZGM8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZgZYGmBMYMTjZmpZM2mxMzMzMzMzAmZmZGzMLzMDMwYwGsMGN2GQmJAbYgZGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZbmZgBGD2glxox2AyMBYDDMzghHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAgZMDGMzwMMmHAjZaMzMNzMz2MzMzMzMzMzAmZmxYmZZMDMwMzwGsMmlGbzMMZmsA2GGYmB4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAgZMDMDzwMwMYMTjZmpZM2mxMzMzMzMzAMzMGzMLzMDMwYwGsMGN2GQmJAbYgZGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGzYMTjZmpZmZ2mZmZmZmZmZGwMzMGzMLjZgBGD2glxox2AyMBYDzgZGM8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBzwYMTjZmpZmZ2mZmZmZmZmZGwMzMGzMmZGYgxgNYZMasNgMTA2wMYmBDPA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBmBjZaMzMNzMz2MzMzMzMzMzAmxMGzMLzMDMwMzwGsMmlGbzMMZmsA2GmBzMY4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzYmBzMYMTjZmpZMWmxMzMz8AzMzAmxYGzMLzMDMgZmxCsMmlGbzMMZmsB2GGYmxYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMDMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AyMBYDDMzghHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 1,
        },
    },
    ["EVOKER_DEVASTATION_RAID"] = {
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmZwMMjZaMzMNzM2mZmZmZmZmZGwMzAmZZmZgBMzM2glxs0YbmhJzkNw2wAzMGz4BA",
            ["n"] = 4,
        },
        {
            ["code"] = "CsbBV7//nP39x/JJympTqouKSAAAAAAAAAAAAGzMMzsYGMgBjZaGzMZMWGzMzw8AzsNDYGzsNmZWmZGMDMjZgNwSwMMhsAWGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZGzMGzwMjxMYMTjZmpZM2GzMzMzMzMzAmZGwMLzMDmBMzM2glxs0YbmhJzkNw2wAzMGz4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZgZYGzMgBjZamZmpZmx2MMzMzMzMzAmxMGzMLzMDMwMzM2glxs0YbmhJzkNw2wAzMGDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDmZYGmBmBjZamZmpZmx2MzMzMz8AzMzAmxMGzMLzMDMwMzM2glxs0YbmhJzkNw2wAzMGDPA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMwMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzYmZwMMjZaMzMNjx2MmZmZmHYmZGwMzAmZZmZgBMzMWglxs0YbmhJzkNw2wAzMGzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzwMgBjZamZmpZM2mxMzMz8AzMzAmZmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZgZYGzMDmhZMTjZmpZmx2MMzMzMzMzAmZGwMLzMDMgZmxGsMmlGbzMMZmsB2GGYmxYGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmBMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzYmBzMYMTjZmpZMWmxMzMz8AzMzAmxYGzMbzMDMgZmxCsMmlGbzMMZmsB2GGYmxYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZw4BMzwMwYGjZaMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AyMBYDzgZGM8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGYMTzMzMNzMz2MzMzMzMzMzAmZmxYmZZmZgBGD2glxoxyAyMBYDzgZGM8AA",
            ["n"] = 1,
        },
    },
    ["EVOKER_PRESERVATION_MYTHICPLUS"] = {
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MMzMbPADAAMzMjZYGzoxYAAAAmZmJzYm5BmlxMAYGzMmZZjFbMMzMTDNbwmhxMDmZYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmHYGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTzwMjZZMDAMmZMzyGL2YYmZmGa2MjNDzMzgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZGZGzMmtZmBAzYmxMbLsYjhZmZaoZzwmhBwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAeAzMDmZMDPwY2MMzMbDDAAMjZMjxYGhZAAAAmZmJDzMzsMzMAwYmxMbLsYhhZmZaoZzwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WGzYYMPwsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMzDMLjZAgxMwCYDMDTIbmxmhBwMDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmHYGDjxsZGw2wAAAzYGzYMMTMzMAAAgZmZaGzMjZZMDAMmZMzyGL2YYmZmGa2MjNDzMzgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGz2MMmZbYAAgZMj5BMzYGhZAAAAmZmJzYmxsMzMAYGzAbgFwMMhsZYzwAYmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BMGzIMDAAAwMzIzYmZmlZmBAzYGYDsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmZGDjxsZGw2wAAAmZGzgxMTmZmBAAAMzMTGzMjZZMDAMmZMzyGLWYYmZmGa2YsZYMzgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGz2MMmZbYAAgZMj5BMzYGhZAAAAmZGZmZmxsMzMAYGzMmZbjFLMMzMTDNbG2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwwMZmZGAAAwMzIzYmxsMzMAYGzMmZZjFLMMzMTDNbG2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzImZAAAAmZGZGzMmtZmBAzYGYBsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAYmZwMjZYGz2MMmZbYAAgZMjZwYGNmZAAAAmZGZGzMmlZmBAzYGYDsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZixMAAAgZmZyYmZmZZMDAMmZMzyGL2YYmZmGa2YsZYmZGMzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BMGzMhZGAAAwMzIzYmxsMzMAYGzAbgFwMMhsZYzwAYmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZswMGmZMbmBsNMAAwMmxMGDzEzMDAAAsNzMywMzMbzMDAMmBWAbgZYCZzM2MMAmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WGYYmZmNzA2GGAAYGGzMjhZaMzMAAAgZmZywMzMGzAAjZgFwGYGmQ2MjNDzAMzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAYmZwMjZYGzmhZmZbYAAgZMj5BwYGNmZAAAAmZmJzYmxsMzMAYGzALgFwMMhsZYzwAYmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjxYGhZAAAAmZGZGzMPwsMzMAYGzMmZZhFLMMzMTDNbwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZM4BmHY2MMzMbDDAAMjZMjxYmJMDAAAwMzIzwMzsMmBAzYmxMLLsYhhZmZaoZzwmhxMDmZGD",
            ["n"] = 1,
        },
    },
    ["EVOKER_PRESERVATION_RAID"] = {
        {
            ["code"] = "CwbBWYnbRY1EREkP8a0IbB+ZHAAAAAAYmZMbzgxMzYWwMbjZGAAgZMjBjxMjYmBAAAYmZmMz2MjZZm5BAwMmNYBsAmhJkB2MA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBV7//nP39x/JJympTqouKSAAAAAAYmZMLzgZMzYWwMbjZGAAAgBwIAAAAwMzMBAAAMGAwCYGmQWgNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjxYGhZAAAAmZGZGzMPwsMzMAYGzMmZZhFLMMzMTDNbwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZM4BmHY2MMzMbDDAAMjZMjxYmJMDAAAwMzIzwMzsMmBAzYmxMLLsYhhZmZaoZzwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYmZmlxMAYGzMmZZhFLMMzMTDNbG2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MMzMbPADAAMjZMjxwMhZGAAAwMzIzYm5BmlZmBAzYmxMLLsYhhZmZaoZD2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZM4BmHY2MMzMbDDAAMjZMDGmJzMzAAAAmZGZGzMmlZmBAzYGYDsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAYmZwMjZYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsMzMAYGzALgFwMMhsZYzwAYmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MMzMbPADAAMzMjZYGzoxYAAAAmZmJzYm5BmlxMAYGzMmZZjFbMMzMTDNbwmhxMDmZYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmHYGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTzwMjZZMDAMmZMzyGL2YYmZmGa2MjNDzMzgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WGzYYMzsZGw2YAAAzYmZmZMMTMzMAAAgZmZywMzDMLjZAgxMwCYDMDTIbM2MMAmZYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGZmZAAAAmZGZGzMmtZmBAzYmxMbLsYjhZmZaoZzwmhBwMzYA",
            ["n"] = 1,
        },
    },
    ["EVOKER_AUGMENTATION_MYTHICPLUS"] = {
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMzADGTNzMzMAAAAYGzMjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGmZMzGAAAAAMAAYmZgBjpGzMzAAAAgZMzMmZWGzMwMMwYGLsADMDDNiFMzYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpGzMzAAAAgZMzMmZWGzMwMMGmlZssMLDzsMMDzMNiFMGzMzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzMWmBzsMjZmxMAAAAAAAAwM8AmBjpGzMzAAAAAzMzMmZWGzMwMMGmlZssMLDzsMMDzMNiFMmZmZmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbMzMzyAzsMjZmxMAAAAAAAAwM8AzYGjpGzMzAAAAAzMjxMzyYmBmZbGDzyMWWmlhZWGmhZmGxCGzMzMzAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbmZGMDzMLzYmZMzGAAAAAAAAMMzAjpGzMzAAAAgZMzMPwMzyYmxwMMwYGLsADMDDNiFMmZmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMmZbmZGMDzMLzMzMjZ2AAAAAAAAwMDMMjpGzMzAAAAgZMjxMzyMzMwMMwYGLsADMDDNiFMGzMADG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZAAAAAAAAwMDjZwYqxMzMAAAAYGzYMzsMmZgZMDMmxCLwAzwQjYBjxMDAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAgBAAmZgBjpGzMzAAAAgZMzMmZ2GzMwMMGmlZsYWGMbDzwMTjYBjZmZMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrxMzMbzMzMWGYGzYMjZ2AAAAAAAAYmBmhZM1YmZGAAAAMjZMmZWGzMwMmxwsMjllZZYmthZYmpRsgZmZmZmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAgBAAzMDMYM1YmZGAAAAMjZmxMzyYmBmZzAjZswCMwMM0IWwMjZGAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNiFMGzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAAAAwMDMMzM1YmZGAAAAMjZMmZWGzMwMLGYMjFWgBmhhGxCmZMzAYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbmZGMYmZZmZmZMDAAAAAAAAzMzADGTNmZmBAAAAzYmZMzsMmZgZWmBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhxMbzMzgBzMLzMzMjZAAAAAAAAwMzADGTNzMzMAAAAYGzMjZmlxMjhZWmBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoRsgZGzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbmZGMYmZZmZmZMDAAAAAAAAMzADzYqxMzMAAAAYGzYMzsMzMDMzyMwYGLsADMDDNiFMGzMADG",
            ["n"] = 1,
        },
    },
    ["EVOKER_AUGMENTATION_RAID"] = {
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAAAAwMMmHAjpGzMzAAAAAzMzMmZWGzMwMbGDWglxwYZAMTEbYmZwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMbGYMjFWgBmhhGxCmZMzAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAgBAAzMDMYM1YmZGAAAAMjZmxMzyYmBmZzAjZswCMwMM0IWwMjZGAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNiFMGzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMzADGTNzMzMAAAAYGzMjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGmZMzGAAAAAMAAYmZgBjpGzMzAAAAgZMzMmZWGzMwMMwYGLsADMDDNiFMzYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpGzMzAAAAgZMzMmZWGzMwMMGmlZssMLDzsMMDzMNiFMGzMzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzMWmBzsMjZmxMAAAAAAAAwM8AmBjpGzMzAAAAAzMzMmZWGzMwMMGmlZssMLDzsMMDzMNiFMmZmZmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbMzMzyAzsMjZmxMAAAAAAAAwM8AzYGjpGzMzAAAAAzMjxMzyYmBmZbGDzyMWWmlhZWGmhZmGxCGzMzMzAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbmZGMDzMLzYmZMzGAAAAAAAAMMzAjpGzMzAAAAgZMzMPwMzyYmxwMMwYGLsADMDDNiFMmZmBAG",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_DEVOURER_MYTHICPLUS"] = {
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxwMAAAAAAAMmthZGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 3,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAMjZmZmxMjhZAAAAAAAWMmtxYGAAAAAAAAmxgZmZmZmZmZGzsYGjFtswMzMzWbzMzAYYAIgxgxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxYmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxwMAAAAAAAMmtxDYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAMjZmZmxMjhZAAAAAAAYMbjxMAAAAAAAAMjZYmZmZmZmZmxMLmxYRLLMzMzs12MzMAGGACYMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAMzMzMzMGjhZAAAAAAAYMbjxMAAAAAAAAMjZYegZmZmZmZGmZbmxYTWYmZmZrtZmZGgZMzMbzMTzyMLzMDzMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAgAGAjZmZbmZa2mZZmZMmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxwMAAAAAAAMmthZGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADjxyMz0sNzmxgxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMzMzMzMjBmBAAAAAAY5BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_DEVOURER_RAID"] = {
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMzMzMzMjBmBAAAAAAY5BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmZmZmZGjxwMAAAAAAALGz2gZAAAAAAAAYGzw8AzMzMzMzMMz2MjxmsAgAGgZMzMbzMTzyMLzMDzMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBG5bbocFKcv+yIq8fPd6ORBA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBG5bbocFKcv+yIq8fPd6ORBA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzMzMGmBAAAAAAgxsMYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwYYMagZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAgAGAjZmZbmZa2mZZmZMmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
    },
}
