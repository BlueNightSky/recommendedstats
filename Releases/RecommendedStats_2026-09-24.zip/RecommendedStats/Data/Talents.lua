-- GENERATED 2026-09-24 - do not hand-edit
RecommendedStatsData_Talents = {
    ["SHAMAN_ENHANCEMENT_MYTHICPLUS"] = {
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 3,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZxYDzsNzyMzMDjlxMAAzwYmhZCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZZGbMzYsMzMz8AGLMDAwMMmZMjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAzyMmxYZZGYmZbsMzMzMGYGAgZYMzwMBmZwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjZmNaW2GmhZ0gFAmlZMjxyyMWYmxYZmZm5BMWGzAAMDjZGGxMzMDGMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjlFjFmZ2GLzMzMMjxMAAzwYmxMiZmZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAzyMmZGLLzYjZmNWmZmZYYMDAwMMmZYmAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYmlZmZGGLjZAAmhxMDjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxMLLzYhZGsMjZmxYZMDAwMMmZMjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGLMzsNWmZmZYGMDAwMMmZMjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYsMzMzwMLjZAAmhxMDjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2WmxMz2mmlthZYmpBLAMLzYGjllZswMjxyMzMzYswMAAzwYmhRgZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMbzYGzssMjFzMzGLz8AzMPAzCzAAMDjZGGxMzMDGMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZZGbMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzsxyMzMDjlxMAAzwYmhZCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmZGLLGbMzsYWmZmZeAYMDAwMMmZYmAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjxstILGmhZ0gFAmlZMjxyyM2YmZjlZmZGGGzAAMDjZGzMBmZwgxA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_ENHANCEMENT_RAID"] = {
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjxstILGmhZ0gFAmlZMjxyyM2YmZjlZmZGGGzAAMDjZGzMBmZwgxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzsNWmZmZYsMmBAYGGzMMCMzgBjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjxstILGmhZ0gFAmlZMjxyyM2YmZjlZmZGGLMDAwMMmZMzEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjllZsxMzGLzMzMMMmBAYGGzMmZiZmZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZxYjZmNWmZmZGYMDAwMMmZMzEYmBDGDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZxYDzsNzyMzMDjlxMAAzwYmhZCMzgBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAzyMmxYZZGbMzYsMzMz8AGLMDAwMMmZMjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAzyMmxYZZGYmZbsMzMzMGYGAgZYMzwMBmZwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC2MjZmNaW2GmhZ0gFAmlZMjxyyMWYmxYZmZm5BMWGzAAMDjZGGxMzMDGMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2wC22mxMz2imlthZYmpBLAMLzYGjlFjFmZ2GLzMzMMjxMAAzwYmxMiZmZGMYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDLkFYGGawCAzyMmZGLLzYjZmNWmZmZYYMDAwMMmZYmAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxYZZGbMzYmlZmZGGLjZAAmhxMDjAzMYwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcQALMl7AwW51MWzGneuHE3tPOzMzgZmZmZmhZmZAAAAAAAAA2AsZGDbkFYGGawCAz2MmxMLLzYhZGsMjZmxYZMDAwMMmZMjAzMYwYA",
            ["n"] = 1,
        },
    },
    ["MONK_MISTWEAVER_MYTHICPLUS"] = {
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAgAsYbmtZbmBEAAjBYGwAsIjZA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAMbTbz2MLzitZ2mtZGQAAMmZGMDYAWkxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgB2mZZGbWMjZWWmxGmZmtHYmtllZGLMzEmBMYwYWmZmZY2GMMLmAAAAAIALWmZZ2mZABADAwMgxwYRGzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAAMMzyYWsNjZmtNDMDzmZ2WWmZswQzYGwghhxMzMDz2ghZZmAAAAAIAL2mZZ2mZABADGDwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgB2mZZMLz2MmZ22MwMMbMbLLzMWYMNjZADGwYmZmhZDzwsMTAAAAgZbab2mZZWsNz2sNzACAGMmZGMDYAWkxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAYmZmhZDzwsMTAAAAAEgFbzsMbzMgAgBjBYGwAsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZ22MwMMbmZzyMjFGTzYGwgBwMzMDzGmhZZmAAAAAIAL2mZb2mZABADGDwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgxwyMLjZx2MmZsYYZZGmtZmtllZGLMmmxMgBDgZmZGmNMDzyMBAAAAmlplhZZWsNzysNzACAGMMDMDYMwiMmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZ22MwMMbmZzyMjFGTzYGwYMbAzMzMMbYGmlZCAAAAgAsYbmtZbmBEAAjBYGwAsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAgAsYbmlZbmBEAAjBYGwAsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZADGwYmZmhZDzwsMTAAAAAEgFbzsNbzMgAAYMAzAGDsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgxwyMLjZx2MmZ22MwMMbmZzyMjFGTzYGwYMgxMzMDzGmhZZmAAAAAIAL2mZb2mZABAwYAmBMALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYGNjZADGAzMzMMbYGsMTAAAAAEgFbzsNbzMgAgBjBYGwYwsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZADGAzMzMMbYGmlZCAAAAgAsYbmtZbmBEAMYMAzAGDsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZZ2MmZ2WMghZbMbWmZswMaGzAGMbwsMzMzwsNGDWMBAAAAQAWsNz2sNzACAGwAMDYgxiMmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZ2WMwMMbmZzyMjFGTzYGwgBMmZmZY2wMMLzEAAAAABYx2Mbz2MDIAAGDwMgxALyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAMbTbz2MLzitZ2mtZGQAAMGgZADwiMmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswYaGzAGMYYZmZmhZbwwsYCAAAAgWGwilZWmtZGQAwAmZgZAjhxiMmBA",
            ["n"] = 1,
        },
    },
    ["MONK_MISTWEAVER_RAID"] = {
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswYaGzAGMALzMzMMbwws8ATAAAAAEgFLzsMbzMgAgBjBYGwYYsIjZA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW22mZswMaGzAGMYMmZmZY2GjBLmAAAAAIALWmZZ2mZABADYAmBMGGLyYGA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswYaGzAGMYYZmZmhZbwwsYCAAAAgWGwilZWmtZGQAwAmZgZAjhxiMmBA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghxyMLjZx2MmZsYmNMMbmZbZZmxCjpZMDYMGAzMzMMbwwsMTAAAAAEgFbzsMbzMgAgBjPAYGwYgFZMDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW2WmZswQzYGbYwghlZmZGmtBDziJAAAAAaZALWmZZ2mZABADYmBmBMGGLyYGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAghx2MwmFzYmllZshZmhZW22mZswYaGzAGMALzMzMMbwws8ATAAAAAEgFLzsMbzMgAgBjBYGwYYsIjZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgBWmZZML2mxMz2mBmhZzMbLLzMWYMNjZAjxAGzMzMMbYGmlZCAAAAMbTbz2MLzitZ2mtZGQAAMmZGMDYAWkxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4QAQnG51S19isUJoJoTeJ/IKDAAAAAAAgB2mZZGbWMjZWWmxGmZmtHYmtllZGLMzEmBMYwYWmZmZY2GMMLmAAAAAIALWmZZ2mZABADAwMgxwYRGzA",
            ["n"] = 1,
        },
    },
    ["PALADIN_PROTECTION_MYTHICPLUS"] = {
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZxMmZYmZrNAMwAGYDAAgAMzsst0yMjFLLMAwYGGDAmZAYmZAjN",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMDjZrNAMwAmBbAAAEgZmlllWmZsYZBDAYGGDAmZAwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyMzMzMzM2WGDLDGGAgBAAAAAANNzsNzYmhxs1GAGYAzgNAAACwMzy2SLzMWsthBAMzixAgZGAMzAGL",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZeAz2YmZmZmx2yYYZMLDDAwAAAAAAgmmZWmZMDmZ2aDADYgZwGAAYmptZmtZmZWWWaZmxilNMMwgZYMAYmZbGgZAGL",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZegZmZGLLjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02Mz2MzMLbLtMzYxyCzAYwMbYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxsMmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02MzyMzMLbLtMzYxyCzAYwMbYAwMz2MAzMgxC",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjHYrNAMwAGYDAAgAMzsst0yMjFLLMDgBzshBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamxMjZGGzWbAYgBMwGAAYmptZmlZmZW2WaZmxilFmBwgZYMAYmZZGgZGwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLMDgBzshBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWmHYmHYmZmZ2WGjZZYbGDAwAAAAAAgmmZMzYmZMmt2AwAADsBAAmZabmZbmZmlllWmZsYZDDgxYGGDAmZ2mBYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLbjxYWmlZMAADAAAAAAaamZZmxMYMbtBgBGwMYDAAMz02Mz2MzMLbLtMzYz2CGAwMbGDAmZ2mBYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLMDAYmNjBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamZZmxMY8AbtBgBGwMYDAAMz02Mz2MzMLbLtMzYxyCzAYwMMGAMzsMDwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLbjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLYAMYmNjBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjHYrNAMwAmBbAAgZm2mZWmZmZZbplZGLWWwAYwMMGAMzsNDwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGz8AzMzMzyyYMLjZZGDAwAAAAAAgmmZWmZMDm5B2aDADMgZwGAAABYmZZbplZGL2WYGAwMbYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLMDgBzYYAwMDAmZAjN",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMYYrNAMwAmBbAAgZmWmZ2mZmZZbplZGLWWYGAjxMbYAwMzyMAzMgxC",
            ["n"] = 1,
        },
    },
    ["PALADIN_PROTECTION_RAID"] = {
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxYWmlZMAADAAAAAAaamZZmxMzYYrNAMwAmBbAAgZm2mZ2mZmZZbplZGLWWwAgxMMGAMzsMDwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLzysNMAADAAAAAAaamxMjZwY2aDADMDMD2AAAzMtNzsMzMzy2SLzMWYjZAMzYYGDAmZWmBwAMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAgAMzsst0yMjFLLMDgBzshBAzMAYmBMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAm+0bA85vR0Yy+QcPHjtRvuZMMzyYZmZmZmx2MzMmZZMMAAADAAAAAAAJzMLGmBjhZLAwYAAmBbDAAwMTbzysNDQgNDMAMzYGGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjZrNAMwAGYDAAMz0mBzMzy2SLzMWsswMAYMDjBAzMAYGgxC",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLjZbYAAGAAAAAA00MziZMzMGPwWbAYgBMD2GAAYmptZmtZmZW2WaZmxilNmBwMjhhBAzMLzAYAGL",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyYGzMzMz2yYMLjZbYAAGAAAAAA00MjZGzgxs1GAGYGYGsBAAmZabmZZmZmltlWmZsYZjZAMzYYGDAmZWmBwAMWA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlhBAYAAAAAAQTzMmZMzwY2aDADYgZw2AAAzMtNzsMzMzy2SLzMWsswMAmZMMMAYmZbGADwYB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZW2GjZZWmlZMAADAAAAAAaamZZmxMDjZrNAMwAGYDAAgAMzsst0yMjFLLMDAGzwYAwMDAmBYsB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZxMmZYmZrNAMwAGYDAAgAMzsst0yMjFLLMAwYGGDAmZAYmZAjN",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZYWGzYmZmZWWGjZZWmlZMAADAAAAAAaamZZmxMDjZrNAMwAmBbAAAEgZmlllWmZsYZBDAYGGDAmZAwMDYsA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsNDzyMzMzMzM2WGDLDGGAgBAAAAAANNzsNzYmhxs1GAGYAzgNAAACwMzy2SLzMWsthBAMzixAgZGAMzAGL",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZeAz2YmZmZmx2yYYZMLDDAwAAAAAAgmmZWmZMDmZ2aDADYgZwGAAYmptZmtZmZWWWaZmxilNMMwgZYMAYmZbGgZAGL",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZegZmZGLLjxYWmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02Mz2MzMLbLtMzYxyCzAYwMbYAwMDAmZAjF",
            ["n"] = 1,
        },
        {
            ["code"] = "CIEAzbn3egSOtoSwvPw1U1vTLsZsNLjZMzMzMLLjxsMmlZMAADAAAAAAaamZZmxMDDbtBgBGwMYDAAMz02MzyMzMLbLtMzYxyCzAYwMbYAwMz2MAzMgxC",
            ["n"] = 1,
        },
    },
    ["HUNTER_SURVIVAL_MYTHICPLUS"] = {
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2mxYGzwyYaGAAAgBAGLLzMWwMz4BGjBgZsBGjZmNDA",
            ["n"] = 2,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZMzsNPAAAAAAgZMzMDzYMjZYZMNDAAAAAYmltZGLDzMMjxAmZbGbwMGmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZMzMGzyAAAAAAwMmZmZxMGzYGMmmBAAAYAwMWWmZmFjZmZMzAAzYBLGDjNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZZ0ssMMDzMNYbmZmZMmtZAAAAAAMjZmZw4BMjZYZMNDAAAwAAssMzYZGzMzMjZGwMLzYDMGmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjhxMsMmmBAAAYAAW2mZsMMzMmxYAYGbMMGmZxAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2MGzYGMmmBAAAYAgxyyMjFMzMmxYAYGbwMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZMzsNDAAAAAgZMzMDGjZMDbjpZAAAAGAgltZGLzYmhZMGwMbzYDmxwMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjxMmhlx0MAAAADAMW2mZsMMzYMzYAYGbgxwMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgNjZmxwyAAAAAAwMmZmhZMmxMYMNDAAAwAgZstMzMLmZmZmZMAwMWYYMmxmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgNzMzMmZ2mBAAAAAwMmZmhZMmxMsMmmBAAAYAAWWmZswMzYMGDAzYDLGjZmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz28AAAAAAAmxMzMMjxMmBjpZAAAAGAYmltZGLDzMMjxAwM2gZMMzmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZmxsMPAAAAAAgZMzMjtZMmxMYMNDAAAwAAjllZGLYmZMjxAmZbGbgxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzM2MGzYGWGTzAAAAMAALbzMWmxMDzYMAMjNwYYmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2mxYGzgx0MAAAADAMWWmZsgZmxMGDAzYDMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjxMmBjpZAAAAGAgltZGLzYmxYMzAwM2wixwMLGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjxMmBjpZAAAAGAgltZGbzYmxYMzAwM2wixwMLGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZMzMGzyAAAAAAwMmxMLbzYMjZwDYaGAAAgBAzYZZm5BWMmZmxMzAgZswwYYmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMgxMG2ILwMM0gFzMzMzMWGAAAAAAmxMzM2MGzYGWGTzAAAAMAYYZZm5BWYmZYGjBMzGAGjZmNDA",
            ["n"] = 1,
        },
    },
    ["HUNTER_SURVIVAL_RAID"] = {
        {
            ["code"] = "C8PApei1JmYNvFfEFaN5bWuGKMgxMGWILwMM0gFzMzMzwyAAAAAAgZMzMDz4BMjZwYaGAAAAAAjllZmZxMzMGzMGwMbAmlZMmZ2MA",
            ["n"] = 2,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZmxsMPAAAAAAgZMzMjtZMmxMYMNDAAAwAAjllZGLYmZMjxAmZbGbgxYmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMgxMG2ILwMM0gFzMzMzMWGAAAAAAmxMzM2MGzYGWGTzAAAAMAYYZZm5BWYmZYGjBMzGAGjZmNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZb0ssMMDzMNYbmZmZMzsNPAAAAAAgZMzMDzYMjZYZMNDAAAAAYmltZGLDzMMjxAmZbGbwMGmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZMzMGzyAAAAAAwMmZmZxMGzYGMmmBAAAYAwMWWmZmFjZmZMzAAzYBLGDjNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWwMzYmZZ0ssMMDzMNYbmZmZMmtZAAAAAAMjZmZw4BMjZYZMNDAAAwAAssMzYZGzMzMjZGwMLzYDMGmZzAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmxMz2MAAAAAAmxMzMMjhxMsMmmBAAAYAAW2mZsMMzMmxYAYGbMMGmZxAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2MGzYGMmmBAAAYAgxyyMjFMzMmxYAYGbwMGzMbGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8PAD57yiELKEty14ekTDtZEqMWgBmxoxyAYmgtZmZmZGz28AAAAAAAmxMzM2mxYGzwyYaGAAAgBAGLLzMWwMz4BGjBgZsBGjZmNDA",
            ["n"] = 1,
        },
    },
    ["PRIEST_DISCIPLINE_MYTHICPLUS"] = {
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMjNjZGsZamYwMDACgZb2WAjNDAAjZmZMYGMzgRwM",
            ["n"] = 2,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMzMDYamGDmZAQAMbz2GYsZAAYMmZMYGMzATwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMDGzMGbmmJGMzAgAY2mtFwYzAAwYmZGDmBzMYEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYMmZGMbzYmZmZmZAAAAAAAAAAYwyMYmZGbGzMYz0MxgZGAEAz2stAGbGAAGzMzYwMYmBzEMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgBLzgZmZYGzMYz0MxgZGAEAz2stAGbGAAmZmZGDmBzMwEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgZYZGMzMzwYmBbmmJGgZWwQYMLDwYwCAAMmZmxgZAmZGBzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAghZZGMzMjNjZGW2MNTMAzshhwYWGgxgFAAYMzMjBzAMzQwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMPwMwMbzYmZmZMzAAAAAAAAAAYGzyMYmZGmhZATzEDmZmZBDhxsMzystYMGLGAAGzMGDzMYmZmZmgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsYmxyYMGz8AMbsNzMzMzMAAAAAAAAAAMGbzgZmZwYmBbmmJGMzMzCGCjhZZ22MGjNDAAjZmZMYGMzYmZCmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWGjxYGMbzYmZmZmZAAAAAAAAAAYMWmBzMzwMmZATzEDmZmZBDhxsMz2stYMGbGAAGzMzYwMYmZmZmgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDzyMjxYmhZbGzMjZ8AzAAAAAAAAAAYMWmBzMzwMmZATzEDwMLYIMmlBYMYBAAGzMzYwMAzMzEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMGWmZmxMwMbzsMzMjxMDAAAAAAAAAgZMLzgZmZYGzMANTMYmZmFMEGzyMbz2mxYsYAAYMzYMMzgZmZmZCG",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzwyMjxYwMbzsNzMjxAAAAAAAAAAghZZGMzMDzYmBmpZiZYmZmNMEGzyMbz2mxYsYAAYMzMjBzgZmZGTwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmxYGmhZbmZmZmZAAAAAAAAAAYGWmBzMzwMmZATzEDmZAQAMbz2CYsZAAYMzMjBzgZGMTwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzwMgpZamBzMAIAmtZbBM2MAAMGzMGMDmZwMBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgxYZGMzMjNjZGsZamYAmZBDhxsMAjBLAAwYmZGDmBYmZEMD",
            ["n"] = 1,
        },
    },
    ["PRIEST_DISCIPLINE_RAID"] = {
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMjNjZGsZamYwMDACgZb2WAjNDAAjZmZMYGMzgRwM",
            ["n"] = 3,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgxYZGMzMDGzMGbmmJGgZ2wQYMbDwYwCAAMmZmxgZAmZGBzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAJVmtV83otBfEj5bt80waBAgtZegZMmZMmBmtZ2mZmxYmBAAAAAAAAAAzysMbMmZGMLMmxYMMLsNTjJWMAzsgFKGzyAM2wCAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmBzgZbmtZmZmZmBAAAAAAAAAgZYZGMzMDzwMgpZamBzMAIAmtZbBM2MAAMGzMGMDmZwMBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMjNjZGsZamYwMjBQAMbz2CYsZAAYMzMjBzgZGjRwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAJVmtV83otBfEj5bt80waBAgtxMDGzDMmZGzsZ2mZGzMmBAAAAAAAAAAWmlZbwMzgZhhBjhZxsNTjJWmBzMAoAMbz2GYsZDAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAJVmtV83otBfEj5bt80waBADsMzMjxYMmZGzsZ2mZmZmBAAAAAAAAAAwysMbDmZGMLMMGjhZhtZamJWAzMAoAMbz2GYsZDAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMDWmZMmBmZbmtZmZmxMDAAAAAAAAAgxYZGMzMjNjZGsZamYAmZBDhxsMAjBLAAwYmZGDmBYmZEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYmBz8AMmZbmZmZmZAAAAAAAAAAYGWmBzMzwMzMDYamGDmZAQAMbz2GYsZAAYMmZMYGMzATwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgxYZGMzMDGzMGbmmJGMzAgAY2mtFwYzAAwYmZGDmBzMYEMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMmxyYMmZGMbzYmZmZmZAAAAAAAAAAYwyMYmZGbGzMYz0MxgZGAEAz2stAGbGAAGzMzYwMYmBzEMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAQAR03Gt7xPmcDNOjs2Zlb3yCDsMzMWYMGzgZzsNzMzMzMDAAAAAAAAAgBLzgZmZYGzMYz0MxgZGAEAz2stAGbGAAmZmZGDmBzMwEMD",
            ["n"] = 1,
        },
    },
    ["MONK_BREWMASTER_MYTHICPLUS"] = {
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMmZZYZ7B22mNMLAAwysMtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGzYWmxGmZMAAAAAAALLwEmBzMwmhxMzMjZ2YmxMLDLb22mthZBAAWmlplZbmlBAY2mlmZmZzMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEmBmhxmhxMzMDz2YmxYZYZ7B22mNMLAAwysNtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGPwYWm5B2YmZMAAAAAAALLYmYmBzMM2AmZmZY2GzMGLDLbPw22shZBAAWmlplZbmlBAACghNwMDYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMz2wMjBAAAAAAYZBmYmBmhBzgZmZGmtxMjZWGW2egttZDzCAAsMLTLz2MLDAAEADbgZGw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEmBmhxmBmZmZMzGzMmZZYZ7B22mNMLAAwysNtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGzYGzyM2wMjBAAAAAAYZBjYmBmhZ2MDmZmZYWGmxYZYZz22YGzCAAshAAAMbzSzMzswwGAzMMNGAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMmZZYZ7B22mNMLAAwysNtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMMzGDmZmZY2GmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2MwMzMjZ2YmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBjwMYmhxmZwMzMDz2YmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMPwGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMGLDLbz22shZBAAWmlplZbmlBAACghNGmZATjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMz2YmZMAAAAAAALLYmYmBmhxGMmZmZMzGzMGLDLbPw22shBAAsMLTLz2MLDAAEADbgZGw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMmZZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGjZmtxMzYAAAAAAAWWwMxMDMDzsZgZmZGmNmZMWGW2egttZDzCAAsMLTLz2MLDAwsNLNzMzGDbgZmZGmGDAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzmtZGjlhltHYbb2wsAAALzy0ysNzyAAABwwGYmBMNGAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGDGzyM2YmZMAAAAAAALLYEzMwMMYGMzMzYmthZMzywy2stNbDzCAAshAAAMbzSzMzsxwGAzMMNGAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGDPwY2mxGmZMAAAAAAALLgYmBmhBzgZmZGzsNMjZWGW2mltZbYWAAgNEAAgZbWamZmNG2AYmhpxAGAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBjYmBzMM2MwMzMjZ2YmxYZYZ7B22mNMLAAwysMtMbzsMAAz2s0MzMbMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGDGzyM2GmZMAAAAAAALLYEzMwMM2MjxMzMjZWGMGLDLbPwy2sNMLAAwysMtMbzsMAAQAMsBmZATzMAAgB",
            ["n"] = 1,
        },
    },
    ["MONK_BREWMASTER_RAID"] = {
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMLbGzYGWmxGmZMAAAAAAALLYEzMwMM2MjxMzMjZ2YmxMLYZz22YGzCAAshAAAMbzSzMzsZG2AYmhpxAAAG",
            ["n"] = 2,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGDGzyM2YmZMAAAAAAALLYEzMwMMYGMzMzYmthZMzywy2stNbDzCAAshAAAMbzSzMzsxwGAzMMNGAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAwMbbGDGzyM2YmZMAAAAAAALLYEzMwMM2gxMzMDzmtZGzsMssNbbz2wsAAAbIAAAz2s0MzMbMsBwMDTjBAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyM2YmZMAAAAAAALLYEzMwMMDzgZmZGmthZMzywy2ssNGzsAAAbz20ysNzyAAMbzSzMzswwGYmZmhpxAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMMzmZwMzMDzGzMGLDLbz22YYWAAglZbaZ2mZZAAmtZpZmZWYYDMzMzw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGzYWmxGmZMAAAAAAALLYEzMwMM2MDmZmZMz2wMGLDLb22mtxMLAAwysMtMbzsMAAz2s0MzMLMsBmZmZYaMAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAgZbzYGzYWmxGmZMAAAAAAALLYmYmBmB2MwMzMDz2YmxMLDLb22GzYWAAgtZZaZ2mZZAAmtZpZmZ2MDbgZmZGmGDAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAwMbbGzwYWmxGmZMAAAAAAALLYEzMwMM2MjxMzMDz2wMGLDLbz22YMzCAAsNbTLz2MLDAwsNLNzMzCDbgZmZGmGDAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAwMbbGDGz2MPwGzMjBAAAAAAYZBjYmBmhZ2MwMzMDzGzMmZZYZbW2mNMLAAwGCAAwsNLNzMzGDbAMzw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAi6cZM+HWADeySjzG9Lwx8DAAAgZbzYGPwYWmZ2YmZMAAAAAAALLYmYmBmhZ2MwMzMDzGzMGLDLbPwy2shBAAsMLTLz2MLDAAEADbgZGw0YAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwQAQnG51S19isUJoJoTeJ/IKDAAAgZbzYGGzyMzGzMjBAAAAAAYZBzEzMwMM2gxMzMDzGzMmZZYZ7B22mNMLAAwysMtMbzsMAAQAMsBmZATjBAAMA",
            ["n"] = 1,
        },
    },
    ["WARRIOR_FURY_MYTHICPLUS"] = {
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMz2yMzMzMzMmZmZmZMzyMGzMmNzMzAAAxYZbgFwEMDTgZYDYmhBAAYmhxsMwgxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmBAAYmhxsMwgxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZmZmxsYmZGAAIMwGssY0YGQmFMjFAzgBAMzAwwiZAGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjZMzmZmZGzMjZmZmZmZmlZmxMjZZMzMAAQMzy2YjFLbmpxMzwkZhZGLAmhZAAzMYmxgFjBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMz2yMzMzMMmZmZmZMzyMGzMzsZmZGAAIGLbDsAmgZYCMDbAzMM2AAgZGGjhxgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMzy2YjFLLmpxMzwkZhZYDYmhBAYmBzMMmlhxgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjZmZ2WmxMjxMmZmZmZmZWmZGzMmFzMzAAAhB2glFjGzAysgZsAMzwAAMzAwwixAGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMjZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmBAAYmhxsMwgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMjZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDzMmZ2MzMzMDjZmZGzMzsMzMmZmZzYmBAAixy2ALgJYGmAzwGwMDjNAAYmhxYYMYM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMz2yMzMzMzMmZmZmZm5BWmxYmxsZmZGAAIGLbDsAmgZYCMDbAzMMAAAzMMmlBGMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMDDAAwMDjZZYMYM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMziZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjZMz2yMzMjZmxMzMzMjZWmZGzMmFzMzAAAhB2glFjGzAysgZsAYGMAgZGAGWMDDGD",
            ["n"] = 1,
        },
    },
    ["WARRIOR_FURY_RAID"] = {
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZmZMzMzMzMzDsMjxMjZzMzMAAQMW2GYBMBzwEYG2AmZYAAAmZYMLDjBjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgEArbixk/ZKwTdpZGVHeylmLAAAAAAAAAQDMzwMwYAgHYYGMY22mZMzMLYGzMDzw2sNPAzMGAAAEDbDsAmADTgBbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEArbixk/ZKwTdpZGVHeylmLAAAAAAAAAQjhhNzMWmxgZWYmZGzwMMz22MjZmZBGzMzYmxywwDMzMAAAIGbbDsAmgZYCMDbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxM2WmZMzYmhZMjZmZWmxMzMmtxMzAAAxMbLDsYZhpxMzwkBzwGAAAwMDmZmhxADGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEAjLzRlq54bI5v+r8Sr9Xw4DAAAAAAgGDzYmZsMzMzMDjZGzYGzsMzMGzMLjZmBAAiZWWGbsYZzMNmZGmMLMGLAmBz2AgZGADzMzMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDDzMYmhZwwMmxMmZZmZMmZWGzMDAAEGYDW2MaMDIzGmxCAgNAYmBwwsMjxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEAjLzRlq54bI5v+r8Sr9Xw4DAAAAAAgGDDzMjlZmZmZYMzYGzYmlZmxYmZZMzMAAQYgNYZzoxMgMbYGLAmBz2AgZGADzMzMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEASWsDSHNyPDXnbxuIhH3ZdDAAAAAAgGDjxMzmZmZmZYMzMzMzYmlZMmZMbmZmBAAixy2ALgJYGmAzwGwMzmxGAAMzwYWGGDGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEArbixk/ZKwTdpZGVHeylmLAAAAAAAAAQjhZmtZmhZMYmFmZmhhZYstNzYmZWYmxMzMmhNbzwMmBAAAxYbZgFwEMDTgBbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEAO9DBjZzKcjSu6RJDto0RCCAAAAAAAAAEgBDMGAwAAmNzMmZsMMjZMmZYZYmZGzAAAABAAEACAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgEAjLzRlq54bI5v+r8Sr9Xw4DAAAAAAgGDzMmhlZmZmZYMzMzYGzsMzMGzMbjZmBAAixyyALgJYGmAzwGwMDmtBAAzMGGzMDDG",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_UNHOLY_MYTHICPLUS"] = {
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDzyMzMTz2MzYmZMAAAAAAAAMPwYYAwyMY2MzYmZMYbmFzMzmmZZhZjZbashBMDgZmZmxMYmZmhZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjZMYWGzMTzyMzYmZMAAAAAAAAMPwYYAwyMY2MzYmZMwAzYTjlNAbTshBMDgZmZmxMYmBMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMzMDz2MzMTzmZGzMDAAAAAAAAMPwYYAwyMY2MzYmZMwAzYRjlFAbTshBMDgZmZmxMYmBGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTz2MzYmZMAAAAAAAAMPwYMDAWGMzmZGzMjBGYGbassBYbiNMgZAMzMzMMYmBDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjZMY2mZmZaMzMmZGDAAAAAAAAzDMGzAglBzsZmxMzYw2MbmZmNNzyCzGz20YDDYGAzMzMDDmZmZYGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyYmZa2mZGzMjBAAAAAAAg5BGDDAWmhZ2MzYMjBGYGbassAYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMMjZGDz2YmZaWmZGzMjBAAAAAAAg5BGDDAWmhZ2MzYMjBGYGLassBYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDz2MzMTjZmxMzYAAAAAAAAYmxYGAsMMzsNzMmZGD2GYGbassAYbiNMgZAYMzMMYmBjZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyYmZa2mZGzMjBAAAAAAAg5BGDDAWmBzmZGzMjBGYGbassBYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMmZYWmZmZaMzMmZGAAAAAAAAYegxwAglZwsZmxMzYgBmxmGLbA2mYDDYGAzMzMjZwMDMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMmZYWmZmZa2mZGjZMAAAAAAAAMzYMDAWGmZ2mZGzMjBbzsZmZ20MLbMbMbTjNMgZAYMzMMYmZmhZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTz2MzYmZMAAAAAAAAMzYMDAWGmZ2mZGzMjBGYGbassBYbiNMgZAYMzMMYmBDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjZY2mZmZa2mZGjZMAAAAAAAAMPwYYAwyMMzmZGjZMwAzYTjlFAbTshBMDgZmZmxMYmBDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMjZY2mZmZa2mZGjZAAAAAAAAg5BGGDAWmhZ2MzYmZMwAzYRjlFAbTsBgZAMzMzMmBzMYGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDz2MzMTjZmxMzAAAAAAAAAzDMGGAsMDmNzMmZGDMwM20YZBw2EbYAzAYmZmZMDmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMDDz2MzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzYwyAzYTjlFAbTshBMDAjZmxMYmBzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMDY2MzMTz2MzMzMjBAAAAAAAg5BGDDAWmBzmZGzMjBGYGbassBYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxMDz2MzMTzmZGjZMAAAAAAAAMzwYAwyMmZ2MzYmZMYZmFzMzimZZhZjZZasgBMDAjZmxMAzMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxMDz2MzMTzmZGjZMAAAAAAAAMzwMDAWmxMz2MzYMjBLzsYmZW0MLLMbMLTjFAMDAjZmxMAzMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmZMjxYY2mZmZa2MzYMjBAAAAAAAg5BGDDAWmBzmZGzMjBLzsYmZW0MLLMbMbTjNMgZAMzMzMmBzMzMzYMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_UNHOLY_RAID"] = {
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZmxYY2mZmZa2MzYMjBAAAAAAAgZeAmZAwyMmZ2mZGzMjBLzsYmZW0MLLMbMLTjFAMDAMzMGAzMzYMA",
            ["n"] = 4,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMDDz2MzMTzmZmZMjBAAAAAAAgZeAmZAwyMmZ2mZGzMDYzsYYIDMbM0YBAzAAzMjBwMzMGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMzYY2mZmZa2MzYMjBAAAAAAAgZGGDAWmxMzmZGzMjBLzsYmZW0MLLMbMLTjFMgZAYMzMmBYmZGjB",
            ["n"] = 2,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMjBzyMzMTjZmxMzYAAAAAAAAYmxwAglZMzsZmxMzA2MbGGyAzGDNWwAmBgxMzYGgZmxMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMDY2MzMTz2MzMzMjBAAAAAAAg5BGDDAWmBzmZGzMjBGYGbassBYbiNMgZAMzMzMmBzMYMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMGDz2MzMTjZmxYGDAAAAAAAAzMMzAglZMzsZmxMzAWMLGGyAzGDNWAwMAMmZGzAMzMzMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBwMjZMGDz2MzMTjZmxYGDAAAAAAAAzMMGAsMjZmNzMmZGwiZxwQGY2YoxCGwMAMmZGzAMzMzMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPASnrjTdwaLTX9NnLQoJJXfAwMjZMGDz2MzMTzmZGjZMDAAAAAAAgZGmZAwyMmZ2mZGzYA2MLGGyAzGDNWAwMAwMzYGgZmZMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwPAkXBWxkyfx9CbGaHonEAhLBYmhZMGDzyMzMTz2MzYmZMAAAAAAAAMPwYYAwyMY2MzYmZMYbmFzMzmmZZhZjZbashBMDgZmZmxMYmZmhZMA",
            ["n"] = 1,
        },
    },
    ["ROGUE_ASSASSINATION_MYTHICPLUS"] = {
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMz8AzDMmZMGmZMGgtZWGLMmxs0Y2WGmsNMsZwMDmZGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMz8AmxMjxwMjxAsNzyYhxMmlGz2ywkthhNDmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxMADsAzY0YWAZbAbAgZmxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAILzMzMzMjx2MzMbzsMzMPgZMzYMMzYMAbmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCILDYzAgZmxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AjxMjxYmZMGgtZWGLMmxs0Y2WGmsNMsZwMDmZGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZM2mZmZbmlZmZGjZGjxMzYMAbzsMWYMjZpxstMMZbYYzgZGMzMGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxMADsAzY0Y2AZbAbGAMzMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AzDMmZMGmZMmBsNzyYhxMmlGz2ywklhhNwMDmZGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZGGMAAAAAwsMYbGAAAAAQWmZmZmZGjtZmZ2mZZmZGPwYmxMDzMGDw2MLjFGzYWaMLLDT2GGWMYmBzMjxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMz8AmxMjxwMjxMgtZWGLMmxs0Y2WGmsNMsBmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZM2mZmZbmlZmZGjZGjxMzYMAbzsMWYMjZpxssMMZbYYzgZGMzMGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZmHYMzYMMzYMAGYBmxoxsBy2A2MAYmZMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMz8AjZGjhZGzMAGYBmxoxsBy2A2MAYmZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxAsZWGYALBLDTghFDmZAGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7PzsMmlZwAAAAAAzygtZAAAAAAttNzMzMzMGbzMzsNzyMzMMjZMGzMGGADsAzY0YWAZbAbGAMzYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMAGYBmxoxsBy2A2MAYmZMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlZmZmZmxYZmZmtZWmZmHwMmZMGmZMGgtZWGLMmxs0Y2WGmsNMsYwMDmZGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
    },
    ["ROGUE_ASSASSINATION_RAID"] = {
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlxsYwAAAAAAzygtZAAAAAAZbmZmZmZMWmZmZbmlZmZmHYMzYMMzYMAGYBmxoxsAy2A2MAYmZMGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPwYMzYMmZGjBYzsMwAWCWGmADLGMzAMGD",
            ["n"] = 2,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjx2MzMbzsMzMPgZMzYMMzYMALmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAIbzMzMzMjxyMzMbzsMzMPgZMzYMMzYMAbmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttNzMzMzMGLzMzsNzyMz8AmxMjxMmZMGADsAzY0Y2AZbAbGAMzMDfA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMz8AzDMmZMGmZMGgtZWGLMmxs0Y2WGmsNMsZwMDmZGjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDAAAAAAzygtZAAAAAAttMzMzMzMGbzMzsNzyMz8AmxMjxwMjxAsNzyYhxMmlGz2ywkthhNDmZwMzYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxMADsAzY0YWAZbAbAgZmxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAILzMzMzMjx2MzMbzsMzMPgZMzYMMzYMAbmlBGwSwywEYYxgZGgxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAotlxMzMzMGbzMzsNzyMz8AmxMjxwMjxAYgFYGjGzCILDYzAgZmxYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CMQA5HmDzx68KWyrW/8Y781L7bmlZmFDGAAAAAYWGsNDAAAAAottxMzMzMGLzMzsNzyMz8AjxMjxYmZMGgtZWGLMmxs0Y2WGmsNMsZwMDmZGjB",
            ["n"] = 1,
        },
    },
    ["SHAMAN_RESTORATION_MYTHICPLUS"] = {
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMYWWmZxGjZsMN2mZhJzwYzMMDWmZmZa2WmZ2MjBLz8AzMGMLDAAAMzMYmBzMwgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstNmZmZMzMjhxyyML2YMjlpx2MLMZGGbYmBzyMjRzyyMzmZMbsYMzYYZWmBAgBwMDmZwMDjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZmZGjhhFYDmxiGbDIzAbYmB2mZmRzyyMzmZMYZGzMGWmlZAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsttMmZmZMzMjhx2yML2YMjlpx2MLMZGGbYmBz2MzMaWWmZ2MjBLzYmxgZZGAAGAzMYmBgxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMDjZGzMgFYDmxiGbDIzAbmZYYWGjZa2WmZWMjZhFzMzYwsMAAAwMzgZGAYwM",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzYMMWWmZzGjZsMN2mZjJzwYDzMDzyMzMa2WmZ2MjBLzYmxgZZGAAGAzMYmBzMMGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNmZGjZGzMYsAbwMW0YbAZGYzMMDz2MjZa2WmZYGzCLmxMmhZZAAAgZmBzMAwgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzYMMWWmZxGjZsMN2mZhJzwYjZmBz2MzMa2WmZ2MjBLzYmxgZZGAAGAzMYmBzMMGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzMjZMsAbwMW0YbAZGYDzMY2mZMaWWmZ2MDbsYMzYMmlZAAYAMzgZGAGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMDjxYmBjFYDmxiGbDIzAbmZYYWGzMTz2yMziZMbsMjZGDmlBAAAmZGMzAADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzMjZMsAbwMW0YbAZGYDzMYWmZmRzyyMzmZMYZGzMGMLDAAGAzMYmBgxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsttMzMzMjZGjZMsAbwMW0YbAZGYDzMYWmZmRz2yMzmZMYZGzMGMLDAAGAzMYmBgxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMDjxYmBjFYDmxiGbDIzAbmZYw2MzMTz2yMDzY2YZGzMGMLzAAAgZmBzMAwgZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDIzAbmhZY2GzMTzyyMDzYwyMjZMYWGAAAYmZwMDAMYG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzYMjhFYDmxiGbDIzAbMzMY2mZmRz2yMzmZMYZGzMGMLDAAGAzMYmBgxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAAAAAAYmZmtltZmZmZMzYMjxyyMLWYYsMNWmZhJzwYhZmBz2MjRz2yMzmZMYxYmxYWmFDAADAzYwgZGGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzstsMmZmZMzMjZMWWmZxGjZsMN2mZhJzwYBzMY2mZmRzyyMzmZMYZGzMGjZBAAGAzMYmBzMMGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAAAAAAYmZmltlZmZGjZmZMjhFYDmxiGbDIzAbYmZY2mZmRzyyMzmZMbsYMzYwsMAAYAmZGMzAwYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNzMzYMzYmZwyyML2YMjtpx2MLMZGGbmhZY2GjZa2WmZ2MjZjFzDMzYwsMAAAwMzgZGMzADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMmZmZMzMjhhFYDmxiGbDIzAbYmBzyMjRzyyMzmZMbsYMz8ADmlZAAYAMzgZGAGDG",
            ["n"] = 1,
        },
    },
    ["SHAMAN_RESTORATION_RAID"] = {
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDIzAbmhZw2YMTz2yMzmZMLsYegZGzwsMAAAwMzgZGAYwM",
            ["n"] = 3,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMjxyyMb2YMjlpx2MbMZGGLmhZw2YMTz2yMzmZMLsYegZGzwsMAAAwMzgZGMzADmB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMjxiZ2gBMBzGTgxiZYGsNGz0stMzsZGzCLmHYmxMMLDAAAMzMAYmBGMD",
            ["n"] = 2,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZYMzYmZMWMzGMgJY2YCMWMGzgtxYmmtlZmNzYWYx8AzMmhZZAAAgZmBAzMwgZA",
            ["n"] = 2,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsstMzMzMjZGjZgFYDmxiGbDIzAbMzMY2mZMa2WmZ2MjZjFjZGDLzyMAAAYmZwMDAAzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMDjFYDmxiGbDIzAbmhZw2MjZa2WmZ2MjZhFzDMzYGGDAAAMzMYmBAGMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMjxyyMbWYMjlpx2MbMZGGLmhZw2YMTz2yMzmZMLsYegZGzwsMAAAwMzgZGMzADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQAL+iDLHPJSLC+6fqMJ8tubCAAAAAAAAAAYMzMLzwMYW2sMAYBWgZspxyAyMwGeADYZmZmJzyCzMNmhZ2wyMmBjhZZMAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZYMGzMYWWmZzCjZsMN2mZjJzwYzMDDWGzMTz2yMzmZMLsMzYGDmlBAADwMzgZGMzADmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgQALMl7AwW51MWzGneuHE3tPCAAAgBAAAAzMzsssNjZGjZGzMYWWmZxGjZsMN2mZhJzwYzMMDWmZmZa2WmZ2MjBLz8AzMGMLDAAAMzMYmBzMwgZA",
            ["n"] = 1,
        },
    },
    ["MAGE_FROST_MYTHICPLUS"] = {
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGjZMziZmZmZMDEAAYmZmllZm2AAAAAAgNA2WGzMzAbzYmZYBAAgZ2AmBGwADD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwMLzMPwsMMzEzMzYmZmZWMzMjZMDEAAYmZmllZm2AAgNAAAwCAbbjZmZwsNMmhNAAAmZDYGYAzghB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmxYmZmZWMzMzMzMzsMTzMbzCAAAaBAA2AAAAAYzYmZmhZbGzMjtNAAAwMDmBGwAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmZGzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAWAYbbMzMDmthxMsAAAwMbAzADYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMmZmZmZWMzMzMzMzsMTzMbzCAAAaBAA2AAAAAYbZMzMDmtZMzM22AAAAzMYGGDYAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzMzMziZmZMjZgAAAzMzssMz0GAAAAAAsBw2yYmZGMbDjZYBAAgZ2AmBGwMYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwMLzMmFegZmYmxYmZmZWMzMzMzMzsMTzMbzCAAAaBAA2AAAAAYbZMzMzwsNjZmx2CAAAYmBzADYAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMzMzMzMziZmZMjZgAAAzMzssMz0GAAsBAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzMzMziZmhZMDEAAYmZmllZm2AAAAAAgFA2WGzMzgZbYMzYBAAgZ2AmhxAmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzALzMzsMmZmYmZGzMzMziZmhZMDEAAYmZmllZm2AAAAAAgFA2WGzMz8AMbDjZGLAAAMzGwMwAmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZEzMmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAgNA2WGzMzMMbDjZYBAAgZ2AmBGwMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFmZmYGmZmZmZWMzMMjZgAAAzMzssMz0GAAsAAAAWAYbbMzMDmthxMjFAAAmZDYGGDYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGzMzMWMzMzMzYmlZamZbWAAAQLAAAAAAwCAbbjZmZwsNjZmx2CAAAYmBzADYGgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlxMzEzMGzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAWAYbbMzMDmthxMsBAAwMbAzADYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMmZmZmZWMzMzMzMzsMTzMbzCAAAaBAAWAAAAAYbZMzMDmtZMzM2WAAAAzMYGGDYAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFmZmYmxMzMzMziZmhZMDEAAYmZmllZm2AAgFAAAwGAbLjZmZwsNMmZsAAAwMbAzADYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMegZmYmxYmZmZ2MzMjZGzsMTzMbzCAYmZmtlZmWAAgNAAAAA22GzMzgZbmZmZmtFAAAmZbmBzwYADgB",
            ["n"] = 1,
        },
    },
    ["MAGE_FROST_RAID"] = {
        {
            ["code"] = "CAEAMhlVtghLZL4RZzExaQoBYZGGLzMzsMmZmYmZmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAAbAstMmZmBz2wYGWAAAYmNgZgBMDGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CAEAMhlVtghLZL4RZzExaQoBYZGGLzMzsMmZmYmxMzMzMziZmZMjZgAAAzMzssMz0GAAAAAAYDgtlxMzMY2GGzwCAAAzsBMDjBMDGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFmZmYmZmZmZmZWMzMMjZmtZamZZWAAzMzssMz0GAAAAAAsBw22YmZGMbDjZGLAAAMz2MDmBGwMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmFMzEzMzMzMzMziZmZMjZgAAAzMzssMz0GAAsBAAA2AYbZMzMDmthxMsAAAwMbAzADYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGmZZm5BmlxMzEzMzYmZmZWMzMjZMzsMTzMLzCAYmZmllZm2AAAAAAgNA2WGzMzgZbYMDLAAAMz2MDmBGwMYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGmZZmZmlxMzEzYmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAgNA2WGzYGMbDjZYBAAgZ2AmBGwMYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGLjlZmHYWGzMTMzMjZmZmZxMzMmxMQAAgZmZWWmZaDAAAAAA2AYbZMjZwsNMmhFAAAmZDYGGDYGMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZmZmZmZWMzMjZMDEAAYmZmllZm2AAAAAAgNA2WGzMzgZbYMDLAAAMzGwMwAmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAMhlVtghLZL4RZzExaQoBYNzwYZGmlxMzEzMzMzMzMziZmZMjZgAAAzMzssMz0GAAsBAAAsBw2yYmZGMbDjZYBAAgZ2AmhxAmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuZGGLzMzsMmZmYmZGjZMziZmZmZMDEAAYmZmllZm2AAAAAAgNA2WGzMzAbzYmZYBAAgZ2AmBGwADD",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwMLzMPwsMMzEzMzYmZmZWMzMjZMDEAAYmZmllZm2AAgNAAAwCAbbjZmZwsNMmhNAAAmZDYGYAzghB",
            ["n"] = 1,
        },
        {
            ["code"] = "CAEAche08tHz49KSVf7iKFnyuNzwYZmZmlhZmYmxYmZmZWMzMzMzMzsMTzMbzCAAAaBAA2AAAAAYzYmZmhZbGzMjtNAAAwMDmBGwAYA",
            ["n"] = 1,
        },
    },
    ["MAGE_ARCANE_MYTHICPLUS"] = {
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMmFMzQzMzAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
            ["n"] = 2,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMzsgZGamxAAAwAAmZmmlltZAgYDAgNYmZYzyMmZZGjZmZmhFmxMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZm5BmFMzQzMzAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamZGAAAGAwMz0sssNzMzMLLzMxGAAgZmhNLzYmlZMmZmZGWYGzMzAAMAAAzMLYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMPwsgZGamZGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLmZmFMzQzMzAAAwAAmZmmlllZAgYDAgNGzMDbWmxMLzYMjZmhFmZm5BmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZmZmZZZmJ2AAAMzMsZZGzsMjxMzMzwCzMzMzAAMAAAzMLYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZxMzsgZGamZGAAAGAwMz0sssNzMzMLLzMxGAAbwMzwmlZMzyMGzMzMDLMzMzDMDAwAAAMzsgZGYMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMmFmZQzMzAAAwAAmZmmlllZAgYDAgFYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGwMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFMzQzMGAAAGAwMz0sssNDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFMDamZGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFMzQzMGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZmZmFMDamZGAAAGAwMz0sssMzMzMLLzMxGAAbMmZG2sMjZWmxYGzMDLMzMzMDAwAAAMzsgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzsgZGamZGAAAGAwMz0sssMzMzMLLzMxGAAbwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMzsgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZGPwswMDamxMAAAGAwMz0sssMDAEbAAsxYmZYzyMmZZGjZMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwYZmxsgZQzMzMAAAGAwMz0sssMzMzMLLzMxGAAbwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMzsgZGwMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzsgZGamxAAAwAAmZmmlllZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAjBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGLjlZMzCzMoZmZAAAYAAzMTzyyyMAQsBAAYmZYzyMmZZGjZmZmhFmxMzMAADAAwAMzAmBADzMD",
            ["n"] = 1,
        },
    },
    ["MAGE_ARCANE_RAID"] = {
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzQzMGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAMAYYmZA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZAgYDAAwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMAzMgZAwwMzA",
            ["n"] = 3,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZAgYDAAwMzwmlZMzyMGzMzMDLMzMzMDAwAAAMAzMgZAwwMzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmxMzMAADAAwAMzAmBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAkrVdV3pA5GLQDtVHHbnyGZGMbzgZMjZzDwYmhx08AjZAAAAAAYgAmZmWmtlZAgYDAAAAAgNAMGMzysMzMzYMDzMzMjZYZM",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMzQzMzAAAwAAmZmmlltZAgYDAAwMzwmlZMzyMGzMzMDLMzMjZAAGAAgBYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMzQzMzAAAwAAmZmmlllZAgYDAAwMzwmlZMzyMGzMzMDLMzMjZAAGAAgBYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamZGAAAGAwMz0sssMDAEbAAAmZG2sMjZWmxYmZmZYhZMzMDAwAAAMAzMgZAwwMzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMzsgZGamxAAAwAAmZmmlltZAgYDAgNYmZYzyMmZZGjZmZmhFmxMzMAADAAwAMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZZm5BmFMzQzMzAAAwAAmZmmlllZAgYDAgNYmZYzyMmZZGjZmZmhFmZmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamZGAAAGAwMz0sssNzMzMLLzMxGAAgZmhNLzYmlZMmZmZGWYGzMzAAMAAAzMLYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlllZmZmZZZmJ2AAYDmZG2sMjZWmxYmZmZYhZmZmZAAGAAgZmFMzAMAYYmZA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLzMPwsgZGamZGAAAGAwMz0sssMDAEbAAsBzMDbWmxMLzYMzMzMswMmZmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuNzwMLmZmFMzQzMzAAAwAAmZmmlllZAgYDAgNGzMDbWmxMLzYMjZmhFmZm5BmBAYAAAGgZGgBADzMD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGGLzMzswMDamxAAAwAAmZmmlltZmZmZZZmJ2AAAMzMsZZGzsMjxMzMzwCzMzMzAAMAAAzMLYmBMDAGmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4DAche08tHz49KSVf7iKFnyuZGmZxMzsgZGamZGAAAGAwMz0sssNzMzMLLzMxGAAbwMzwmlZMzyMGzMzMDLMzMzDMDAwAAAMzsgZGYMAYYmZA",
            ["n"] = 1,
        },
    },
    ["PALADIN_HOLY_MYTHICPLUS"] = {
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAYwyAmZWmZmlZMjhFzmZWMTTMMmZmxY2yAwAwGYjFzMAIAgZmllFLzMsx2YGsBMjBAYmBAjxoB",
            ["n"] = 2,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2GGmZWmZsYMzMsMPwmZWMaiZxYmZYMbZAYAYDsxiZmZZ2mZmtGAwMzy2ilZGWYjZwGwMbwMAmZwMDzYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwAAA2mZmZMjZGLGzMDLDmZxMNxYGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2GzwMzyMzsYMjhlxmZWMaiZxYmZYMbZAYAYDsxiZmZZ2mZmtGAwMzy2itZGWYjHYwGwMbDmBAwMDzYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAAWGwMzyMzsMjZMsY2MziZaiZxYmZGjZLDADAbgN2MzMLz2Mzs1AAmZWWWsMzwGbDD28AwMbDAwMDmZwYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAAWGwMzyMzsMjZMsY2MziZaihxMzMGzWGAGA2AbsYmZWmtZmZrBAMzsssYZmhN2GzgNPAMjBAYmBzMYMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMLGzMDjZLDADAbgN2MzAgAAmZWWWsMzwGbjZwGDmxAAMzAwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAAbAwMAADWGwMzyMzsMjZMsY2MziZaixMmZGGzWGAGA2AbsNzMzysMzMLNAgZmllFLzMsxGGsZgZMAAzMYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2wwMzyMzsYYmhl5B2MziRTMmxMzMGzWGAGA2AbsZmZWmtZmZrBAAAYhNmBbAzYwMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAAWGwMzyMzsMjZMsY2MziZaiZxYmZGjZLDADAbgNWMzMLz2Mzs1AAmZWWWsMzwGbjHYwGwMGAgZGMzwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyAmZWmZmlZMjhFzmZWMTTMMmZGGzWGAGA2AbsZmBABAMzsssYZmhN2GzgNDMjBAYmBgZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGzYmZYMbZAYADbgNWmxMLz2Mzs1AAAAsAwYDGzYGmBAwMDzYMaA",
            ["n"] = 1,
        },
    },
    ["PALADIN_HOLY_RAID"] = {
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAglxMzYGzMzGjxYWGbzMLmpJGzYmZYY2yAwAG2AbsMjZWmtZmZrBAAAYBA2MMmxMAAgZGmxY0A",
            ["n"] = 2,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAAbAwMAADWmZmZmZMzMLGzYYBmZxoJGGzMDjZLDADAbgNWmZmZZ2mZmtGAwMzyyilZGWYjZwGDmhhBgZGMzwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAAAgFAYzwYGzwMAAmZYGjRDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAgZBAmBAYwyAmZWmZmlZMjhFzmZWMTTMMmZmxY2yAwAwGYjFzMAIAgZmllFLzMsx2YGsBMjBAYmBAjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMDAAsMmZGzYmZWYMGzyYbmZxMJGGzMDDzWGAGwwGYjlZMzysNzMbNAgZmltFLzMsAAbegxYGzMAwMDmZYGjRD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZMzYxYmZYZwMLmpJGGzMDjZLDADYYDsxyMmZZ2mZmtGAwgtFLDsAAbGGzYGmBwMwMDzYMaA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAglxMzYGzMzCjxYWGbzMLmpJGGzMDDzWGAGwwGYjlZMzysNzMbNAAAALAwmhxMmZAAgZGmxY0A",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAglZmZGzYmZ2YwYWGbzMLzoJGGzMDDzWGAGwwGYjlZMzysNzMbNAAAALAwmhxMmZAAgZGmxY0A",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAwyYmZMjZmZjxYMLjtZmFzkY2mxMzwY2yAwAwGYjtZMzysNzMLNAAAALAwmhxMmBAAMzwMGjGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwAAAWGzMjZMzMLMGjZZsNzsYmmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNDjZMzAAAzMMjxoB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZWmZsYMmhlBzsYmmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAD2GzMzMjZmZBmZYZsZmFjmYYMzMMmtMAMAsB2YbmZmlZbmZ2aAAAAWAGsZgZMDzAAYmhZMGNA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAVg1HmQqr1Dwlv86ljju8vCAAAYBAMAAGsMmZmZGzMjZMmhlxixmZaihxMzAegtMAMAsB2YxMzsMbzMzSDAYmZZbxyMDbAAPwAAAAAAIA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEEAzbn3egSOtoSwvPw1U1vTLAAAALAwMAAw2MzMjZWmZsYMmhlBzsMjmYYMzMMmtMAMghNwGLzYmlZbmZ2aAAAAWAgNDjZMDzAAYmhZMGNA",
            ["n"] = 1,
        },
    },
    ["PALADIN_RETRIBUTION_MYTHICPLUS"] = {
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAMzGwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxMjxwMWYDAzysNzMbNzMtNzsNDAYBwAgxMMwMmZ2wyMzMDjhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAANbbzMzyYGzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtmZm2MYAALAGAMmxMwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmywwMjtxsNMz2MGzMGmxCbAY2mtZmZrZmptZmtZAALAGsBGzwMYGzMbYZmZmhBGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAYMzGwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAjysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAMjZYGMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAjhBMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrZmptZmtZAALAGAMmhBmxMzGWmZmZMjhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtmZm2mZ2mBAsAYAwYGGYGzMbYZmZmhxMGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtmZm2mZ2mBAsAYAwYGmBzYmZDLzMzMMGGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAgZ2AmxMzGwMzwYGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGEAAwCgBAjZ2AmxMzGwMzwYGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtmZm2mZ2mBAsAYAwYmNgZMzshlZmZGGzYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrBBAAsAYAwYGGYGzMbAzMDjZMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtmZm2mZ2mBAsAYAAzsZgZMzshlZmZGGzYwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAgZ2AmxMzGwMzYGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1gAAAWAMAYMDDMjZmNgZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGGDAAAAAAjysMDzM2Gz2wMbzYMGDzYhtBgZZ2mZmtmZm2mZ2mBAsAYAYGzwMYGzMbYZmZmhxwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYMGDzYhNAMLz2Mzs1Mz02MzyMAgFADAGzwAzYmZDLzMzMMGGMA",
            ["n"] = 1,
        },
    },
    ["PALADIN_RETRIBUTION_RAID"] = {
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxCbAYWmtZmZrZmptZmtZAALAGAMmhBmxMzGWmZmZMjhBD",
            ["n"] = 5,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxYMGmxGbAAAZmptZmtZAAbAGAMmhBmxMzGWmBDjZMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzYGAAAAAAzUmlZYmx2Y2GmZbGjxYYGLsBgZZ2mZmtGEAAwCgBAjZ2AmxMzGwMzwYGDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAVg1HmQqr1Dwlv86ljju8vCAAAAAQz22MzsMMzAAAAAAwoMmhZGbDz2wMbzYMmZYGbsNAAgMz02Mz2MAgNADAzYGmBzYMbYZGMMmxgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZZbmZWGzMzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtGEAAwCgBAMzGwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAwoZbbmZWGzMzAAAAAAYmyYGmZsNmthZ2mxMjxwMWYDAzysNzMbNzMtNzsNDAYBwAgxMMwMmZ2wyMzMDjhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYEAzbn3egSOtoSwvPw1U1vTLAAAAAANbbzMzyYGzAAAAAAYmysMDzM2Gz2wMbzYmxYYGLsBgZZ2mZmtmZm2MYAALAGAMmxMwMmZ2AmZGGDDG",
            ["n"] = 1,
        },
    },
    ["WARRIOR_ARMS_MYTHICPLUS"] = {
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzYmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxy2ALgBMDTIzgNwMDjtBWmZbAmZAwMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZbZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2ALgBMDTIzgNwMDDDmlZ2GgZGAMDDA",
            ["n"] = 2,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZYmZbZmZmZYGzMAAAAAmZZmBmwYZZgFwAmhJkZwGYmhhBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAgBNMGzMbLzMzMDzYmBAAAAwYZmBmwYZbgFwAmhJkZwGYmx2wgZZmtBYmBAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZYmZbZmZmZwYmBAAAAwYZmBmwYZbgFwAmhJkZwGYmhx2gZZmtBYmBAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZzMzMzYmxMDAAAAgxyMDMhxy2sZmlhFDDzMz0GNzgNwMDDDmlZ2GMzMzAgZYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMz8AmZGAAAghphxwMbLzMzMjZGzMAAAAAmZZmBmwYZZgFwAmhJkZwGYmhhBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzYmZGAAAghphZGzMWmZmZGmxMDAAAAgZWmZgJMW2GYBMgZYCZgNwMDjlBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZbZmZmZYGzMAAAAAGLzMwEGLbDsBGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzYmZGAAAghphBzMbLzMzMDzYmBAAAAwMLzMwEGLbDsAGwMMhMD2AzMMWGYZmtBYmBAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzYmZGAAAghphZGmxyMzMzwMmZAAAAAMzyMDMhxy2ALgBMDTIzgNwMDjtBWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMDzMLLzMzMDzYmBAAAAwMLzMwEGLLDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmxyMzMzgxMDAAAAgZWmZgJMW2GYBMgZYCZGsBmZYsNYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMmZGAAAghphZwMbmZmZGzMmZAAAAAMzyMDIMWWGYBMgZYCZGsBmZYsNwyMLDwMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZzMzMzwMmZAAAAAMWmZgJMW2GYBMgZYCZGsBmZsMMYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxwMbLzMzMDzYmBAAAAwYZmBmwYZb2MzywihhZmZajmZwGYmxywgZZmtBzMzMAYGGA",
            ["n"] = 1,
        },
    },
    ["WARRIOR_ARMS_RAID"] = {
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmxyMzMzgxMDAAAAgZWmZgJMWWmFsAGwMMhMD2AzMM2GMLzsNAzMAYGGA",
            ["n"] = 5,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYmZbZmZmZwYmBAAAAwMLzMwEGLLDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 4,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFz8AmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDMhxyysgFwAmhJkZwGYmhx2ALzsNAzMAYGGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphxYmZzMzMzYmxMDAAAAgxyMDMhxy2AbgBMDTIzgNwMDDDmlZ2GgZGAMDDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMmZGAAAghphZGzMWmZmZGMmZAAAAAMzyMDIMWWGYBMgZYCZGsBmZYsNwyMLDwMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMzMzMDAAAghphZYGLLzMzMDzYmBAAAAwMLzMgsYssMwCYAzwEyMYDMzgxYwMGgZGAmZYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzYmZGAAAghphZGmZbZmZmZYGzMAAAAAGLzMwEGLbDsAGwMMhMD2AzMMMYWmZbAmZAwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdDzMzsMz8AmZGAAAghphxwMbLzMzMjZGzMAAAAAmZZmBmwYZZ2MzywihhZmZajmZwGYmhhBWmZbwMzMDAmhBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcEASWsDSHNyPDXnbxuIhH3ZdjZmZmFzwMzAAAAMMNMzYGWmZmZGMmZAAAAAMzyMDMhxyyALgBMDTIzgNwMDmtBzyMbDwMDAzMMA",
            ["n"] = 1,
        },
    },
    ["WARRIOR_PROTECTION_MYTHICPLUS"] = {
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYGLzMzMDzYmBAAAALDAzYAGstBbLGNmBwsEzsBzMmBzCAMzAAwAGD",
            ["n"] = 3,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZYmZmZGzmZmlhxY0wMzstMjZmxMMzAAAAglZGgZMAD22mxsssMamZYGWmlGzsAjZmhBAYmZmBAYgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzMmZmZmxsZmZZYMmpZMzMbMzMzAmZAAAAwyMDwMGgB2gtFjGzAY2iZ2wMYGmZDAmZAAwAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzgZmZmxsYmZZGjxoxMGWMzMzYGmZAAAAwyMDwMGgBbbzYWW2GNzMMDLzSjZ2wMmZGMbAwMzMDAYGYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYmllZMzMmhZGAAAAsMGgZMADW2mxsssNamZYGWmlGzsBjZmhBAYmZmBAYgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmFzMLzYMGNmZGWMzMDzwMDAAAAWmZAmxAMYbbGzyyyoZmhZYZWaMzGMmZGGbAwMzMDAYGYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzMmZmxMzsZmZZGjxoxMGWmxMzYGmZAAAAgZGgZMAD22gtFjGzAYWiZ2gxMzgZDAmZAAYGYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZYMGNmxYZxMzMjZYmBAAAALzMAzYAGYDWWMaMDgZJmZDGzMDGAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZYMGNmxYbxMzMjZYmBAAAALzMAzYAGYDWWMaMDgZJmZDGzMDDAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmNzMLzYMGNmxYbxMzMjZYmBAAAALzMAzYAGYDWWMaMDgZJmZDGzMDGAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzMmZmxMmNzMLzYMGNmxwiZmZGzwMDAAAAWmZAmxAMYbbGzyy2oZmhZYZWaMzGMmZGGLAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzMzMzMzMmNzMLDjxMhZmZzMzMzYGmZAAAAwyMDwMGgBbLzYWW2GNzMMDLzWjZ2AmZGGbAwMzMDAAYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYMzMzMmNzMLzYMGNmxwiZmZGzwMDAAAAWmZAmxAMYbbGzyyyoZmhZYZWaMzGMmZGMbAwMzMDAYGYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzYmZmZmxsZmZZGjxoxMGWMzMzYGmZAAAAwyMDwMGgB2glFjGzAYWiZ2AmZGMbAwMDAAzAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzMzY2MzsMMGjGzYGLmZmZMDzMAAAAYZmBYGDwAbwyiRjZAMbxMbAjZYmNAYmBAADMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZwMzMzY2MzsMjxYEmZYZmZmZYGzMAAAAYZMAzYAGYDWWMaMDgZLmZDmZmZwsBAzMAAMDMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAGzwMzMzMmNzMLzYMGNmxYbZGzMjZGzMAAAAYZmBYGDwAbwyiRjZAMLxMbwYMDGAwMDAAzAjB",
            ["n"] = 1,
        },
    },
    ["WARRIOR_PROTECTION_RAID"] = {
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAzMDzMzMzY2MzsMMGjGmZssMzMzMMjZGAAAAsMGgZMAD22mxsssNamZYGWmlGzsBzYmBDAYmBAgBMG",
            ["n"] = 3,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYGLzMzMDzYmBAAAALDAzYAGstBbLGNmBwsEzsBzMmBzCAMzAAwAGD",
            ["n"] = 3,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLzgxMNMGMzwMYYGAAAAsMGgZ2GgB2glFjGzAY2iZ2gZAYDAmZAAwADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmZmZmxMmNjZZGjxMNMzwyMzMzgxMDAAAAWGDwMGgB2glFjGzAY2iZ2gZMzwYDAmZAAYAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLDjxMNMzwyYmZGmxMDAAAA2GDwMbDwAbw2iRjZAMbxMbYmxMDmNAYmBAgBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3ZdnBAAmZmxMzMmxsZMLDjxMNMzYbZMzMDGzMAAAAYZMAzsNAD22mxstsNamZYG2mtGzshZGzMM2AgZmZGAwAGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAzMzYmZGzY2MmlhxYmGmZYZMzMDzYmBAAAAbjBYGDwAbw2iRjZAMbxMbYmxMDmNAYmBAgBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZGzMzYGzmZmlZMGjGzYGLzMzMDzYmBAAAALDAzYAGYD2WMaMDgZJmZDmZMDmFAYmBAgBMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZYmZmZGzmZmlhxY0wMzstMjZmxMMzAAAAglZGgZMAD22mxsssMamZYGWmlGzsAjZmhBAYmZmBAYgxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkEASWsDSHNyPDXnbxuIhH3Zd3yAAAjZmxMzYGzmZmlhxY0wYGLzMzMjZYmBAAAALzMAzYAGstNjZZZb0MzwMsMbNmZBGzMDjNAYmZmBAYgxA",
            ["n"] = 1,
        },
    },
    ["HUNTER_BEASTMASTERY_MYTHICPLUS"] = {
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLDNDAAAAAAAAMjxAmZjAmFw2AA",
            ["n"] = 3,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYZmZMjZwYaGAAAAAAAAYGjBMzGBMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAYGjhZmZ2IgZBsNAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYzMjZMDGTzAAAAAAAAAzYMgZ2IwMLglBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZYMDLjpZAAAAAAAAgZMGwMbEwsA2GAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZYMDLjpZAAAAAAAAgHYMGwMbEGmFw2AA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAAPwYMgZ2IwMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAAzYMgZ2IgZBsNAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZYbMNDAAAAAAAA8AjxAmZjAmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGzMzsYGzMzMjZGMzYmhZGzMzYzMjZMDbDNDAAAAAAAAMzMGmZmZjAmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYxsMjZmhFDLwMLGaGbAAYGzMzsMzwMzMjZGMzYmhZGzMzYzMjZMDGaGAAAAAAAAMzYmBMzGBMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYzMjZMDGTzAAAAAAAAAzYMgZ2IwMLgtBA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYzMjZMDGaGAAAAAAAAMzYMgZ2IMMLgtBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZYMDLDNDAAAAAAAAMjxwMzMbEGmFw2AA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGPwMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAgxYgZmZ2IYZmFwyAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDLjpZAAAAAAAAgHYMGwMbEwsA2GAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGzMzsMzwMzMjZGMzYmhZGzMzYbmZYMDLjpZAAAAAAAAwYMzwMzMbEwsA2GAA",
            ["n"] = 1,
        },
    },
    ["HUNTER_BEASTMASTERY_RAID"] = {
        {
            ["code"] = "C0PApei1JmYNvFfEFaN5bWuGKAMmxwCsBzwQDbAAYmx2MzsYGmZmZYGzMGmhZGzMzYbmZYMDLDNDAAAAgZAAAYegxMDYmNEwsA2GA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwGsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwGsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzwMGzYGMmmBAAAAAAAAjxMAzsR2YZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYzsNjZmhFDLMzMbGaGbAAYGPwMzs8AzYmZmZMzgZGzMMzYmZGbzMjZMDGTzAAAAAAAAgxYgZmZ2IYZmFwyAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGzMzsYGzMzMjZGMzYmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqYxsMjZmhFDbwMLGaGbAAYGzMzsYGzMzMjZGjZGmhZGzMzYbmZMjZwYaGAAAAAAAAMGDgZ2IYZmFw2AwA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAYEriH0bRqGs1Qj5St9dJoZxsMjZmhFDbwMLGaGbAAAMgZwAAAwYAAPADDQDAAAAAAAAAAAAEAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PApei1JmYNvFfEFaN5bWuGKALGzYYxwCMDDNsBAgZYbMz2MDzYmhhZGjZGzMjZMDzYMjZwYaGAAAAAzAAAwYmZGwMbIbGmFw2AA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAo4YcvOcqUdzB9zV+NhSAcYzsAGwAGAyYBAAjhZmZxMMzYmhZmZmZMDzMmxMMjxMmZ4BMZAAAAAAzAAAwYmxwMDQwyMLAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PApei1JmYNvFfEFaN5bWuGKYzYgBAYYDyYBAAzw2YmlZGmxMDDzMGzMmZGDDmxYGGgmBAAAAwMAAAMGDMzAEwsAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsBzwQDbAAYGmZmlHYGmxMDzYmxYmhZGzMzgZGzYGMmmBAAAAMDAAAmZGDYmNCDzCYbAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0PAD57yiELKEty14ekTDtZEqAMmxwCsAzwQDbAAYGzMzsMzwMzMjZGMzYmhZGzMzYZmZMjZwYaGAAAAAAAAYGjBMzGBMLgtBA",
            ["n"] = 1,
        },
    },
    ["HUNTER_MARKSMANSHIP_MYTHICPLUS"] = {
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwGMwMGNWGQmBbAAAAAAAAgZMzMjtZMzMmhlx0MGMLbLzMzMzMzMzCzsMMDAAgHYMGAmxGYA2YmtZMA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZ2GDjZMTjlZG2yMMbAAAAAAAAgZMjZsNjZmxMYMNjBz222MzMzMzMzgZWGmBAAYegZGGzMYGbMMALMz2MG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMjFjZmxMYMNjBzymZmZmZmZmZhZWGmZAAAmZGDAzYDMAbMz2MG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMjNjZmxMsMmmxgZZzMzMzMzMzswMLDzMAAAzYMAMjNwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZ2GDjZMTjlZG2yMMbAAAAAAAAgZMzMDzYmZMDGTzYwsttMzMzMzMzMYmlBzAAA8AzMMmZwM2YMDwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMzy2MmZGzgx0MGMbbbzMzMzMzMDmZZYGAAgxMDDgZsBGgNmZbGD",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGTzYwsttNzMzMzMzMwsMMDAAwMzMMAmxGDDwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZ2GDjZMTjlZG2yMMbAAAAAAAAgZMzMDzYmZMDGTzYwsttNzMzMzMzMYmlhZAAA8AzMMmZwM2YMDwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMjNjZmxMsNmmxgZZbbmZmZmZmZWYmlhZAAAMjxAwM2ADwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZWGDjZMTjlZGWyMMbAAAAAAAAgZMzMjNjZmxMsMmmxgZZbbmZmZmZmZWYmlhZAAAMjxwMDmxGYA2YmtZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMDGzMjZYZMNjBzy2yMzMzMzMzswMLDzAAAMzYMAMjNwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAwYMMAmxGWmBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzwMmZGzgx0MGMbbmZmZmZmZmFMLDzAAAMGzYAMjtNWmBYhZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMziZMzMmBjpZMY22WmZmZmZmZGMzywMAAAjZmxAYGbgBYhZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMDzYmZMDGTzYwsttNzMzMzMzMwsMMDAAgZmhBwM2YMDwGzsNjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMzMziZMzMmBjpZMY22MzMzMzMzMYmlhZGAAwYmhBwM2YYA2YmtZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZYGzMjZwYaGDmtNzMzMzMzMDmZZYmBAAMmZmZAMjNGGgNmZbGD",
            ["n"] = 1,
        },
    },
    ["HUNTER_MARKSMANSHIP_RAID"] = {
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAwYMMAmxGWmBYjZ2mxA",
            ["n"] = 2,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAwYMjBwM2wyMAYmtZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzYGbzYmZMDGTzYwsttMzMzMzMzMYmlhZAAAGjZMAmxGWmBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PApei1JmYNvFfEFaN5bWuGKwCMwMGNWGQmBbAAAAAAAAAzYGzYxYmZMDGTzYwstZmZYmZmZmZhZWGmZAAAzMzAAzM2YYA2YmZG",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzYbGzMjZwYaGDmttlZmZmZmZmBzsMMDAAw8AjhBwM2wiBYjZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYZZ2GDjZMTjlZgMDzGAAAAAAAAYGzMzwMmZGzgx0MGMbbmZmZmZmZmFMLDzAAAMGzYAMjtNWmBYhZ2mxA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYG8AmmxgZbzMzMzMzMzswMLDzAAAMmZGDgZsxwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqwCMwMGNWGQmBbAAAAAAAAgZMjZW2mxMzYG8AmmxgZbbZmZmZmZmZwMLDzAAAMmZGDgZsxwAsxMbzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C4PAD57yiELKEty14ekTDtZEqYbZ2GDjZMTjlZG2yMMbAAAAAAAAgZMjZsNjZmxMYMNjBz222MzMzMzMzgZWGmBAAYegZGGzMYGbMMALMz2MG",
            ["n"] = 1,
        },
    },
    ["PRIEST_SHADOW_MYTHICPLUS"] = {
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIDLmpxAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZgZaMwMAzsZGNbGAyYsAgZGwYmZGzGzstMAzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtlgZjBAGMmZmxsNmBzMYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGYyAz0MDMDwMbmRzmBgMGLAYmBMmZmxsxMbLDwMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZWmZGzM2MzYmZGbIDLbz0AMzMDAEgZb22CmNGAYwYmZGz2YGMzgZwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDPAAAAAAAAAAAAghZxMmZbmxMz2MGDz2MzYmZGbIzATjZwMAzsZGNbGAyYsAgZGDGzMzY2YmtlBYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDzAAAAAAAAAAAAMMLmxYbmhZ2mZYG2mZGzMzYjJDLmpBYGgZ2MjmNDAZMWAwMjBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDzAAAAAAAAAAAAMmZxMGbzMGz2MGzw2MzYmZGYyAz0MzgZAmZzMa2MAkxYBAzMgxMzMmNmZbZAMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGGaGYmmZgZAmZzMa2MAkxYBAzMgxMzMmNmZbZAMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzw2MNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMzYM2mZGzMzYDZGLmpBYmZGAIAz2stEMbMAwgxMzMmNmBzMYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZWmZGzM2mxYmZGQmhtZaAmZmBACwsNbbBzGDAMYmZmZMbjZwMDmBDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDPAAAAAAAAAAAAgxMLmxMbzMmZWmZGzw2MzYmZGbIDLmpZAzAMzmZ0sZAIjxCAgBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzM2mxYmZGbIDLbz0AMDwMbmRzmBgMGLAYmBMmZmxswMbLDwMYA",
            ["n"] = 1,
        },
    },
    ["PRIEST_SHADOW_RAID"] = {
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMjZGAAAAAAAAAAAghZxMGLzMMzyMDzw2MzYmZGbIzYxMNAzAMziZ0sZAIjxCAmZAjZmZMbjZ2WGgZwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CIQA4VPTJ8eQb8/qEm8PyGu4yMMjZGAAAAAAAAAAAgxYxMGLzMMz2MDzw2MzYmZGbIzYxMNAzAMziZ0sZAIjxCAmBYMzMjZbMz2yAMDGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMGAAAAAAAAAAAAjZZmxYZmxMzyMDzwmBzMzMQmhtZaMwMzMYmNzoZzgZb22yYmNGAYwMzMzMz2YGMzgZwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDPAAAAAAAAAAAAgxMLmxMbzMmZWmZGzw2MzYmZGbIDLmpZAzAMzmZ0sZAIjxCAgBjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMzyMGzw2MzYmZGbIzYxMNAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbIDLmpxAzAMzmZ0sZAIjxCAmZAjZmZMbMz2yAMDGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzw2MzYmZGbMZgZaMwMAzsZGNbGAyYsAgZGwYmZGzGzstMAzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOjZMAAAAAAAAAAAAYMLzMGbzMmZ2mZGzw2MzYmZGbIzYxMNAzMzAABY2mtlgZjBAGMmZmxsNmBzMYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CIQAR03Gt7xPmcDNOjs2Zlb3yOMDDAAAAAAAAAAAAmZxMmZbmxMz2MGzY2MzYmZGYyAz0MDMDwMbmRzmBgMGLAYmBMmZmxsxMbLDwMYA",
            ["n"] = 1,
        },
    },
    ["ROGUE_SUBTLETY_MYTHICPLUS"] = {
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 4,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbZMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbZMzMzMjBjZ2GAAAAmhxsZWGYALglhJkZBGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbLzMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbbmZMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbLjxMDjZmZmZGGbzYGbLzMzMzMjBjZ2GAAAAGMmNzyMmtZYswwyMLTL0ysgZYmZmBzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbLjxMDjZmZmZGGbzYGbLzMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbZmZmZmZMYMz2AAAAwgxsYWmxsNYswwyMLTL0ysADzMmBzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYmZbZmZmZmZMYMz2AAAAwgxsZWmxsMDjFGWmZbaj2mFYYmZmBzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbLzMzMzMjBjZWGAAAAGMmNzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYG2mZmZmZGDGzsNAAAAmBjZxsMjZbGGLMsMzy0CtMLYGmZmZwMGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZWGAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
    },
    ["ROGUE_SUBTLETY_RAID"] = {
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMjZYmZmZG8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 3,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDDzMzMzw8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMjZwDMzMzYMbjZmZbbMzMzMjBjZWGAAAAmhxAGzmhBGYW0CtYDGwMDmxA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUQAA0tw2gAD7pPTLoW5IGZDeAAMAAAAAAAzyMzsMNmZZmxMGDDzMzMMmtxYGbbzMjZmZMYsMbDAAAAzgBwY2MMwAziWoFbMG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQAByFP3pExAEG41/8+e6b8fDgx2MAAAAAwsMGLTMbbjxMjZwDMzMzYMbjZGbbzMzMzMjBjZ2GAAAAGMGwY2MMwAziWoFbYGwMDmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMjZwMzMzYMbDzw2MzMzMzYwYmtBAAAwMYMgxsZYgBmFtQL2wMgZGMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsNGLTMbbjxMjZYmZmZG8AbzYGbbzMzMzMjBjZ2GAAAAGMmFzyADYBsMMhMLYGmZAmxA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQAphyM11FofNMFa1K3vFEDUCgx2MAAAAAwsMGLTMbbjxMjZwMzMzYMbDzw2MzMzMzYwYmtBAAAwMYMgxsZYgBmFtQL2wMgZGMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUQA5HmDzx68KWyrW/8Y781L7Dgx2MAAAAAwsMGLTMbbjxMDjZmZmZGGbzYmZbZMzMzMjBjZ2GAAAAmhxsZWGYALglhJkZBGmZAmxA",
            ["n"] = 1,
        },
    },
    ["DRUID_FERAL_MYTHICPLUS"] = {
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 5,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzyYmZGjZMDAAAAAgBGAAAABAz2MLNLzssBmZAWMDGAAzMAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYLY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZpZZmlFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzCzMzYMzAAAAAAgBGAAAABAz2MLNLzssBmZAWMzwAAYmBAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZ2MzMzMGzGWmZZmZm5BmZAAAAYJY2gxMjaGzCzMzYMjZAAAAAAMwAAAAIAY2mZpZZmlNwMDwiZGGAAzMAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZrZZmtFYmZAWYwAAAYmNMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwghxYmZmxsxDsMz2MzMmZGAAAAWCmFDjZG1MmlxMzMGzYAAAAAAYgBAAAQzsMLzMzMbzs0sMz2CYmBYxMYAAMzgZ2wA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZ2mZmZ2mZpZZmtFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwgZMGzMzMmtFWGbzMzYmZAAAAYJY2MMmZUzYWmZmZGjZYAAAAAAMwAAAAIAY2mZpZZmlNwMPAwiZwAAYmBAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZ2MzMzMzY2MWGbzYm5BmZAAAAYJY2gxMjaGzCzMzYMzMAAAAAAAGAAAABAz2MLNLzssBmZAWMzwAAYmBAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZYmZmZMmNjtZWmxMjZGAAAAWCmNDMzM1MmFzMzMLjZYAAAAAAMwAAAAoZWmlZmZmlZWaWmZZBmZGgFGMAAmZwMbYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWYmZmlxMMAAAAAAGYAAAA0MLzyMzMgALwMzAswMMAAAmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWmZmZmlxMMAAAAAAGYAAAA0MLzyMzMgALgZGgFGMAAAmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2MzMzMGzmx2YbGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 1,
        },
    },
    ["DRUID_FERAL_RAID"] = {
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZMGzMjxstMzygZmZmZGAAAA2CmNYMzomxsMzMzMGz8ADAAAAAAgBAAAQzsMLzMzMbzs0sMzyGYmBYxMYAAMzgZWwA",
            ["n"] = 6,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAAjZwMzMzMmtl5BWGbzYm5BmZAAAAYLY2gxMjaGzyYmZGjZmBAAAAAAwAAAAoZWmlZmZmtZWa2mZZDMzAsYGMAAmZwMLYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYLY2MMmZUzYWMzMzYMDAAAAAAMwAAAAIAY2mZpZbmlNYmZAWMDGAAzMAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGAkuH5GdQpDrgY32rlVGnyqBAAAAAAmZb2MzGzMzMbzGjtZmZmHYmBAAAAAYLY2AzMjaGzCbzMjZmZmBAAAAAAAAAABoZWmlZmtBEYBMzAYhBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzyYmZGjZMDAAAAAgBGAAAABAz2MLNLzssBmZAWMDGAAzMAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYJY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmBEYBmZGgFGMAAAmZDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAgZmZ2YmZmxY2M2mZZGzMmZAAAAYLY2M8AmZUzYWMzMzsMmhBAAAAAwADAAAgmZZWmZmZ2mZpZZmlFYmZAWYwAAYmBzshB",
            ["n"] = 1,
        },
        {
            ["code"] = "CcGADBD3hSPCL9Y9gz68WcKvMAAAAAAwYMjxYmZMmtFWGbzMzYmZAAAAYJY2gxMjaGzCzMzYMzAAAAAAgBGAAAABAz2MLNLzssBmZAWMzwAAYmBAD",
            ["n"] = 1,
        },
    },
    ["DRUID_GUARDIAN_MYTHICPLUS"] = {
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMAAAAAAMjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 5,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmZmFzMjZWmZxMPwMLLDMbmxoJyMzyYmZmlxMAAAAAAYsZGYZbmBjZZAMFAAAYzYmBYxYYgZxCAzMAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMMAAAAAgZsZALbzMYMLDgpmZbWmZmBAwGmZAWMwAWsAwMzMLwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxs4BGjZ2mZxMMLLDMbMGNRzMzyMzMzYMjZAAAAAAzYbGwy2MDGz2AYqZWmlZmZAAshZMgFzgBsYxAMzMzGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMGAAAAAgZsZALbzMYMLDgpAAAAbYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJyMzyYmZmlxMPwAAAAAAMjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMzyMLGmZZZgZzwoJamZWmZmZmlxMAAAAAAMjNDYZbmBjZZAMFAAAYDzMALGDDYxCAzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZbGGNRzMziZmZmlxMAAAAAwgZsZAbbzMYMLDgpmZZWmZmBAwGmZAWMwAWsAwMzMLwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzAW2mZwY2GATNDYAAwGmZAWMDGwmltBYmxAG",
            ["n"] = 1,
        },
    },
    ["DRUID_GUARDIAN_RAID"] = {
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMPAAAAAAgZsYAbbzMYMLDgpmZZWmZmBAwGm5BAWMDGwiFAmZmZDG",
            ["n"] = 3,
        },
        {
            ["code"] = "CgGA8cL7tpvige+kkmGM9zUPWDAAAAAAAAAAAgZmZmFzMjZWmZx4BmZZZgZzwoJyMzyYmZmlxMDAAAAAAmNzALbzMYMLDgpAAAAbYmBYxADmZxyGgZGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmZmFzMjZWmZxwMLLDMbGGNRmZWmZmZmlxMGAAAAAgZsZGYZbmBjZZAMFAAAYDzMALGDDMLWMAzMAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGA8cL7tpvige+kkmGM9zUPWDAAAAAAAAAAAgZmxsMmZMz2MLzgx2AYGjmoZmZZmZmZMmxMAAAAAgZsNDYZbmBjZbAM1MLzyMzMAA2wMPwAWMDGwiFDwMzMbwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGA8cL7tpvige+kkmGM9zUPWDAAAAAAAAAAAgZmxsMPwYMzmZZGMWGY2YMaimZmlZmZmxYGzAAAAAAmx2MgltZGMmtBwUAAAgNMzDAsYGMgFLbDwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2mZxgZZbgZzwoJamZWmZmZGjZMDAAAAAYGLzAW2mZwYWGATNzysMzMDAgNMzDAsYGMwsYBgZmZ2gB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsMmZMWMLzMPgZZZgZzMGNRzMziZmZmlxMAAAAAAMsMDYZbmBjZZAMFAAAYDz8ADYxMYwgltBYmBwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWMLm5BmZZZgZDGNRzMzyMzMzYMjZAAAAAAzYZGw22MDGz2AYKAAAwGmZAWMDGALAMzAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmZmlZGPgZWmZxMmZZZgZzwoJamZWmZmZmlZmBAAAAAAjFDYZbmBjZZAM1MLzyMzMAA2wMPAwiZwA2sAwMzMbwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZ2MLGMLLDMbwoJamZWmZmZGjZMDAAAAAYGLzAW2mZwY2GATNDYAAwGmZAWMDGwmltBYmxAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWmZxMPgZZZgZjxoJamZWmZmZGjZMDAAAAAYGLzA22mZwYWGATNzysMzMDAgNMjBsYGMAWAYmZmNYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYGjZWMLmhZZZgZjxoJamZWmZmZGjZMDAAAAAYYZGwy2MDGzyAYqZWmlZmZAAshZMgFzgBjFLbAmZmZDG",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsMmZMziZZGPwMWGY2MMaiMzsMzMzMLjZMAAAAAAzYZGwy2MDGzyAYKAAAwGmZAWMDGwiFAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAgZmxsYmZMziZxMmZZZgZzwoJamZWmZmZmlxMAAAAAAMzsZALbzMYMLDgpAAAAbYmHAYxYYALWAYmBwA",
            ["n"] = 1,
        },
    },
    ["DRUID_RESTORATION_MYTHICPLUS"] = {
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AMmNsZbGAAAAAAAAAAsYoZbmx0MDwsYmZmhhBAAAAADYAmBstMWw0MzyAAY2mZrZbmFbMzMGmZ2ANDAwMDADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbzQzGjpZGDMLzMzMDDzAAAAAwAAAAABAAMbzs0sNzmNGz8ADmZB0MAAzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNmBmNmNbzAAAAAAAAAAgFDNbzMmmZAmFzMzYxwDYAAAAAMAAzAAQAAAz2MLNbzsZjZm5BGmZ2ANDAwMDADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMzsgNbzAAAAAAAAAAglBNbGmmZMDmFzMzMLzADAAAAAAAGAACAAY2mZrZbmNbMzMDmZWwoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMmNjNbzAAAAAAAAAAgFDNbzw0MAmlZmZmZxwAAAAAgBAYGw22YBTzMLDAgZbmtmtZ2sxYmZYmZD0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZzw0MjZwsYmZmZZGegZAAAAAAAwAAQAAAz2MbNbzsYjxMDMzCoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AMmNsZbGAAAAAAAAAAsYoZbmx0MDwsYmZGLGeADAAAAgBMAGwy2YBTzMLDAgZbmtmtZWswYmZYmZD0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmxYmZmZMbDDjZjZz2MAAAAAAAAAAYxQz2MMNzAPgZxMzMWM8ADAAAAADAYGAAEAAwsNzWz2ML2YmZGMzsBaGAgZGAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmZmthZwsZsZbGAAAAAAAAAAsANbzw0MgxswMzMLGmBAAAAgBAYAAQAAAz2MbNbzsZjxMDGzGGNDAwMDADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbGa2MjpZAPgZZmZmZYYGAAAAAGAAAAIAAgZbmlmtZ2sxYmZwMwoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMjxMLzMjZmxsNMmxwYjZAAAAAAAAAAwygmNGTzMGGziZmZGzwMDAAAAAAAA22GLYamZZAAMbzs0sNzmNGz8AYmZB0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMmNjNbzAAAAAAAAAAgFDNbzw0MDwswMzMLGmBAAAAgBAYGADQAAAz2MbNbzsZjZm5BGmZgRzAAMzAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AwsZsZbGAAAAAAAAAAsYoZzMmmZAmFzMzMLGGAAAAAMgBwA22GLYamZZAAMbzs0sNzmFGzMDzMbgmBAzMzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZbMjZmxsNMDzshNbzAAAAAAAAAAgNDNbmx0MDwsMzMzMM8AzAAAAAYAAMAAEAAwsNzWz2ML2YMzMMzAjmBAYmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNMMmlZsZbGAAAAAAAAAAsMoZDmmhZMmFzMzMmhZGAAAAAAAMAAEAAwsMzWz2ML2YMzAzsAaGAgZGAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmxYmZmZMbDDjZxYz2MAAAAAAAAAAYxQz2MjpZGgZhZmxihHYGAAAAADAYGgttxCmmZWGAAz2MbNLzsZjxMPwwMzmBNDAmZmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZbMjZmxsNMDmNjNbzAAAAAAAAAAglBNbzw0MjBmFzMzYxwDYAAAAAMAAzAWWGLYamZZAAMbzs1sNzmNmZmBzMLgmBAYmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsYsNmBAAAAAAAAAALDa2YMNzY4BMLzMzMzihHYAAAAAAAAAAEAAwsNzSz2Mb2YMzMYmFQzAAMzAwA",
            ["n"] = 1,
        },
    },
    ["DRUID_RESTORATION_RAID"] = {
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MzMzYWGmZmxixCzAAAAAAAAAAglBNbmx0MDDmlxMzMMMDAAAAADAgBstM2w0MzyAAAEwCzMzgZGY0MAYmBAA",
            ["n"] = 3,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2mZMNzYgZZmZmZYYmBAAAAwAAAYbbshpZmlBAwsMzSz2Mb2YMzDAzA0MAYmZmBgB",
            ["n"] = 2,
        },
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MmZGz2wDYmZYswMAAAAAAAAAAYZQzmZMNzAjZbmZmZYYGAAAAAAAAAABAAMbzs0sNzmNmZmBzMANDAwMDAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AwshNbzAAAAAAAAAAgFDNbzMmmBwsMzMzMLGYAAAAAMAgZGAACAAY2mZrZbmFbMm5BGmZ2MoZAAmZAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MzMzY2GmZmxixCzAAAAAAAAAAglBNbzMmmZAmlxMzMMMDAAAAADAgBstM2w0MzyAAYWmZrZbmNLMzMDmZgRzAgZmZGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGA8cL7tpvige+kkmGM9zUPWPjxMLz2MmZGzywMzMzixCzAAAAAAAAAAglBNbmx0MDDmlxMzMMMDAAAAADAgBstM2w0MzyAAAEwCzMzgZGY0MAYmBAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2mZMNzYgZbmZmZYYmBAAAAwAAAYbbshpZmlBAwsMzWz2Mb2YMzDAzA0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZbmZMzMmthZMmNsNmBAAAAAAAAAALDa2MjpZGDMLzMzMjZYmBAAAAAAAAbbjNMNzsMAAmlZWa2mZzGjZegBzA0MAYmZmBgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthHgZmNjtxMAAAAAAAAAAYZQzmZMNzYgZZmZmZMDzMAAAAAAAAYbbshpZmlBAwsMzSz2Mb2YMzDMYGgmBAzMzMAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMMMmZZMjZmxsNz8AMmNsZbGAAAAAAAAAAsYoZbmx0MDwsYmZmhhBAAAAADYAmBstMWw0MzyAAY2mZrZbmFbMzMGmZ2ANDAwMDADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkGADBD3hSPCL9Y9gz68WcKvMYMmZZmZMzMmthZwsZsNmBAAAAAAAAAAbzQzGjpZGDMLzMzMDDzAAAAAwAAAAABAAMbzs0sNzmNGz8ADmZB0MAAzMAMA",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DESTRUCTION_MYTHICPLUS"] = {
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmlZmZmFjZbxDMAAYGjZmZxGMwsY0YGAzWsxAAAjBGbAAzMYMjZsBAAYmZGAAGDD",
            ["n"] = 2,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+ixDMzoZzM2mZmZWmtZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDLzWjFGAAYMDDAwMzMDGzYmZDAAwMzMAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMziNYgZxoxMAmtYjBAAGDM2AAmZwYGzYDAAwMzMAAMGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzMzysYmZmFjxiZAAwMzYmZWsADMLGNmBwsFbMAAwYgxGAwMDMzYMAAAMzMDAAjhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMz2MzYWmtZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDLzWjFGAAYMYYDAzMzMYMjZsBAAYmZGAAYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzDMzoZzM2mZGzmtZmZmFzMLLjBAAzYMzMbgxMGWIDsNsQjFGAAYMDDAwMDw4BGzMbAAAmZmZAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2mZGzysNzMzsYmZZZegBAAzYMzMLWwMzYmllRzMDbDbzWjFGAAYMYAAmZmZwYGzYDAAwMzMAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWmNzMzsYmZZZMAAYGjZmZBMmxwCZgthFaswAAAjBDAwMDwYGzMbAAAmZmBAAzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMjZmZmlZZmZmZxMzyyYAAwMGzMzmNMzMmZZZ0Mzw2wys1YhBAAGDG2AwMzMDmZGGbAAAmZmBAAGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmxmZGzysZmZmFzMLLjBAAzYMzMLgxMGWIDsNsQjFGAAYMDDAwMDwYGzMbAAAmZmZAA4BGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmlZmZmFjZbxMAAYGjZmZxGMwsY0YGAzWsxAAAjBYDAYmBjZMjNAAAzMzAAwYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+iZmZmpZzM2mZGz2sMzMzsYMLLmBAAzYMzML2gBmFjGzAY2iNGAAYMAbAAzMgZMGAAAmZmZAAMGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMMzoZxMzyMzYWmtZGzsYGLLjBAAzYMzMLWwMzYmltRzMDbDLzWjFGAAYMDDbAYmZmBjZMzsBAAYmZGAAGDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmtZZmZmZxY2WMDAAmxYmZWsADMLGNmBwsFbMAAwYA2AAmZwMzgBAAgZmZGAAjhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlZZmZmZxY2WMDAAmxYmZWsADMLGNmBwsFbMAAwYA2AAmZwMzYMAAAMzMDAAjhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+iZmZGNLMMzMmlZZmZmZxYWWMDAAmxYmZWsgZmxMLLjmZG2GWmtGbMAAwYA2AwMzMDMzMjZBAAwMzMDAgxwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbmx2MzMzysYmZmFzMLLjBAAzYMzML2wMzYmllRzMDbDLzWjFGAAYMYGbAYmZmBjZYGAAAmZmBAAGG",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DESTRUCTION_RAID"] = {
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlZZmZmZxMz2CDAAmxYmZWsADMLGNmBwsFbMAAwYwwGAwMDmZGMAAAMzMzAAYMM",
            ["n"] = 2,
        },
        {
            ["code"] = "CsQAYIOwXTfhprvln24ZeRPDbMbGzYmZmRMbGGzmZmhZb2MGYWMbssMzMAAAAgZmZZZmZZYBGYWMaMDIzWshBAAAAAAwMzMGAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbM2mZGzysMzMzsYmZbhBAAzYMzMLWgBmFjGzAY2iNGAAYMYYDAYmBmZMGAAAmZmBAgxwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjhZmZmlZZmZmZxMz2iHYAAwMGzMziFYgZxoxMAmtYjBAAGDwGAwMDMzYMAAAMzMzAAYMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMjZmZmlZZmZmZxMzyyYAAwMGzMzmNMzMmZZZ0Mzw2wys1YhBAAGDG2AwMzMDmZGGbAAAmZmBAAGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAA81jxQD71lYhS/t8p6HgAAmZmZmZEzmBmtZmZY2mNzwMzsY2MWMzAAAAAzMDLzMzMgxMGWIDsNahGLYAAAAAAAMmZmBAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+ixDMzoZzM2mZmZWmtZmZmFzMLLjBAAzYMzMLWwMzYmllRzMDbDLzWjFGAAYMDDAwMzMDGzYmZDAAwMzMAAwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMzmZmZWmFzMzsYMWMDAAmZGzMziNYgZxoxMAmtYjBAAGDM2AAmZwYGzYDAAwMzMAAMGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzMzysYmZmFjxiZAAwMzYmZWsADMLGNmBwsFbMAAwYgxGAwMDMzYMAAAMzMDAAjhB",
            ["n"] = 1,
        },
    },
    ["PRIEST_HOLY_MYTHICPLUS"] = {
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmx2MmZAMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMbYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAjZWmhZmZGmhZMgZKAmZBDhxsNAjBWMzMLAaGz8AGDzMAzMDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzMzyMMzMzYbGzMsBzUDgZ2wQYMLDwYgFzMzCgmBMGMDwMjBGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMzYmZmx2MmZAMTBwMLzsMzkZbmZZAmZGsYMzCgmhhxgZAmZmBGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZmZmlxMjZGDzwYZmZmBAAAwYmlZwMzMMjZGDYmCgZWwQYMbDwYgFjBANjZGjBzAMzMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZm5BmlxMjZGjZGYZmZmBAAAwYmlZGzMzMMMzAYmCgZWwQYMbDwYgFDzCgmxMjxgZAmZmBGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMzMDgZKAmZBDhxsMAjBWMzMLAaGjxYwMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmxmxMD2wMFAzshhwYWGgxALGzsAoZMzYMYGgZmBMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMjBMTNAmZBDhxsMAjBWMzMLAaGmxYwMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYxwMzyYmxMjhZglZmZGAAAAzYWmBzMzwMjZAMTBwMbzsNzkZbmZbAmZGsYmZWA0MmZMGMz2ygZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzAbzMzMAAAAGzsMDmZmx2MmZAMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAghZmlxMjZGjZGYZmZmBAAAwwsMzYmZmh5BMzAYmCgZWwQYMbDwYgFjZWA0MmZMGMDwMzMwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZmxsMmZMzYYGYZmZmBAAAwwsMDzMzM2mxMDLwMFAzsMz2MTmtZmtBYmZwiZmZBQzYMGDmZbZwMzAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAgZmxsMmZMzYYGYZmZmBAAAwwsMDzMzM2mxMDgZKAmZBDhxsMAjBWMzMLAaGmxYwMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYxwMjhZMzYGzMGLzMzMAAAAGzsMDmZmBjZGshZqBwMLzsMzkZbmZZAmZGsYmZAoZMzDYMYGgZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYzMzYWGzMmZMMDsMzMzAAAAYYWmhZmZGmxMD2wMFAzsghwYWGgxALGzsAoZMzYMYGgZGDMA",
            ["n"] = 1,
        },
    },
    ["PRIEST_HOLY_RAID"] = {
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzAYmaAgZ2MTmNDAMGsZmZWA0MmZMGmZ2WGgBMA",
            ["n"] = 6,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwwsMDzMzMMDzYAzUAgZWMTmFDAMGsZmZWA0MmZMGmZ2WGgBMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZWGzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMbYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMmZAMTBwMLYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAgZmlxYMzMDzMzYZGmBAAAwMsMDzMzMYGzAYmaAgZWMTmFDAMGsZmZWA0MMjxwMz2yAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yCDAAAAAAYBmZ2GzMmZMMDzsMzYGAAAAzYWmBzMzwMMDgZqBwMbYIMmlBYMwiZmZBQzYMGDzMAzMzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEQAR03Gt7xPmcDNOjs2Zlb3yyYAAAAAAAMzMmlxMjZGDzALzMzMAAAAGzsMDmZmx2MmZAMTBwMLYIMmtBYMwiZmBgmxMjxgZAmZGwA",
            ["n"] = 1,
        },
    },
    ["MAGE_FIRE_MYTHICPLUS"] = {
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 3,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzMAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsNAMzQYMgZYMA",
            ["n"] = 3,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMjZAAgZMmZmZMzsMAMzQGjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwMLzMzsgZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMjZAAgZMmZmZMzsMAMzQGjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMmBAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMzMDAAMjxMzMjZmlBgZGaYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwMLzMzsgZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsNAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMzMDAAMjxMzMjZmlBgZGCjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMzAAAwAAmZmmlllZAA2MzM2mZmZGbAAAAAYxMzMzDAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlllZAA2MzM2GzMzAAAAAA2MzMzMAAYMjZMzMzMbDAzMEGjBGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMGAAAGAwMz0sssMDAwmZmx2YmZGLAAAAAYxMzMDAAMmxMMzMzsNAMzQGjxgZYMA",
            ["n"] = 1,
        },
    },
    ["MAGE_FIRE_RAID"] = {
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFmZGZmxAAAwAAmZmmlllZAA2MzM2GzMzYDAAAAALmZmZAAgxMmxMzMzsAgZGCjxgZYMA",
            ["n"] = 2,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzgZZmZmFmZGZmxAAAwAAmZmmlllZAA2MzM2GzMzYDAAAAALmZmZAAgxMmxMzMzsAgZGyYMGMDDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwYBAzMTzyyyMAAbmZGbzMzMDAAAAAYxMzMDAAMjxMzMjZmtBgZGyYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMzMDAAMjxMzMjZmlBgZGCjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAJHMkDNl9e4q1zfgySSx9jbGGbWwMzMzs4BYMzw0YMmZAAAAAAMzyMNzsMLQAAQWMmhZGzMzMzsYMzYGYmlZwswAAAAAAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMjZAAgZMmZmZMzsMAMzQGjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwMLzMzsgZGZmZGAAAGAwMz0sstNDAwmZmx2MzMzYDAAAAALmZmZAAgZMmZmZMzsMAMzQYMgZYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuZGGLzMzswMzIzMzAAAwAAmZmmlttZAA2MzM2mZmZGLAAAAAYxMjZAAgZMmZmZMzsMAMzQGjBMDjB",
            ["n"] = 1,
        },
        {
            ["code"] = "C8DAche08tHz49KSVf7iKFnyuNzwYZmZmFMzIzMmBAAwAAmZmmlttZAA2MzM2mZmZGbAAAAAYxMzMDAAMjxMzMjZmlBgZGaYMgZYMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_BLOOD_MYTHICPLUS"] = {
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMbzMz0MLmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzwMmZmhZbmZmmZxMjxMmBAAAAmZmZmZmZYGjBAjZmZGAAADMwMW0YZDktBsBYGzAAAmZwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMGMbzMz0MLzMjZmBAAAAwgZmZmZMzMjBAzMzMzAAAMzsNGGzYZpxy2ywklhhFAzYAAwMzMDYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZZmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmxgZbmZmmZZmZMzMGAAAAwMMzMzMjZGDAYmZmZGAAgZmtxwYGLLNW2WGmsNMsBYGDAAmZmZAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMGMbjZmmZZmZMzMGAAAAwMMzMzMjZGDAYmZmZGAAgZmtxwYGLLNWWWGmsNMsBYGDAAmZmZAjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbMz0MbzMjZmBAAAAwMMzMzMjZGDAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDYMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmZMbzMz0MLmZMzMAAAAAmhZmZmZMzYAAzMzMzAAAYgBmxiGLbgsNgNAzYAAAmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZZGjZmxAAAAAmhZmZmZMzYAAzMzMzAAAMzsNGGzYRjltlhJbDDbAmxAAgZmZGAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZZmZmmZxMjZmBAAAAwMMzMzMjZGDAYmZmZGAAgZmlxwYGLLNW22GmsNMsBYGDAAmZmZghB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZZmZmmZxMjZmxAAAAAmHgZmZmZMzMjBAjZmZGAAgZmtxwYGLLNW22GmsNMsBYGDAAmZmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZxMjZmBAAAAwMMzMzMjZGDAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyYmxMmZmhZbmZmmZzMjhxMAAAAwYmZmZmZMzYMAwMzMzAAAMzsNGGzYZpxyy2wkthhlBYGGAAmZmZAMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_BLOOD_RAID"] = {
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMLzMz0MLmZMmBAAAAYGzMzMzMjZGjBAmZmZGAAgZmtxwYGbLNW2WGmsMMsAYGGAAmZmZwMMA",
            ["n"] = 3,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzwMmZmhZbmZmmZxMjZmBAAAAwMMzMzMjZGDAYmZmZGAAADMwMW0YZDktBsBYGDAAwMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMGMLzMz0MLzMjZmBAAAAwgZmZmZMzMjBAzMzMzAAAMmtBGwSwywEYYBwMGAAMzAwYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyYmxMmZMMbzMz0MbmZMmxMAAAAwMzMzMzMDzYMAYMzMzAAAYgBmxiGLLgsNgNAzwAAAmZghB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAclESCN5uIs3wGGVadXqL3xwMzMDzYmZGmxMzMNzYYmxMGAAAAYmZmZmZGzmZmxAAAYmZmBAAAYgBmxoxyGILDYDgZwGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyYmxMmZmhZbmZmmZzMjhxMAAAAwYmZmZmZMzYMAwMzMzAAAMzsNGGzYZpxyy2wkthhlBYGGAAmZmZAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMbzMz0MLmZmxMAAAAAmZmZmZmZYGDAYmZmZmBAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMbzMz0MLmZMMmBAAAAmZmZmZmZYmZAAzMzMzAAAYgBmxiGLbgsNgNAzwAAAmZwgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzMmxMzMMbzMz0MLmZMmBAAAAwYmZmZmZMzYMAYmZmZGAAgZmtxwYGLLNW22GmsMMsAYGGAAmZmZwMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxMzyMzMmxMzMMbzMz0MLmZmxMAAAAAmhZmZmZmHYmZAAjZmZGAAADMwMW0YZDktBsBYGDAAwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWGzwMmZmhZbmZmmZxMzMmxAAAAAmZmZmZmZ8AzYAAzMzMzAAAMzsNGGzYZpxy22wkthhNAzwAAwMzMDGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoPAkXBWxkyfx9CbGaHonEAhLxYWmZGmxMzMMbjZmmZzMzMzMAAAAAmZmZmZmZYGDAYmZmZmBAAMzsNGGzYZpxy2ywkthhNAzwAAwMzMDGMA",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_FROST_MYTHICPLUS"] = {
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 2,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZYYWmZmZmZbGjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZzMjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjBz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbWMLzwYhhlZ2mGaGLYmxMzADADzMYmBYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxMDz2MzMzMbzYkZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MbzwYhhlZWmGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMDjxYY2mZmZmZbmZkZMzYYmxgZmZmZmZmZAAAAAAAAAYMbziZbGGLMsMz20QzYBzMmZGYAYYmBzMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZAzyMzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMzMzYY2mZmZmZzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZAz2MzMzMLzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZZmZkZMGDzMGMzMzMzMzMDAAAAAAAAAjZbWMLzwYhhlZ2mGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMzYY2mZmZmZzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNDYmhZMGDzyMzMzMbmZ0MjxYYMGMzMzMzMzMDAAAAAAAAAjZb2MLzwYhhlZ2mGaGLYmxMzADADzMYmZGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNDYmZMzMjBz2MzMzMLmZkZMGDjxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2GzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMDY2mZmZmZxMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjZYWmZmZmZbmZ0MDGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAAD",
            ["n"] = 1,
        },
    },
    ["DEATHKNIGHT_FROST_RAID"] = {
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAmZMjZAz2MzMzMbzMjMjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAclESCN5uIs3wGGVadXqL3NDwMzYGjxYZYmZmZmxMGZGjxwMDwMzMzMzMzAAAAAAAAAAAgxy2sZWmhxCDLzsNN0MWwMzMzMDMM",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZYYWmZmZmZbGjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAmBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZbmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZzMjmZMzYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMjZMjBz2MzMzMbzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbWMLzwYhhlZ2mGaGLYmxMzADADzMYmBYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxMDz2MzMzMbzYkZMGDzMGMzMzMzMzMDAAAAAAAAAjZb2MbzwYhhlZWmGaGLYmxMzADADzMYmxMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMDjxYY2mZmZmZbmZkZMzYYmxgZmZmZmZmZAAAAAAAAAYMbziZbGGLMsMz20QzYBzMmZGYAYYmBzMMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjZAzyMzMzMLzMjmZMGDzMGMzMzMzMzMDAAAAAAAAAjZbgBsAWGmQGLYmxMzADADzMAjBD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsPAkXBWxkyfx9CbGaHonEAhLNAzMMjxYY2mZmZmZZmZ0MjxYYmxgZmZmZmZmZAAAAAAAAAYMbDMgFwywEyYBzMmZGYAYYmBgBD",
            ["n"] = 1,
        },
    },
    ["ROGUE_OUTLAW_MYTHICPLUS"] = {
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAAbLzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw2yMzMMzMzsYmZ2GAAAAzMDAGzihhMwswCtwGAmZwAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGmZbaZw2MAAAAAgZbZMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBMY2mFzMzoZmNmFW2mWYjBYmZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAMjBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MmZmhZmtZmZMzMmFYmx0ygtZAAAAAA22mZmhZmZmFzMz2AAAAwYAwYWMMkBmFWoF2YAmZwAzA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMzswDwMbTLD2mBAAAAAYbZmZGmZmZWMzMLDAAAAjBAjZxwQGYWYhWYjBYmBzgHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYZZmZGmZMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMzswDwMbTLD2mBAAAAAYbZmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBzgHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYGMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZMzsNzMzMzMzsBmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYMgBz2sYmZGNzsxswy20CbMAzMzMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAgZMAYMLGGyAzCL0CbAYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZmZmZmFGmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMDzsNzMzMjxss4BYmtplBbzAAAAAAstMzMDzMzMLmZmlBAAAgxAgxsYYIDMLsQLsxAMzgBmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZmZmtZmZMzMzsBmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYMgBz2sYmZGNzsxswy20CbMAzMzMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
    },
    ["ROGUE_OUTLAW_RAID"] = {
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZmZmtZmZmZMmNeAmZbaZw2MAAAAAgZbbmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQAA0tw2gAD7pPTLoW5IGZDeAAMwwYmZwMzwMMMzMzMjZmplZMLzAAAAAAgttxM8AzMjFmZZ2GAAAAzMDwAbwwoBA2mwiZA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MYmZMzsNzMzMzMzsBmZbaZw2MAAAAAALLzMzwMzMziZmZbAAAAYMgBz2sYmZGNzsxswy20CbMAzMzMzgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MmZmZMzsNzMjZmZmFwMmWGsNDAAAAAw2yMzMMzMzsYmZ2GAAAAzMDAGzihhMwswCtwGAmZwAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGmZbaZw2MAAAAAgZbZMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBD8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAAbLzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMmZmtZmZmZMmF4BmZbaZw2MAAAAAAbbzMzwMzMziZmZbAAAAYmBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBMY2mFzMzoZmNmFW2mWYjBYmZmZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMjZmtZmZMzMzsAmZbaZw2MAAAAAgZbZmZGmZmZWMzMbDAAAAjBAjZxwQGYWYhWYjBYmBDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CQQA5HmDzx68KWyrW/8Y781L7Dgx2MMzMzMzsNzMzMzMjFGPwMbTLD2mBAAAAAYbZmZGmZMziZmZbAAAAYMAYMLGGyAzCL0CbMAzMYG8AA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_ELEMENTAL_MYTHICPLUS"] = {
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZmtxyMmZMmFLzMLDjZmFAgZAwMjhhB",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGzstMTLmZmNWmxMjBWmxiZGmZZAgZAMzMzYYYA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYahZGjlZmZGzYxyMzywYmZBAYAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMLzMzYstYCzMbjlZmZGDLzyMzywYmZBAYAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMbzMzYstYajZGjlZmZGjZxyMzywYmZBAYAMzMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZmtxyMPwMjxsYZmZZYMzsAAMAwMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZmtxyMzMjhFLzMLDjZmFAgBAmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMLzMzYstYahZmtxyMzMjhlZZMLDjZmNAgBAmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNMgBMbMhMLAwsMzMjx2iJMzsMWmZmZMsMLzYxMDzsMAgBAmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMLzMzYstYajZGjlZMz8AjZZWmZWGGzMLAADAMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYajZGjlZmZGDLWmZWGGzMLAAzAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYssYajZmtxyMmZegxsYZmZZYMzsAAMAwMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMLzMzYssYaDzsNWmZmZMsYZmZZYMzsAAMMwMzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzmZCNzCAMbzMzYstYajZmtxyMzMjhFLzMLDjZmFAgBAzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYahZmtxyMzMjhFLzMLDjZmFAgBAmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZbZMmhZAAAAgFzsthBMgZzMN0MLAwsMzMjx2ipFmZMWmZmZMjFLzMLDjZmFAgBgZmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMLzMzYmtlZiZmZjlZMzYwsMzsMMmZWAAzAYmZmxwwA",
            ["n"] = 1,
        },
    },
    ["SHAMAN_ELEMENTAL_RAID"] = {
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZZZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZGLzMjZmFAwMAmZmZMMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZmZZGjZmFAwMAmZmZMMMA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAmZZZAwyCDAAAAAAAAAgQAAAAIAAAAAAAAAAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbLzMGjZZZZMmhBAAAAsYmNYADY2YCZWAgZZmZGjtFTYmZbsMzMzYMLWmxyMzYmZBAYAgZGDDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsthBMgZjJkZBAmtZmZMWWMtxMz2YZmHYmxYWsMzsMMmZWAAGAYmxwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGzstMTLmZmNWmxMjBWmxiZGmZZAgZAMzMzYYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzstZmZYzwCz2MTDNzCAMLzMzYmtlZiZmZjlZMzYwsMzsMMmZWAAzAYmZmxwwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZGLmZMzsAAmBwMzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMmZmZZbZMMjBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZGLmZYmlBAmBwMzMjhhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZZZMmhBAAAAsYmtNzMDbGWY2mZaoZWAgZZmZGjtFTLMzsNWm5BmZMsYZmZZGjZmFAwMAmZmZMMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYQALMl7AwW51MWzGneuHE3tPCAAAAzMbbzMGjZZbZMmhZAAAAgFzsBDYAzGTIzCAMbzMzYstYahZGjlZmZGzYxyMzywYmZBAYAgZGDDD",
            ["n"] = 1,
        },
    },
    ["WARLOCK_AFFLICTION_MYTHICPLUS"] = {
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmNGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2MzY2GAAwMmlZZmZWGDAMbbbjhxsYmGzMDbZ2YYbAAAYAAAzMzMjZMzsxwMzMzMMDzMzAAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNLmx2MzYWGAAwMzsMLzMz2YAgx2yADYCmhtADbDAAAzAAAYmZMzwsxYGjZmZYYmZmBAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmFGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2mZGzyAAAmxsMLmZ2GDAMbbbjhxsYmGzMDbZ2YYbAAAYAAAYmhZMjtxYmZMzMjZYmZGAgBMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzmZmZWGAAwMmlZZmZ2GDAM22GYATwMsFYYbAAAYAAAYmZMjZsxwMzMzMMDzMzAAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbmxyMzMzyAAAmZmlZZmZWGDAMLbLjhxsYmGzMDbZ2YYZAAAYGAAYmZmZMjxYGDzwMzYwMzMAAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+iZMzoZzMz2MzYWGAAwMzsMLmZ2GDAM22GYATwMsFYYbAAAYGAAAzMjZMzYMmxYmZmxwMzMDAYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMMzMzsMAAAzMLzyMzsMGAwCMwsY0YGQmFwyAAAwMAAwMDMzYmZzMDzMmZGDmZmBAYGYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZmZWGAAwMmlZZmZWGDAYBGYWMaMDIzCYZAAAYAAAzMYMjxsxwMzYmZMDzMzAAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+amhZGNbzM2mZGz2AAAmZmlZxMzyYAgZZbbMMmFz0YmZYLzGDbDAAAzAAAzMzMjZMmtxYGjZmZGDzMzAAMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmxsMAAAzMLzyMzsNGAYstMwAmgZYLww2AAAwMAAAmZmZGzMGDjZmZmZMMzMDAwAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAYmZZWmZmlxAAzy2yYYMLmpxMzwWmFG2GAAAmBAAmZmZMzwMYGmZmZmxgZmZGAwMwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMMzMzsMAAAzMLzyMzsMGAYW2WGDjZxMNmZG2yswwyAAAwMAAwMzMzMzYMbmZYmxMzYwMzMAAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAysBWGAAAmBAAmZgZmZMMzwMjZmxgZmZAAmBG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMzsYZmZWGDAM22GYATwMsFYYbAAAYGAAAzMjZMzsBmZmZmxMDzMzAAMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzoZhhZmZmlBAAYmZZWmZmlxAAjllBGwEMDbBG2GAAAmBAAwMDzMmBzwMzMzMGMzMzAAmBG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZmZWGAAgZmlZZmZWGDAMLbbjhxsYmGzMDbZWYYZAAAYGAAYmZmZmZMGmZYmxMzYwMzMAAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZGz2AAAmZmlZxMzyYAgx2yADYCmhlADbDAAAzAAAYmZmZMzYMmxYmZmxwMzMAADYA",
            ["n"] = 1,
        },
    },
    ["WARLOCK_AFFLICTION_RAID"] = {
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAYmZZWmZmlxAAzy2yYYMLmpxMzwWmFG2GAAAmBAAmZmZMzwMYGmZmZmxgZmZGAwMwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZGNLMMzMzsMAAAzMLzyMzsMGAYW2WGDjZxMNmZG2yswwyAAAwMAAwMzMzMzYMbmZYmxMzYwMzMAAzAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMmZmpZjhZmZmlBAAYmZZWmZmlxAAWgBmFjGzAysBWGAAAmBAAmZgZmZMMzwMjZmxgZmZAAmBG",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAYIOwXTfhprvln24ZeRPDbAmZmZmZEzmhxsZmZY2GAAAwMzMzyMjxyMzMLmxMDAYGLwAziRjZAZWCWmBAAAAAAAAzwCA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAYIOwXTfhprvln24ZeRPDbghZmZmZEzmhxsZmZY2GAAAwMjZWmZegx2MzMLmxMDAYGbwAziRjZAZWCWmBAAAAAAAAzwCA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmNGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2MzY2GAAwMmlZZmZWGDAMbbbjhxsYmGzMDbZ2YYbAAAYAAAzMzMjZMzsxwMzMzMMDzMzAAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMjZGNLmx2MzYWGAAwMzsMLzMz2YAgx2yADYCmhtADbDAAAzAAAYmZMzwsxYGjZmZYYmZmBAMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CkQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzYWGAAwMmlZZmZWGDAM22GYATwMsFYYbAAAYAAAYmZMjZmFGmZmZmhZYmZGAgZgB",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DEMONOLOGY_MYTHICPLUS"] = {
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amZmZmpZjx2MzMzyAAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmZmZwMzwMMAAAjZmxMglZMgB",
            ["n"] = 2,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmx2MzMz2AAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmxMDmZGzYmZDAAMmZMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzyMzYWGAAAAAAgx2yMmZGWMMMz2s1CNjFjZGLzyMzMmBAmZMzMmZwMzYGzYBAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMMzMzsNAAAAAAAgxMGWgB2GtQDLGzMWmtZmZMDAMzYMzMzAMmxMzCAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMMzoZzMz2MzY2GAAAAAAgx2yMmZGWMMMz2s1CNjFjZGLz2MzMmBAmZMzMmZwMzMzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+ixDMzoZzMz2MzMz2AAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmxMDmZGzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmZ2mZGzyAAAAAAAM22mxMzwihhZ2mtWoZsYMzYZ2mZmxMAwMjZmxMDmZGzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZGzyAAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZ2mZmxMAwMjZmxMDmZGzYmZDAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDwYGGbAAgxMzMzwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmZ2mZGz2AAAAAAAAGzYYBGYb0CNsYMzYZ2mZmxMAwMjZmxMDwYGzYDAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+ixMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDwMzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMegZGNbmx2MzYWGAAAAAAAwYGDLwAbjWohFjZGLzyMzMmBAmZMzMmZAGzYmZBAAMmZmxwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMjZGNbmx2MzY2GAAAAAAAwYGDLwAbjWohFjZGLzyMzMmBAmZMzMmZAGzwMbAAgxMzMzwwyMGwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMzmZmZWGAAAAAAAwYGDLwAbjWohFjZGLzyMzMmBAmZMzMmZAGzYGbAAgxMzMGGWmxAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAAAAAYstMjZmhFDDzsNbtRzYxYmxysMzMjZAgZGzMjZGMzYmhZAAAGzMzMDDLzYAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amxMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZMzMzsMAAAAAAAjtlZMzMsYYYmtZrFaGLGzMWmlZmZMDAMzYmZMzgZGzMYAAAGzMzMDDLzYAD",
            ["n"] = 1,
        },
    },
    ["WARLOCK_DEMONOLOGY_RAID"] = {
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amxMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 3,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amZmZmpZjx2MzMzyAAAAAAAM2WmxMzwihhZ2mtWoZsYMzYZWmZmxMAwMjZmZmZwMzwMMAAAjZmxMglZMgB",
            ["n"] = 3,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzMNbMMzMmlBAAAAAAYstMjZmhFDDzsNbtRzYxYmxysMzMjZAgZGzMjZGMzYmhZAAAGzMzMDDLzYAD",
            ["n"] = 2,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbMz2MzMzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDAzYmBAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjhZmxsMAAAAAAAgxMGWgB2GtQDLGzMWmlZmZMDAMzYMzMzAMzMmZAAAGzMzYYYZGDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZMzMmlBAAAAAAAMmxwCMw2oFaYxYmxysMzMjZAgZGjZmZGAzMmBAAwYmZmZYYZGDYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZ2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjZmxMDgZGzAAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMmZGNbM2mZGzyAAAAAAAAGzYYBGYb0CNsYMzYZWmZmxMAwMjxMzMDwMzYmBAAYMzMjhhlZMgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+amZmZmpZjx2MzMzyAAAAAAAM2WmxMzwihhZWmtWoZsZMzYZMzMmZAgZmZGzMzgZmhZYAAAGzMjZMYZmBYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CoQAMrNP5kak+EBqLfUa3dMm+yMzMzoZjZMzMzsMAAAAAAAjtlZMzMsYYYmtZrFaGLGzMWmlZmZMDAMzYmZMzgZGzMYAAAGzMzMDDLzYAD",
            ["n"] = 1,
        },
    },
    ["MONK_WINDWALKER_MYTHICPLUS"] = {
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAswsNmxYmZgAYxMLzyYaWmlmZmZBYGDMzMDwYZAMzMLG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmx2MAAAAAAAAAAAALDjmxMgBMmhZmZGmthZYWmJAgFmtxMmZmZgAYxMLzyYaWmlmZmZDYGDMzMDwYZAMzMLG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMgZmhZmZGmNMDziJAgFmtxMGzMDEALmZZWGTQAAzMDgZAYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAswsxMmZmZgAYxMLz2YCCAYGDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNmZwyMBAswsxMmZmZgAYxMLz2YCCAYGDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAGGmZmZY2GmhZZmAAWMz2MDzMzMQAsBgmlZpZmZWAwAzMAM2GAD4DA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMGMMMzMzwshZYWmJAgFmNmxMzMDEALmZZ2GTQAAzYAMDwYZMgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNMDzyMBAswsxMmZmZgAYxMLzyYaWmlmZmZBYmZgZmZAYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNmZYWmJAgFmNmxMzMDEALmZZ2GTQAAzYAMDALDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GmhlZmZbGAAAAAAAAAAAglhRYGGGwwMmZmZY2GmhZZmAAWY2mZGjZmBCgFzsMLjpZZWamZmFAMwMzMAjlZAmZmNfA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNmZwyMBAswsNmxYmZgAYxMLz2YCCAYGDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsxMDzyMBAswsxMmZmZgAYxMLz2YaWmlmZmZBYGDMzMDwYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAGmxMzMDz2wMY5BmAAWMz2MzYMzMQAsYmlZZMBBAYMAmBYsMDwMzs5CA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmx2MAAAAAAAAAAAALDz0MmhhBMjhZmZGmNMDziJAgFmtxMmZmZgAYxMLz2YCCAYmZAMDwYZAMzMbG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRYGGGwMzwMzMDz2wMMLzEAwiZ2GzYmZmBCgFzsMbjJIAAjBwMAjlBwMzs5BA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMghZZmZ2mxAAAAAAAAAAAALDzEmx2wAGGmZmZY2GmhZZmAA2Mz2YYMzMQAsYmlZbMBBAMMAmBYsNAmZmND",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGsMzMbzAAAAAAAAAAAAsMMaGzwwAmxMmZmZY2GmBLmAAWMz2MzYMzMQAsYmlZZMBBAYMAmBYsMDwMzs5CA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMGMMMzYGmNmZwyMBAswsxMmZmZgAYxMLz2YCCAYGDgZAGbDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYbmZ2mBAAAAAAAAAAAYZYmmxMMMghhZmZGmNMDzyMBAswsxMmZmZgAYxMLz2YCCAYGDgZAGLDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYAMGbzM2mBAAAAAAAAAAAYZYmwMMMGMjhZmZGmNMDzyMBAsYmtZmxMzMDEAbAoZZWamZmFghBmZAYsNAGwA",
            ["n"] = 1,
        },
    },
    ["MONK_WINDWALKER_RAID"] = {
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwMGmZmZY2GmhZZmAAWMz2YGzMzMQAsYmlZZMBBAgBwMAsMAmZmFXA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmBMwyMGmZmZY2GmhZZmAAWMz2YGzMzMQAsYmlZZMNbzSzMzsAYMwMzMAsMAmZmNfA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2wMsMzMbzAAAAAAAAAAAAsMMCzwwAbzMDzMzMMbDzwsMTAALmZbmxMmZGIA2MzysMmmlZpZmZ2AwAzMzAwyAYmZW8B",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgZGLzMz2MAAAAAAAAAAAALDjmxMMMgZMMzMzwsNMDzyMBAsYmtZmxMzMDEALmZZWGTzys0MzMbAGDMzMDALDgZmZzDA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2MmhlZGbzAAAAAAAAAAAAsMMaGzwwAmxwMzMDz2ghZZmAAWMz2MDzMzMQAsBgmlZpZmZWAwAzMAMWGAD4DA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZY0MmhhBMjhZmZGmthZYWmJAgFzsNmxMzMDEALmZZWGTzys0MzMbAGDMzMDALDgZmZzHA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGwAGzwMzMDz2wMMLzEAwiZ2GzYmZmBCgFzsMLjpZZWamZmFAjBmZmBglZAmZmFPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GGjlZmZbGAAAAAAAAAAAglhRzYGGGwMmxMzMDz2wMYZmAAWMz2YGzMzMQAsYmlZZMNLzSzMzsBYMwMzMAsMAmZmFPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mZAAAAAAAAAAAALDjmxMMMw2YmxMzMDz2wMMLmAAWY2YGzMzMQAsYmlZZMNLzSzMzsAYMwMzMAsMAmZmND",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYM2GmhlZmZbGAAAAAAAAAAAglhRzYGwAmxMmZmZY2GmhZZmAAWMz2MzYmZmBCgFzsMLjpZZWamZmNAMwMzMAsMAmZmNPA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYw2wgtZmZbGAAAAAAAAAAAglhRzYGGGwMGmZmZY2GmhZZmAAWMz2MzYMzMQAsZswYaWmlmZmZDADMzMDALDgZmZzA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAi6cZM+HWADeySjzG9Lwx8PzYMYMYbmZ2mxAAAAAAAAAAAALDzEmhhB2mZGmZmZYWwMMLmAAWMz2YYMzMQAsBgmlZpZmZWAGzAzMAMWGADYA",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmZ2mBAAAAAAAAAAAYZYmwMMMgZMMzMzwsNMDzyMBAswsNmxYmZgAYxMLzyYaWmlmZmZBYGDMzMDwYZAMzMLG",
            ["n"] = 1,
        },
        {
            ["code"] = "C0QAQnG51S19isUJoJoTeJ/IKPzYMgxYZmx2MAAAAAAAAAAAALDjmxMgBMmhZmZGmthZYWmJAgFmtxMmZmZgAYxMLzyYaWmlmZmZDYGDMzMDwYZAMzMLG",
            ["n"] = 1,
        },
    },
    ["DRUID_BALANCE_MYTHICPLUS"] = {
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhhZMLzsMzCzM2YZmlxMjxGGGgx22MDGz2IwEAAAgFmZmZwmhxYAAYmBLDA",
            ["n"] = 3,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBjZZmlZWYmxGLzsMmZM2wwAM22mZwY2GBmAAAAswMzMD2MmxYAAYmBLDA",
            ["n"] = 2,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYstMzstNz2sNTzMLzEAAAgNzMzMD2MwYGAzMYmBGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBjxMLzsYmZswyMLjxMjNMMAjttZGMmtRgJAAAALMzMzgNjZMGAAmZwyA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgxsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZEAAAgNmZmZwmBGzAYmBAGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBjZZmlZWYmxGLzsMmZM2wwAM22mZwY2GBmAAAAsYmZmZwmhxYAAYmBLDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsMzMzMYYY2mZZsMMjNzyMLjZmhNMMADw22YDTzMLjAAAAsZmZmZwmhxYGAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgxsYmZmZBMjxMLzswMjNWmZZMmZsghBYstNzssNz2sNTzMLzEAAAgFmZmZwmhxYGAzMYmBLDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYGz2MLjtZMjNzyMGzMzYDDDwAstN2w0MzyIAAAAbMzMzgNDjxAwMDAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsYmZmZhhZMmZZmFzMjNWmZZMmZsghBYstNzgxsNCMBAAAYhZmZGsZYMmBAwMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMYYYMzyMLmZGbsMzyYMzYBDDwYbbmBjZbEYCAAAwiZmZmBbGGjZAAMzADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAA2oMaGjZG4BMLzMzMDzwwsNzyYZYGbmlZWGzMDbYYAGgttxGmmZWGBAAAYzMzMzgNDMmBwMDAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmZhBMLzsMzCzM2YZmlxMjxGGGgx22MDGz2IwEAAAgFzMzMD2MmxYAAYmBLDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMzMzMLMYMLzsMzCzM2YZmlxMjxGGAM22mZwY2GBmAAAAswMzMD2MmxYAAYmBLDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMMjtZWmxYmZGbYYAGbLzMbbzsMbz0MzyMBAAAYzMzMzgNDjxAwMDmZgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZAmlZmZmhZYY2mZZsMMjNzyMLjZmhNMMAjltZstNz2sMTzMLzEAAAgNzMzMD2MMGzAYmBAGA",
            ["n"] = 1,
        },
    },
    ["DRUID_BALANCE_RAID"] = {
        {
            ["code"] = "CYGAkuH5GdQpDrgY32rlVGnyqBAAAAAAAAAAAAAAAAAAoGCzYGAAAwmZZmlZmlxMzMzsYMGmZshFAMW2mZbbbmlZZmmZWmpAAQAsBAAA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmZhxDYMLzsN2mxMz2YZGzMGmNMAYAW2GbYamZZEAAAgNzMzMD2MMGDAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLGzYhlZWGjZGbYYAGbLzMYMbjATAAAAWYmZmBbGzYMDAgZGsMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDDzyYZmFzMzsxyMLjZmhNMMAjttZGMmlRgJAAAALmZmZGsZMjxAAwMDMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsMmZmZhBjZZmtx2MmZ2GLzYmxwshBADwy2YBTzMLjAAAAsZmZmZwmxMGDAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNMmZgxsMzMzMLMgxMLzsYmZmtxyMLjZGsgBAjltZGbzY2mJzsYCAAAwCzMzMYzYGjBgZGMzADA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzYMzyMLGzYhlZWGjZGbYYAGbLzMYMbjATAAAAWMzMzMYzwYMDAgZGsMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWGlZpZMmZAmtZmZmZBYMLjlxywMz2MLzYmZmhNMAYssNzstNz2sMTzMLzEAAAgNzMzMD2MMGDAzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbNjxMDwsYmZmBDzY2mZZsMMjtZWmxYmZGbYYAGbLzMbbzsMbz0MzyMBAAAYzMzMzgNDjxAwMDmZgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CYGADBD3hSPCL9Y9gz68WcKvMAAAAAAAAAAAAAAAAAWoMbZMmZgHwsMzMzMMDDz2MLjlhZsZWmZZMzMshhBYA22GbYamZZEAAAgNzMzMD2MwYGAzMAwA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_HAVOC_MYTHICPLUS"] = {
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmxYmMmZAAAAAAAzixsNDzMwMWmZmZYmBzyALzmZMMLaaMzMmxGAAAwAAQAwMDGACAAM",
            ["n"] = 3,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmxYmMmZAAAAAAAzixsNDzMz2MzYZmxMMzwMLzsNDGGbbMJjZGzYBAAAAAABYmBYAIAAwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmxYmMmZAAAAAAAzmxsNDzMwMWmZmZYmBzyMbzsMLzMzssNbTTzMzMmxGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmZGzkxMDAAAAAAYWMmtBzMz2MzYZmxMWmZYsMz2MbzyMzMbbzy00MmZMjFAAAAAAEgZmZGMAEAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMjZMzMzMmJjZGAAAAAAwsYMbjxMDMjlZmZGmZwsMDzysZGjtZZaaMzMG2AAAAGAACAmZwAQAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmZGzkxMDAAAAAAY2MmtZYmZ2mZGLzMmxyMDjlZ2mBDjtNmkxMjhFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBmxyMzMDzMYWGYZ2MjhZTTjZmxwGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMjZMzMzMmJjZGAAAAAAwsYMbjxMDMjlZmZGmZwsMwysZGDzimGzMjhNAAAgBAgAgZGMAEAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iagZmZ2mxMzMGzkxMDAAAAAAYWMmtZYmZ2mZGLzMmxyMDzsMz2MYYssxkMmZMjFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmZGzkxMDAAAAAAY2MmtZYmZ2mZGLz4BmhZGmZZmtZwwYbjJZMzYYBAAAAAABYmBYAIAAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iagZmZWmxMzMzMzkxMDAAAAAAY2MmtZYMz2MzYZmxMWmZYmlZ2mBDjlNmkxMjhFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmZ2mZGLzMmxyMDjlZ2mBDjtNmkxMjhFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iaGMzMz2MmZmxYmMmZAAAAAAAzixsNDzMz2MzYZmxMWmZYsMz2MYYstxkMmZMjFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmZGzkxMDAAAAAAY2MmtZYmBmxyMzMDzMYWGYZ2MjhZRTjZmxwGAAAwAAQAwMDGACAAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iagZmZ2MmZmxYmwMDAAAAAAY2egZmlZYmZ2mZGLzMmxyMDzsMz2MYYssxkMmZmhFAAAAAAEgZGgBgAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyYbmlZbmxYb200YmZMsBAAAAAgAgZGMAEAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALzmZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_HAVOC_RAID"] = {
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZMDzMGzyALzmZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 4,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZmZmZ2MmZmxMzkxMDAAAAAAYWegxsNDzMYmxyMjZYmBzyALzmZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 2,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMz2MmZmZmZmwMDAAAAAAY2MmtZYmBzMWmZegZYmBzyALziZMMbaaMzMG2AAAAAAQAwMDGACAAM",
            ["n"] = 2,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzixMzMzYmwMDAAAAAAY2MmtZGzMYmxyMjZYmxYWGYZWMjhZRTjZmxwGAAAAAACAmZwAQAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAEDLOxe3SEPP2R8Hw6bhoSYmZmZmZGMzMjxMhZGAAAAAAwsNMmZMzgZmtZbMmBzshlNYbWMjhZRTjxMzYwG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZmZmZ2mxMzMGzkxMDAAAAAAYWMmlZYmBmx2YmZGAWmZbmlZbmZmttZZaamZmxM2AAAAAAQAmZmZwAQAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEkAp/epaxe7D0A403L+Tvk0iamZGzMzmxMzMmZmMmZAAAAAAAzyDMmtZYmBzMWmZegZYmBzyYbmlZbmxYb200YmZMsBAAAAAgAgZGMAEAAYA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_VENGEANCE_MYTHICPLUS"] = {
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmhZmMzMYYmZGYGzMmZmZmxgZmZsZmZbMMAAAAAAACYmZsBAAAgBmZmZmt2mZmBAAAAAYA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjhZkZmBWMjZwMjZGz8AzMzYYmZmx2YGjxMAAAAAAACYmZsBAAAgBmZmZml2mZmBAzAAAAYA",
            ["n"] = 2,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMzkZmxwyMzMDMjZmZMzMzYwwM2MzsNGzAAAAwsNDGGLLMhhZM2AAAAwgZmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMjZkZmxwyMzMDMjZGzYmZGDmZmxmZmtxwAAAAwsMDGGLLMhhZmZ2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAwsNDGGLLMhhZmxGAAAAGYmZmZ2abmZGzMADAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjxMjZMjMzMGzyMzMjhZMzYGzMzYwwM2MzsNGzAAAAwsNDGGLLMhhZmZWAAAAwAzMzMzSbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZmMzMwiZMDmZMzYmHYmZGDzMzM2YmtxwAAAAwsNDGGLLMhhZmZ2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjZmZkZmBziZmZgZMzYGzMzYYmZmxyDMzsNGAAAAwsNDGGLLMhhZmxGAAAAGYmZmZ2abmZGzMADAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmhZkZmxwyMzMDMjZGzMzMzYwwM2MzsNGzAAAAwwAAMBMzM2AAAAwAzMzMzWbzMzAAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmBWMzMDMjZmZMzMzYwMzM2MzsNGzAAAAAAAIgZmxGAAAAGYmZmZ2abmZGAAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjhZkZmZYWMzMjhZMzYGzMzYYGmx2DMzsNGGAAAAAAABMzM2AAAAwgZmZmZ2abmZGAYAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZkZmxwyMzMDMjZGzYmZGDmZmx2DMzsMGGAAAAmtZwwYZhJMMzM2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjxMjZMjMzMGWmZmZgZMzYmZmZGDGmxmZmtxYGAAAAmtZwwYZhJMMzMzCAAAAGYAEgZGAAAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMjZkZmxwyMzMDMjZGzYmZGDmZmxmZmlxwAAAAAAAIgZmxGAAAAGYmZmZ2abmZGAYAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMjMzMGWmZmZgZMzMjZmZGDGmx2DMzsNGzAAAAwsNDGGLLMhhZmxCAAAAGYAEgZGAAAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmhZkZmBDzYGMzYmxMzMzMGMzMjtHYmZbMMAAAAAAACYmZsBAAAgBmZmZmt2mZmBAAAAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMGWmZmZgZMzYGzMzYwMzM2egZmtxAAAAAmtZwwYbjJMMzM2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_VENGEANCE_RAID"] = {
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZmMzMYWMzMDmZMzYGzMzYwMzM2egZGjxMAAAAAAACYmhNAAAAMwMzMzs12MzMAAAAAAD",
            ["n"] = 3,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjhZkZmBWMjZwMjZGz8AzMzYYmZmx2YGjxMAAAAAAACYmZsBAAAgBmZmZml2mZmBAzAAAAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAEDLOxe3SEPP2R8Hw6bhoSAAGMzMjxMjMzMGDjZbmBjtZYmZGMzMjZGbjZMzgBAAAAYZWMjhZTTDMzMDbA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMYWMjZgZMzYmZmZGDmZmx2DMzsMGAAAAwsNDGGbbMhhZmxGAAAAGYmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAYMzMjZmZkZmZMWMzMDMjZGzMzMzYwwM2mZGjBAAAAAAACYmZsBAAAgBjZmZml2mZmBAGAAAAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMYWMjZgZMzYmZmZGDmZmx2DMzsNGAAAAwsNDGGbbMhhZmxGAAAAGYmZmZWabmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMmZmMzMYWMzMDmZMzYGzMzYwMzM2egZGjxMAAAAYbGMgNEwMDbAAAAYgZmZmZrtZmZAAAAAAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMzMjMzMGWmZmZgZMzYGzMzYwMzM2egZmtxAAAAAmtZwwYbjJMMzM2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMMzkZmxwyMzMDMjZmZMzMzYwwM2MzsNGzAAAAwsNDGGLLMhhZM2AAAAwgZmZmZ2abmZGzMAAAAAMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZMjZkZmxwyMzMDMjZGzYmZGDmZmxmZmtxwAAAAwsMDGGLLMhhZmZ2AAAAwAzMzMzWbzMzYmBAAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmxMjMzMYWMzMDMjZGzYmZGDzMzM2MzsNGAAAAwsNDGGLLMhhZmxGAAAAGYmZmZ2abmZGzMADAAAgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CUkAp/epaxe7D0A403L+Tvk0iCAMjZmZmhZmMzMYYmZGYGzMmZmZmxgZmZsZmZbMMAAAAAAACYmZsBAAAgBmZmZmt2mZmBAAAAAYA",
            ["n"] = 1,
        },
    },
    ["EVOKER_DEVASTATION_MYTHICPLUS"] = {
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmZwMMjZaMzMNzM2mZmZmZmZmZGwMzAmZZmZgBMzM2glxs0YbmhJzkNw2wAzMGz4BA",
            ["n"] = 3,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMwMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 2,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMjZGmBmBjZaGzMZMWGzMzw8AzMzAmxMGzMLzMDmBmxMwGYLYGmQ2ALDzAMzMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmBMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AyMBYDDMzghHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMzMzYmZZMDMwYwGsMGN2GQmJAbYgZGMjHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmZmxYmZbmZgBGD2glxox2AyMBYDDMzghHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAgZMDmZYGMDMYMTjZmpZmx2MzMzMzMzMzAmZmZmHYmZZMDMwMzwGsMmlGbzMMZmsA2GGYmB4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMDMYMTjZmpZmx2MzMzMzMzMzAmxMzYmZZmZgBGD2glxox2AyMBYDDMzghHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBzYGjZaMzMNzMz2MzMzMzMzMzAMzMGzMLjZgBGD2glxox2AyMBYDzgZGM8AA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAgZMDmZYGmBMYMTzMzMNzM2mZmZmZmZmZGwMmBzMLzMDMwYwGsMGN2GQmJAbYgZGMjHA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmhHw8AYMTjZmpZmZ2mZmZmZmZmZGgZmxYmZZmZgBmZG2glxs0YbmhJzkFw2wMYmBDPA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzYmBzMYMTjZmpZMWmxMzMz8AzMzAmxYGzMLzMDMgZmxCsMmlGbzMMZmsB2GGYmxYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwgZGmBGzYMTjZmpZmZ2mZmZmZmZmZGwMmxYmZZmZwMwYwGsMGN2GQmJAbYGMzgBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMgBjZamZmpZmx2MzMzMzMzMzAmZmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMgBjZaMzMNzM2mZmZmZmZmZGwMmZGzMLzMDMwYwGsMGN2GQmJAbYgZGMjHA",
            ["n"] = 1,
        },
    },
    ["EVOKER_DEVASTATION_RAID"] = {
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmZwMMjZaMzMNzM2mZmZmZmZmZGwMzAmZZmZgBMzM2glxs0YbmhJzkNw2wAzMGz4BA",
            ["n"] = 5,
        },
        {
            ["code"] = "CsbBV7//nP39x/JJympTqouKSAAAAAAAAAAAAGzMMzsYGMgBjZaGzMZMWGzMzw8AzsNDYGzsNmZWmZGMDMjZgNwSwMMhsAWGG",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZGzMGzwMjxMYMTjZmpZM2GzMzMzMzMzAmZGwMLzMDmBMzM2glxs0YbmhJzkNw2wAzMGz4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZgZYGzMgBjZamZmpZmx2MMzMzMzMzAmxMGzMLzMDMwMzM2glxs0YbmhJzkNw2wAzMGDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDmZYGmBmBjZamZmpZmx2MzMzMz8AzMzAmxMGzMLzMDMwMzM2glxs0YbmhJzkNw2wAzMGDPA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzwMwMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzYmZwMMjZaMzMNjx2MmZmZmHYmZGwMzAmZZmZgBMzMWglxs0YbmhJzkNw2wAzMGzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmBMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBmZmxGsMmlGbzMMZmsB2GGYmxY4BA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAzMDMDzYmBzMYMTjZmpZMWmxMzMz8AzMzAmxYGzMbzMDMgZmxCsMmlGbzMMZmsB2GGYmxYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMjZGmBmBjZaGzMZMWGzMzw8AzMzAmxMGzMLzMDmBmxMwGYLYGmQ2ALDzAMzMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CsbBPJc41CfcseY0baneJ1IHrBAAAAAAAAAAAjZwMDzYmBMYMTzMzMNzM2mZmZmZmZmZGwMmxYmZZmZgBGD2glxox2AyMBYDDMzghHA",
            ["n"] = 1,
        },
    },
    ["EVOKER_PRESERVATION_MYTHICPLUS"] = {
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAegZmZwMjBz8AzmhZmZ7BYAAgZmZMDzYGNGDAAAwMzMZGzMPwsMmBAzYmxMLbsYjhZmZaoZD2MMmZwMDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmHYGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTzwMjZZMDAMmZMzyGL2YYmZmGa2MjNDzMzgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2mhxMbPADAAMjZMDGzoxMDAAAwMzIzYmxsMzMAYGzALgFwMMhsBbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzMzMmlZmBAzYmxMbLsYjhZmZaoZzwmhBwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2MzDwYGzMbmBYYAAgZMjZmxwMxMzAAAAmZmJDzMzYMDAMmZMzyCLWYYmZmGa2MjNDzMzgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WGzYYMPwsZGw2wAAAzYGzMjhZiZmBAAAMzMTGzMzDMLjZAgxMwCYDMDTIbmxmhBwMDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WGzYYMPwsZGw2wAAAzYGzYMMTMzMAAAgZmZaGzMzDMGzAAjZGzssxiNGmZmphmNzYzwMzMYmhB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZwYGNmZAAAAmZGZGzMmtZmBAzYGYDsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzImZAAAAmZGZGzMmlZmBAzYGYDsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGz2MMmZbYAAgZMj5BMzYGhZAAAAmZGZmZmxsMzMAYGzMmZbjFLMMzMTDNbG2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmZGDjxsZGw2AAAYGzMzMjhZiZmBAAAMzMTzwMjZZMDAMmZwCYDMDTIbM2MMDwMDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzImZAAAAmZGZGzMmtZmBAzYGYBsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmZGDjxsZGw2wAAAzYGzMjhZixMAAAgZmZyYmZmZZMDAMmZMzyGL2YYmZmGa2YsZYmZGMzwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMj5BMGzMhZGAAAwMzIzYmxsMzMAYGzALgFwMMhsZYzwAYmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmHYGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTGmZmxYGAYMDsA2AzwEymZsZYGgZGGA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WGzYYMPwsZGw2wAAAzYGzMjhZiZmBAAA2mZmJjZmxsMmBAGzALgNwMMhsxYzwMAzMMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjxYGhZAAAAmZGZGzMPwsMzMAYGzMmZZhFLMMzMTDNbwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZM4BmHY2MMzMbDDAAMjZMjxYmJMDAAAwMzIzwMzsMmBAzYmxMLLsYhhZmZaoZzwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYmZmlxMAYGzMmZZhFLMMzMTDNbG2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjx4BmJMzAAAAmZGZGzMPwsMmBAzYmxMLLsYhhZmZaoZD2MMmZwMzYA",
            ["n"] = 1,
        },
    },
    ["EVOKER_PRESERVATION_RAID"] = {
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYGzmhZmZbYAAgZMjZMGzIMDAAAwMzIzYmZmlxMAYGzMmZZhFLMMzMTDNbG2MMmZwMzYA",
            ["n"] = 2,
        },
        {
            ["code"] = "CwbBWYnbRY1EREkP8a0IbB+ZHAAAAAAYmZMbzgxMzYWwMbjZGAAgZMjBjxMjYmBAAAYmZmMz2MjZZm5BAwMmNYBsAmhJkB2MA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBV7//nP39x/JJympTqouKSAAAAAAYmZMLzgZMzYWwMbjZGAAAgBwIAAAAwMzMBAAAMGAwCYGmQWgNDA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjxYGhZAAAAmZGZGzMPwsMzMAYGzMmZZhFLMMzMTDNbwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZM4BmHY2MMzMbDDAAMjZMjxYmJMDAAAwMzIzwMzsMmBAzYmxMLLsYhhZmZaoZzwmhxMDmZGD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MjxMbPADAAMjZMjx4BmJMzAAAAmZGZGzMPwsMmBAzYmxMLLsYhhZmZaoZD2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZMYmZ2MMzMbPADAAMjZMjxwMhZGAAAwMzIzYm5BmlZmBAzYmxMLLsYhhZmZaoZD2MMmZwMzYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAMzMDmZM4BmHY2MMzMbDDAAMjZMDGmJzMzAAAAmZGZGzMmlZmBAzYGYDsAmhJkNDbGGAzMjB",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAYmZwMjZYGzmhZmZbAAAMjZMYGzIzMDAAAwMzMZmZmxsMzMAYGzALgFwMMhsZYzwAYmZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAegZmZwMjBz8AzmhZmZ7BYAAgZmZMDzYGNGDAAAwMzMZGzMPwsMmBAzYmxMLbsYjhZmZaoZD2MMmZwMDD",
            ["n"] = 1,
        },
        {
            ["code"] = "CwbBPJc41CfcseY0baneJ1IHrBAAAAAmZmZ2WmHYGDjxsZGw2wAAAzYGzMjhZiZmBAAAMzMTzwMjZZMDAMmZMzyGL2YYmZmGa2MjNDzMzgZGGA",
            ["n"] = 1,
        },
    },
    ["EVOKER_AUGMENTATION_MYTHICPLUS"] = {
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNiFMGzMAwA",
            ["n"] = 2,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMzADGTNzMzMAAAAYGzMjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGmZMzGAAAAAMAAYmZgBjpGzMzAAAAgZMzMmZWGzMwMMwYGLsADMDDNiFMzYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpGzMzAAAAgZMzMmZWGzMwMMGmlZssMLDzsMMDzMNiFMGzMzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZGbzMmZWGMzsMDGmZDAAAAAAAAzwDYGMmaMzMDAAAAMzMzYmZZMzAzsZMMLzYZZWGmZZYGmZaELYmZmZmZAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbMzMzyAzsMjZmxMAAAAAAAAwM8AzYGjpGzMzAAAAAzMjxMzyYmBmZbGDzyMWWmlhZWGmhZmGxCGzMzMzAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbjZmxyMYmtZMzMmBAAAAAAAAM8AzwYM1YmZGAAAAYmZMPwMzyYmBmZzYwCsMGGbDgZiYDjZwMDGM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhxMbzMzgBzMLzMzMjZ2AAAAAAAAYmZghZM1YmZGAAAAMjZMmZWGzMwMbzAjZswCMwMM0IWwYMzAMYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAgBAAmZgBjpGzMzAAAAgZMzMmZ2GzMwMMGmlZsYWGMbDzwMTjYBjxMjZghB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAgBAAzMDMYM1YmZGAAAAMjZmxMzyYmBmZzAjZswCMwMM0IWwMjZGAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmZwMMjpGzMzAAAAgZMjxMzyYmBmhxwsMjFWGMGmhZmGxCGjZmZGAD",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAAAAwMDMMzM1YmZGAAAAMjZMmZWGzMwMLGYMjFWgBmhhGxCmZMzAYYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbmZGMYmZZmZmZMDAAAAAAAAMzADzYqxMzMAAAAYGzYMzsMzMDMzyMwYGLsADMDDNiFMGzMADG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbjZGMDzMLzYmZMzGAAAAAAAAmhZGYM1YmZGAAAAMzMjxMzyYmBmZzYwCsMGGbDgZiYDjZwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjZMzGAAAAAAAAzMMmBjpGzMzAAAAgZMjxMzyYmBmhBGzYhFYgZYoRsgZGzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhxMbzMzgBzMLzMzMjZ2AAAAAAAAYmZgBjpmZmZGAAAAMjZmxMzyYmBmZZGYMjFWgBmhhGxCGjZGAYA",
            ["n"] = 1,
        },
    },
    ["EVOKER_AUGMENTATION_RAID"] = {
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAAAAwMMmHAjpGzMzAAAAAzMzMmZWGzMwMbGDWglxwYZAMTEbYmZwMDgB",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGjhZ2AAAAAgBAAzMDMYM1YmZGAAAAMjZmxMzyYmBmZzAjZswCMwMM0IWwMjZGAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMDj5BYGTNmZmBAAAAzYGjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAYmhxMYM1YmZGAAAAMjZMmZWGzMwMMwYGLsADMDDNiFMGzMAwA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgBzMLzMzMjZAAAAAAAAwMzADGTNzMzMAAAAYGzMjZmlxMDMziBGzYhFYgZYoRsgxYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZmZbmZGMYmZZGmZMzGAAAAAMAAYmZgBjpGzMzAAAAgZMzMmZWGzMwMMwYGLsADMDDNiFMzYmBAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbzMzgZYmZZGzMjZ2AAAAAAAAwMMmBjpGzMzAAAAgZMzMmZWGzMwMMGmlZssMLDzsMMDzMNiFMGzMzMAG",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNmZGbzMmZWGMzsMDGmZDAAAAAAAAzwDYGMmaMzMDAAAAMzMzYmZZMzAzsZMMLzYZZWGmZZYGmZaELYmZmZmZAM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhZmZbMzMzyAzsMjZmxMAAAAAAAAwM8AzYGjpGzMzAAAAAzMjxMzyYmBmZbGDzyMWWmlhZWGmhZmGxCGzMzMzAYA",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrNMzMbjZmxyMYmtZMzMmBAAAAAAAAM8AzwYM1YmZGAAAAYmZMPwMzyYmBmZzYwCsMGGbDgZiYDjZwMDGM",
            ["n"] = 1,
        },
        {
            ["code"] = "CEcBPJc41CfcseY0baneJ1IHrhxMbzMzgBzMLzMzMjZ2AAAAAAAAYmZghZM1YmZGAAAAMjZMmZWGzMwMbzAjZswCMwMM0IWwYMzAMYA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_DEVOURER_MYTHICPLUS"] = {
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 2,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMzMzMzMjBmBAAAAAAY5BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 2,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAMjZmZmxMjhZAAAAAAAWMmtxYGAAAAAAAAmxgZmZmZmZmZGzsYGjFtswMzMzWbzMzAYYAIgxgxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxwMAAAAAAAMmthZGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmxMzMzYmxwMAAAAAAAMmthZGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxYmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmBzMAAAAAAAegZmtBAAAAAAAAwMzMMmZmZMzMzYmtZGjNttAgAGgZMzMbzMTz2MLzMjZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADDABMGMmB",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxwMAAAAAAAMmthZGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADzMz2Mz0sNzmxgxMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMmZmZMzMzYmtZGjNttAgAGgZMzMbzMTz2MLzMjZMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmZmZmZGjxwMAAAAAAALGz2gZAAAAAAAAYGzw8AzMzMzMzMMz2MjxmsAgAGgZMzMbzMTzyMLzMDzMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAMjZmZmxMjhZAAAAAAAYMbjxMAAAAAAAAMjZYmZmZmZmZGmZxMGLaZhZmZmt2mZmBwMGACYMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmxMzMzYmxYmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzYmxwMAAAAAAAMmtxDYGAAAAAAAAmxMMzMzMzMzMzYmFzYsolFmZmZ2abmZGADzMjZMNbmFjBjZA",
            ["n"] = 1,
        },
    },
    ["DEMONHUNTER_DEVOURER_RAID"] = {
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMmZmZmZmBmBAAAAAAY7BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 4,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMzMzMzMjBmBAAAAAAY5BGz2gZAAAAAAAAYGzw8AzMzMzMzMjZ2mZM202CACYAMmZmtZmpZbmlZmxYGA",
            ["n"] = 3,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWmZmZmZGjxwMAAAAAAALGz2gZAAAAAAAAYGzw8AzMzMzMzMMz2MjxmsAgAGgZMzMbzMTzyMLzMDzMA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBG5bbocFKcv+yIq8fPd6ORBA2mxMzMzMzMGmBAAAAAAgxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBG5bbocFKcv+yIq8fPd6ORBA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2mxMzMzMzMGmBAAAAAAgxsMYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwYYMagZMYMD",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCAWMzMzMzMzMwMAAAAAAAegxsNYGAAAAAAAAmxMMPwMzMzMzMzYmtZGjNttAgAGAjZmZbmZa2mZZmZMmBA",
            ["n"] = 1,
        },
        {
            ["code"] = "CgcBp/epaxe7D0A403L+Tvk0iCA2MmZmZmZmxwMAAAAAAAegxsNYGAAAAAAAAmxMMzMzMzMzMDzsYGjFZhZmZmt2mZmBwwAQgZMYMD",
            ["n"] = 1,
        },
    },
}
