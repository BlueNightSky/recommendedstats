-- GENERATED 2026-09-11 - do not hand-edit
RecommendedStatsData_StatWeights = {}
